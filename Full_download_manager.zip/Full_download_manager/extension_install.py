"""Open the selected browser's store; retain cleanup for earlier install requests."""
import json
import os
from pathlib import Path
import re
import subprocess
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
CHROME_UPDATE = 'https://clients2.google.com/service/update2/crx'
EDGE_UPDATE = 'https://edge.microsoft.com/extensionwebstorebase/v1/crx'


def state_path():
    return Path.home() / '.hizli-indir' / 'extension-install-requests.json'


def load_requests():
    try:
        value = json.loads(state_path().read_text(encoding='utf-8'))
        return value if isinstance(value, list) else []
    except (OSError, ValueError):
        return []


def firefox_store_url():
    try:
        value = json.loads((ROOT / 'assets/extension-stores.json').read_text(encoding='utf-8')).get('firefox_url')
        parsed = urlsplit(value or '')
        if (parsed.scheme == 'https' and parsed.netloc == 'addons.mozilla.org'
                and re.fullmatch(r'/(?:[a-zA-Z-]+/)?firefox/addon/[a-zA-Z0-9_.-]+/?', parsed.path)
                and not parsed.query and not parsed.fragment):
            return value
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    return None


def registry_path(provider, identity):
    if provider not in ('chrome', 'edge') or not isinstance(identity, str) or not re.fullmatch('[a-p]{32}', identity):
        raise ValueError('Invalid store extension identity')
    product = 'Microsoft\\Edge' if provider == 'edge' else 'Google\\Chrome'
    return f'Software\\{product}\\Extensions\\{identity}'


def register_request(provider, identity):
    import winreg
    path = registry_path(provider, identity)
    update = EDGE_UPDATE if provider == 'edge' else CHROME_UPDATE
    owner = str(ROOT)
    # Preserve registrations that weren't created by this installation.
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as key:
            try:
                previous_owner = winreg.QueryValueEx(key, 'fdm_owner')[0]
            except OSError:
                previous_owner = None
            if previous_owner != owner:
                return False
    except FileNotFoundError:
        pass
    entry = {'provider': provider, 'id': identity, 'update_url': update, 'owner': owner}
    entries = [item for item in load_requests() if isinstance(item, dict) and (item.get('provider'), item.get('id')) != (provider, identity)]
    entries.append(entry)
    target = state_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(entries, indent=2), encoding='utf-8')
    temporary.replace(target)
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, path) as key:
        winreg.SetValueEx(key, 'fdm_owner', 0, winreg.REG_SZ, owner)
        winreg.SetValueEx(key, 'update_url', 0, winreg.REG_SZ, update)
    return True


def remove_requests():
    import winreg
    owners = {str(ROOT)}
    local = os.environ.get('LOCALAPPDATA')
    if local:
        owners.update(str(Path(local) / name / 'app') for name in ('HizliIndir', 'Full Download Manager'))
    remaining = []
    for entry in load_requests():
        try:
            if not isinstance(entry, dict) or entry.get('owner') not in owners:
                remaining.append(entry)
                continue
            path = registry_path(entry.get('provider'), entry.get('id'))
            expected = EDGE_UPDATE if entry['provider'] == 'edge' else CHROME_UPDATE
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as key:
                owner = winreg.QueryValueEx(key, 'fdm_owner')[0]
                try:
                    update = winreg.QueryValueEx(key, 'update_url')[0]
                except FileNotFoundError:
                    update = None
            if owner == entry['owner'] and update in (None, expected):
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, path)
            else:
                remaining.append(entry)
        except FileNotFoundError:
            pass
        except (OSError, ValueError, KeyError, TypeError):
            remaining.append(entry)
    path = state_path()
    if path.exists():
        path.write_text(json.dumps(remaining, indent=2), encoding='utf-8')


def request_install(browser=None, identity=None, open_browser=True):
    from browser_setup import prepare, store_identity
    result = prepare(browser, identity)
    browser = result['browser']
    pending = False
    if browser == 'firefox':
        url = firefox_store_url()
        if not url:
            url = 'https://addons.mozilla.org/firefox/'
            pending = True
    else:
        chrome_id = store_identity('chrome')
        url = ('https://chromewebstore.google.com/detail/' + chrome_id) if chrome_id else None
        if chrome_id and browser == 'edge' and result.get('extension_id') != chrome_id:
            from setup_browser import install
            install('edge', chrome_id)
    if not url:
        return {**result, 'install_method': 'unavailable'}
    method = 'store-pending' if pending else 'store-page'
    if open_browser:
        executable = result.get('executable')
        if executable and Path(executable).is_file():
            subprocess.Popen([executable, url], creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        else:
            return {**result, 'install_method': 'missing-browser', 'install_url': url}
    return {**result, 'install_method': method, 'install_url': url}
