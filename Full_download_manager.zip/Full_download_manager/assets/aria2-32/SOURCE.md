This Windows x64 aria2 build supports more than 16 connections per server.
The application limits the setting to 32 and defaults to 16.

Provider: https://github.com/tasy5kg/aria2-connection-unlocked
Pinned release: release-9e727358 (see runtime.json for the URL and SHA-256).
Build workflow: .github/workflows/auto-sync-patch-build-windows-x64.yml in that repository.

aria2-source.tar.gz contains corresponding source with the workflow's four
OptionHandlerFactory.cc limit changes applied. COPYING contains the GPL license.
The application does not enable lower piece sizes or other unlocked limits.

To reproduce the Windows build on a Linux Docker host, extract the source,
apply the workflow's Dockerfile.mingw adjustments (GNU GMP mirror and local
source COPY), and run its x86_64-w64-mingw32 build. The workflow describes the
complete configure, make and strip commands and dependency sources.
