"""Optional desktop URL protocol registration, independent of browser extensions."""
import argparse
import json
import os
from pathlib import Path
import plistlib
import shlex
import subprocess
import sys

SCHEME = 'hizli-indir'
DESKTOP = 'hizli-indir-url.desktop'
MIME = 'x-scheme-handler/' + SCHEME


def desktop_quote(value):
    # Desktop Entry quoting is not shell quoting. % must be doubled for field codes.
    value = str(value).replace('%', '%%')
    for char in ('\\', '"', '`', '$'):
        value = value.replace(char, '\\' + char)
    if '\n' in value or '\r' in value:
        raise ValueError('Yol satır sonu içeremez.')
    return '"' + value + '"'


def apple_string(value):
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'


def install(remove=False):
    home = Path.home()
    data = home / '.hizli-indir'
    data.mkdir(parents=True, exist_ok=True)
    handler = Path(__file__).resolve().with_name('protocol_handler.py')
    if sys.platform == 'win32':
        import winreg
        keypath = 'Software\\Classes\\' + SCHEME
        if remove:
            for suffix in ('\\shell\\open\\command', '\\shell\\open', '\\shell', ''):
                try:
                    winreg.DeleteKey(winreg.HKEY_CURRENT_USER, keypath + suffix)
                except FileNotFoundError:
                    pass
        else:
            python = Path(sys.executable)
            if python.with_name('pythonw.exe').exists():
                python = python.with_name('pythonw.exe')
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, keypath) as key:
                winreg.SetValueEx(key, '', 0, winreg.REG_SZ, 'URL:Full Download Manager')
                winreg.SetValueEx(key, 'URL Protocol', 0, winreg.REG_SZ, '')
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, keypath + '\\shell\\open\\command') as key:
                winreg.SetValueEx(key, '', 0, winreg.REG_SZ, f'"{python}" "{handler}" "%1"')
    elif sys.platform == 'darwin':
        bundle = data / 'HizliIndirLink.app'
        register = '/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister'
        if remove:
            if bundle.exists():
                subprocess.run([register, '-u', str(bundle)], check=True)
                import shutil
                shutil.rmtree(bundle)
        else:
            command = shlex.quote(sys.executable) + ' ' + shlex.quote(str(handler)) + ' '
            source = 'on open location target\n  do shell script ' + apple_string(command) + ' & quoted form of target\nend open location\n'
            subprocess.run(['osacompile', '-o', str(bundle), '-'], input=source, text=True, check=True)
            info = bundle / 'Contents/Info.plist'
            with info.open('rb') as stream:
                content = plistlib.load(stream)
            content.update({'CFBundleIdentifier': 'com.hizliindir.link', 'CFBundleURLTypes': [
                {'CFBundleURLName': 'Full Download Manager', 'CFBundleURLSchemes': [SCHEME]}]})
            with info.open('wb') as stream:
                plistlib.dump(content, stream)
            subprocess.run([register, '-f', str(bundle)], check=True)
    elif sys.platform.startswith('linux'):
        applications = Path(os.environ.get('XDG_DATA_HOME', home / '.local/share')) / 'applications'
        desktop = applications / DESKTOP
        previous = data / 'previous-url-handler.json'
        if remove:
            desktop.unlink(missing_ok=True)
            old = json.loads(previous.read_text()) if previous.exists() else ''
            if old:
                subprocess.run(['xdg-mime', 'default', old, MIME], check=True)
            else:
                import configparser
                for file in (Path(os.environ.get('XDG_CONFIG_HOME', home / '.config')) / 'mimeapps.list', applications / 'mimeapps.list'):
                    if not file.exists():
                        continue
                    config = configparser.ConfigParser(interpolation=None)
                    config.optionxform = str
                    config.read(file)
                    for section in config.sections():
                        if config.has_option(section, MIME):
                            values = [v for v in config.get(section, MIME).split(';') if v and v != DESKTOP]
                            if values:
                                config.set(section, MIME, ';'.join(values) + ';')
                            else:
                                config.remove_option(section, MIME)
                    with file.open('w') as stream:
                        config.write(stream, space_around_delimiters=False)
            previous.unlink(missing_ok=True)
        else:
            if not previous.exists():
                old = subprocess.run(['xdg-mime', 'query', 'default', MIME], capture_output=True, text=True, check=True).stdout.strip()
                previous.write_text(json.dumps('' if old == DESKTOP else old))
            applications.mkdir(parents=True, exist_ok=True)
            desktop.write_text('[Desktop Entry]\nType=Application\nName=Full Download Manager\nNoDisplay=true\nTerminal=false\nExec='
                               + desktop_quote(sys.executable) + ' ' + desktop_quote(handler) + ' %u\nMimeType=' + MIME + ';\n', encoding='utf-8')
            subprocess.run(['xdg-mime', 'default', DESKTOP, MIME], check=True)
    else:
        raise ValueError('Bu işletim sistemi için protokol kurulumu yok.')
    print('Uygulama bağlantısı kaldırıldı.' if remove else 'Uygulama bağlantısı kuruldu. Tarayıcıdan browser-link.html dosyasını açabilirsiniz.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Tarayıcıdan açıkça seçilerek kullanılabilen uygulama bağlantısını kurar.')
    parser.add_argument('--remove', action='store_true')
    args = parser.parse_args()
    try:
        install(args.remove)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        parser.exit(1, str(exc) + '\n')
