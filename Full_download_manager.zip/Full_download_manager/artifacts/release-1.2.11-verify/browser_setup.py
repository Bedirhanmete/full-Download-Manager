"""Default-browser discovery and an honest, guided extension activation flow."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BROWSERS = {
    'chrome': ('Google Chrome', 'chrome://extensions'),
    'edge': ('Microsoft Edge', 'edge://extensions'),
    'brave': ('Brave', 'brave://extensions'),
    'vivaldi': ('Vivaldi', 'vivaldi://extensions'),
    'opera': ('Opera', 'opera://extensions'),
    'chromium': ('Chromium', 'chrome://extensions'),
    'firefox': ('Firefox', 'about:addons'),
}


def classify_browser(progid, executable=''):
    value = (progid + ' ' + executable).lower()
    # Branded Chromium browsers can inherit Chrome-like ProgIDs.
    for name in ('firefox', 'brave', 'vivaldi', 'opera', 'chromium'):
        if name in value:
            return name
    if 'msedge' in value or 'microsoftedge' in value:
        return 'edge'
    if 'chrome' in value:
        return 'chrome'
    return None


def command_executable(command):
    match = re.match(r'^\s*"([^"]+\.exe)"', command, re.IGNORECASE)
    if not match:
        match = re.match(r'^\s*(.+?\.exe)(?:\s|$)', command, re.IGNORECASE)
    return os.path.expandvars(match.group(1)) if match else ''


def detect_default_browser():
    import winreg
    progid = ''
    for scheme in ('https', 'http'):
        try:
            path = rf'Software\Microsoft\Windows\Shell\Associations\UrlAssociations\{scheme}\UserChoice'
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as key:
                progid = winreg.QueryValueEx(key, 'ProgId')[0]
            break
        except OSError:
            continue
    command = ''
    if progid:
        for hive, path in (
            (winreg.HKEY_CURRENT_USER, rf'Software\Classes\{progid}\shell\open\command'),
            (winreg.HKEY_CLASSES_ROOT, rf'{progid}\shell\open\command'),
        ):
            try:
                with winreg.OpenKey(hive, path) as key:
                    command = winreg.QueryValueEx(key, '')[0]
                break
            except OSError:
                continue
    executable = command_executable(command)
    browser = classify_browser(progid, executable)
    name = BROWSERS[browser][0] if browser else 'Varsayılan tarayıcı'
    if browser == 'firefox':
        stem = Path(executable).stem.lower()
        name = {'zen': 'Zen Browser', 'floorp': 'Floorp', 'librewolf': 'LibreWolf'}.get(stem, name)
    return {'browser': browser, 'name': name,
            'progid': progid, 'executable': executable}


def extension_id():
    manifest = json.loads((ROOT / 'browser-extension' / 'manifest.json').read_text(encoding='utf-8-sig'))
    public_key = base64.b64decode(manifest['key'], validate=True)
    digest = hashlib.sha256(public_key).digest()[:16].hex()
    return ''.join(chr(ord('a') + int(char, 16)) for char in digest)


def browser_executable(browser):
    if os.name != 'nt':
        return ''
    import winreg
    executables = {'chrome': 'chrome.exe', 'edge': 'msedge.exe', 'brave': 'brave.exe',
                   'vivaldi': 'vivaldi.exe', 'opera': 'opera.exe', 'chromium': 'chromium.exe',
                   'firefox': 'firefox.exe'}
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        try:
            with winreg.OpenKey(hive, rf'Software\Microsoft\Windows\CurrentVersion\App Paths\{executables[browser]}') as key:
                value = winreg.QueryValueEx(key, '')[0].strip('"')
                if Path(value).is_file():
                    return value
        except OSError:
            continue
    return ''


def permanent_package():
    """Recognize a signed-package candidate; Firefox verifies the signature."""
    import zipfile
    candidate = ROOT / 'assets' / 'FullDownloadManager-Firefox.xpi'
    try:
        with zipfile.ZipFile(candidate) as archive:
            names = {name.lower() for name in archive.namelist()}
            manifest = json.loads(archive.read('manifest.json'))
            if (manifest['browser_specific_settings']['gecko']['id'] == 'hizli-indir@local.invalid'
                    and {'meta-inf/mozilla.rsa', 'meta-inf/mozilla.sf'} <= names):
                return candidate
    except (OSError, zipfile.BadZipFile, KeyError, ValueError):
        pass
    return None


def store_identity(browser, identity=None):
    """Persist only explicitly supplied, validated store identities."""
    family = 'edge' if browser == 'edge' else 'chrome'
    path = Path.home() / '.hizli-indir' / 'browser-store-ids.json'
    try:
        saved = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(saved, dict):
            saved = {}
    except (OSError, ValueError):
        saved = {}
    if identity is not None:
        if not re.fullmatch('[a-p]{32}', identity):
            raise ValueError('Extension ID must contain 32 letters from a to p.')
        saved[family] = identity
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix('.tmp')
        temporary.write_text(json.dumps(saved, indent=2), encoding='utf-8')
        temporary.replace(path)
    value = saved.get(family, '')
    if not value:
        try:
            bundled = json.loads((ROOT / 'assets' / 'extension-stores.json').read_text(encoding='utf-8'))
            value = bundled.get(family, '') if isinstance(bundled, dict) else ''
        except (OSError, ValueError):
            value = ''
    return value if isinstance(value, str) and re.fullmatch('[a-p]{32}', value) else None


def prepare(browser_override=None, chromium_id=None):
    from setup_browser import install
    from setup_protocol import install as install_protocol
    result = detect_default_browser()
    if browser_override is not None:
        if browser_override not in BROWSERS:
            raise ValueError('Unsupported browser')
        if result['browser'] != browser_override:
            result = {'browser': browser_override, 'name': BROWSERS[browser_override][0],
                      'progid': '', 'executable': browser_executable(browser_override)}
    # Explicit handoff also works when no supported extension browser is detected.
    install_protocol()
    browser = result['browser']
    published_id = store_identity(browser, chromium_id) if browser and browser != 'firefox' else None
    chrome_store_id = store_identity('chrome')
    store_channel = 'edge' if browser == 'edge' and published_id and published_id != chrome_store_id else 'chrome'
    if browser == 'edge' and not published_id:
        published_id = chrome_store_id
    identity = published_id or (extension_id() if browser and browser != 'firefox' else None)
    if browser:
        install(browser, identity)
    # The default browser may be Firefox/Zen while the store add-on is used in
    # Brave or Chrome. Prepare its host too, using the publisher's actual ID.
    chrome_id = store_identity('chrome')
    if chrome_id and browser not in ('chrome', 'brave', 'vivaldi', 'opera', 'chromium'):
        install('chrome', chrome_id)
    result['native_host_ready'] = bool(browser)
    result['extension_enabled'] = False  # Activation is completed in the browser.
    result['extension_path'] = str(ROOT / ('browser-extension-firefox' if browser == 'firefox' else 'browser-extension'))
    package = permanent_package() if browser == 'firefox' else None
    result['permanent_package'] = str(package) if package else None
    if package:
        result['extension_path'] = str(package)
    result['extensions_url'] = BROWSERS[browser][1] if browser else ''
    result['extension_id'] = identity
    result['store_id'] = published_id
    result['store_channel'] = store_channel
    result['store_url'] = (('https://microsoftedge.microsoft.com/addons/detail/' if store_channel == 'edge'
                           else 'https://chromewebstore.google.com/detail/') + published_id) if published_id else ''
    state = Path(os.environ['LOCALAPPDATA']) / 'Full Download Manager' / 'browser-setup.json'
    state.parent.mkdir(parents=True, exist_ok=True)
    state.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Varsayılan tarayıcı: ' + result['name'])
    return result


def remove_installed():
    """Remove registrations only when their command still points at this install."""
    import winreg
    from extension_install import remove_requests
    remove_requests()
    from setup_browser import install, registry_key, TARGETS
    data = Path.home() / '.hizli-indir'
    launcher = data / 'browser-host.bat'
    owned = launcher.exists() and str(ROOT / 'native_host.py') in launcher.read_text(encoding='utf-8')
    registrations = data / 'browser-registrations.json'
    if owned and registrations.exists():
        state = json.loads(registrations.read_text(encoding='utf-8'))
        for browser in tuple(state):
            if browser in TARGETS:
                install(browser, None, remove=True)
    path = r'Software\Classes\hizli-indir\shell\open\command'
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as key:
            command = winreg.QueryValueEx(key, '')[0]
        if str(ROOT / 'protocol_handler.py') in command:
            from setup_protocol import install as install_protocol
            install_protocol(remove=True)
    except FileNotFoundError:
        pass


def guide(browser_override=None, chromium_id=None):
    import tkinter as tk
    from tkinter import ttk, messagebox
    import preferences
    from i18n import text, error_text
    language = preferences.load()['language']
    def tr(key):
        return text(key, language)
    root = tk.Tk()
    root.title('Full Download Manager — ' + tr('browser'))
    root.geometry('800x740')
    root.minsize(760, 700)
    root.configure(bg='#2d2d2d')
    icon = ROOT / 'assets' / 'app.png'
    if icon.exists():
        window_icon = tk.PhotoImage(file=str(icon))
        root.iconphoto(True, window_icon)
    style = ttk.Style(root)
    style.theme_use('clam')
    style.configure('Browser.TFrame', background='#2d2d2d')
    style.configure('Browser.TLabel', background='#2d2d2d', foreground='#f5f5f5', font=('Segoe UI', 10))
    frame = ttk.Frame(root, padding=24, style='Browser.TFrame')
    frame.pack(fill='both', expand=True)
    try:
        result = prepare(browser_override, chromium_id)
    except Exception as exc:
        messagebox.showerror(tr('browser'), error_text(exc, language), parent=root)
        root.destroy()
        return
    browser = result['browser']
    choices = list(BROWSERS)
    selection = tk.StringVar(value=BROWSERS[browser][0] if browser else '')
    chooser = ttk.Combobox(frame, textvariable=selection, state='readonly',
                           values=[BROWSERS[name][0] for name in choices])
    chooser.pack(fill='x', pady=(0, 12))

    def reopen(selected, identity=None):
        executable = Path(sys.executable)
        pythonw = executable.with_name('pythonw.exe')
        if os.name == 'nt' and pythonw.exists():
            executable = pythonw
        command = [str(executable), str(ROOT / 'browser_setup.py'), '--guide', '--browser', selected]
        if identity is not None:
            command += ['--extension-id', identity]
        subprocess.Popen(command, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        root.destroy()

    chooser.bind('<<ComboboxSelected>>', lambda event: reopen(choices[chooser.current()]))
    ttk.Label(frame, text=result['name'], style='Browser.TLabel', font=('Segoe UI', 20, 'bold')).pack(anchor='w')
    key = ('browser_help_firefox_signed' if result['permanent_package'] else 'browser_help_firefox') if browser == 'firefox' else 'browser_help_chromium' if browser else 'browser_help_unknown'
    if result['store_id']:
        key = 'browser_help_chromium_store'
    ttk.Label(frame, text=tr(key), wraplength=690, justify='left', style='Browser.TLabel').pack(anchor='w', pady=(16, 18))
    path = result['extension_path']
    if browser:
        entry = ttk.Entry(frame)
        entry.insert(0, path)
        entry.configure(state='readonly')
        entry.pack(fill='x', pady=(0, 10))
    controls = ttk.Frame(frame, style='Browser.TFrame')
    controls.pack(fill='x', pady=8)

    def open_page(address=None):
        try:
            address = address or result['extensions_url']
            executable = result['executable']
            if browser and executable and Path(executable).is_file():
                subprocess.Popen([executable, address],
                                 creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            elif browser:
                root.clipboard_clear()
                root.clipboard_append(address)
                root.update()
                messagebox.showinfo(tr('browser'), tr('paste_address') + address, parent=root)
            else:
                os.startfile(str(ROOT / 'browser-link.html'))
        except OSError as exc:
            messagebox.showerror(tr('browser_error'), str(exc), parent=root)

    ttk.Button(controls, text=tr('extensions_page' if browser else 'link_page'), command=open_page).pack(side='left')
    if browser:
        def copy():
            root.clipboard_clear()
            root.clipboard_append(path)
            root.update()
        ttk.Button(controls, text=tr('copy_path'), command=copy).pack(side='left', padx=8)
        ttk.Button(controls, text=tr('open_folder'), command=lambda: os.startfile(str(Path(path).parent) if result['permanent_package'] else path)).pack(side='left')
    if browser == 'firefox' and not result['permanent_package']:
        ttk.Button(frame, text=tr('signing_guide'), command=lambda: os.startfile(str(ROOT / 'assets' / 'extension-signing.html'))).pack(anchor='w', pady=8)
    elif browser and browser != 'firefox':
        ttk.Button(frame, text=tr('publishing_guide'), command=lambda: os.startfile(str(ROOT / 'assets' / 'chromium-publishing.html'))).pack(anchor='w', pady=8)
        ttk.Label(frame, text=tr('store_identity_help'), wraplength=700, style='Browser.TLabel').pack(anchor='w')
        identity_entry = ttk.Entry(frame)
        identity_entry.insert(0, result['store_id'] or '')
        identity_entry.pack(fill='x', pady=8)
        def apply_identity():
            identity = identity_entry.get().strip()
            if not re.fullmatch('[a-p]{32}', identity):
                messagebox.showerror(tr('browser'), tr('store_identity_invalid'), parent=root)
                return
            reopen(browser, identity)
        ttk.Button(frame, text=tr('store_identity_apply'), command=apply_identity).pack(anchor='w')
        if result['store_url']:
            ttk.Button(frame, text=tr('store_open'), command=lambda: open_page(result['store_url'])).pack(anchor='w', pady=8)
    ttk.Label(frame, text=tr('restart_browser'), wraplength=690, style='Browser.TLabel').pack(anchor='w', pady=16)
    ttk.Button(frame, text=tr('done'), command=root.destroy).pack(anchor='e')
    root.mainloop()



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--guide', action='store_true')
    parser.add_argument('--remove-installed', action='store_true')
    parser.add_argument('--browser', choices=BROWSERS)
    parser.add_argument('--extension-id')
    parser.add_argument('--install-extension', action='store_true')
    args = parser.parse_args()
    try:
        if args.remove_installed:
            remove_installed()
        elif args.guide:
            guide(args.browser, args.extension_id)
        elif args.install_extension:
            from extension_install import request_install
            result = request_install(args.browser, args.extension_id)
            if result['install_method'] == 'unavailable':
                import tkinter as tk
                from tkinter import messagebox
                from preferences import load
                from i18n import text
                root = tk.Tk()
                root.withdraw()
                key = 'firefox_store_pending' if result['browser'] == 'firefox' else 'browser_store_unavailable'
                messagebox.showinfo('Full Download Manager', text(key, load()['language']), parent=root)
                root.destroy()
        else:
            prepare(args.browser, args.extension_id)
    except Exception as exc:
        if args.guide or args.install_extension:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, str(exc), 'Tarayıcı bağlantısı', 16)
        else:
            print(str(exc), file=sys.stderr)
        sys.exit(1)
