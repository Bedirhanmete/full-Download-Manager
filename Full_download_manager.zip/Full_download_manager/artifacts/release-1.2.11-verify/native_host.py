"""Invoked on demand by the browser extension. stdout is reserved for native messages."""
import os
from pathlib import Path
import subprocess
import sys
from browser_bridge import deliver, read_message, write_message
from app import find_aria2


def launch():
    python = Path(sys.executable)
    if os.name == 'nt' and python.with_name('pythonw.exe').exists():
        python = python.with_name('pythonw.exe')
    root = Path(__file__).resolve().parent
    environment = os.environ.copy()
    for name in ('PYTHONHOME', 'PYTHONPATH', 'TCL_LIBRARY', 'TK_LIBRARY'):
        environment.pop(name, None)
    environment['PYTHONUTF8'] = '1'
    # Firefox kills its native host job after sendNativeMessage completes.
    # The desktop must outlive that job, including when the browser is closed.
    flags = (subprocess.CREATE_NO_WINDOW | subprocess.CREATE_BREAKAWAY_FROM_JOB) if os.name == 'nt' else 0
    return subprocess.Popen([str(python), str(root / 'app_start.pyw')],
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=(os.name != 'nt'),
                     creationflags=flags, close_fds=True, cwd=root, env=environment)


def main():
    if os.name == 'nt':
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
    try:
        value = read_message(sys.stdin.buffer)
        if value is None:
            return
        if not find_aria2():
            raise RuntimeError('aria2c bulunamadı. Kurulumdan sonra tarayıcıyı yeniden başlatın.')
        result = deliver(value, Path.home() / '.hizli-indir', launch)
    except Exception as exc:
        result = {'ok': False, 'error': str(exc)}
    write_message(sys.stdout.buffer, result)


if __name__ == '__main__':
    main()
