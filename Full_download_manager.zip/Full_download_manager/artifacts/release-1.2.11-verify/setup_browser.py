"""Register user-level native messaging for Firefox and Chromium browsers."""
import argparse
import json
import os
from pathlib import Path
import re
import shlex
import sys
from browser_bridge import HOST

FIREFOX_ID = 'hizli-indir@local.invalid'
# Windows Chromium derivatives read Chrome's native-host registry as fallback.
TARGETS = {
    'chrome': ('Google/Chrome', 'google-chrome'),
    'edge': ('Microsoft Edge', 'microsoft-edge'),
    'chromium': ('Chromium', 'chromium'),
    'brave': ('BraveSoftware/Brave-Browser', 'BraveSoftware/Brave-Browser'),
    'vivaldi': ('Vivaldi', 'vivaldi'),
    'opera': ('com.operasoftware.Opera', 'opera'),
    'firefox': ('Mozilla', '.mozilla'),
}


def manifest_path(browser, home=None, platform=None):
    home = home or Path.home()
    platform = platform or sys.platform
    if platform == 'win32':
        family = 'firefox' if browser == 'firefox' else 'edge' if browser == 'edge' else 'chromium'
        return home / '.hizli-indir' / f'{family}-host.json'
    if platform == 'darwin':
        return home / 'Library/Application Support' / TARGETS[browser][0] / 'NativeMessagingHosts' / f'{HOST}.json'
    if browser == 'firefox':
        return home / '.mozilla/native-messaging-hosts' / f'{HOST}.json'
    return home / '.config' / TARGETS[browser][1] / 'NativeMessagingHosts' / f'{HOST}.json'


def registry_key(browser):
    product = 'Mozilla' if browser == 'firefox' else 'Microsoft\\Edge' if browser == 'edge' else 'Google\\Chrome'
    return f'Software\\{product}\\NativeMessagingHosts\\{HOST}'


def install(browser, extension_id, remove=False):
    if browser not in TARGETS:
        raise ValueError('Bilinmeyen tarayıcı.')
    if browser == 'firefox':
        extension_id = FIREFOX_ID
    elif not remove and (not extension_id or not re.fullmatch('[a-p]{32}', extension_id)):
        raise ValueError('Eklentiler sayfasındaki 32 harfli eklenti kimliğini girin.')
    data = Path.home() / '.hizli-indir'
    data.mkdir(parents=True, exist_ok=True)
    registrations = data / 'browser-registrations.json'
    state = json.loads(registrations.read_text(encoding='utf-8')) if registrations.exists() else {}
    if remove:
        state.pop(browser, None)
    else:
        state[browser] = extension_id
    manifest = manifest_path(browser)
    # Multiple Windows browsers share the Chrome registry. Keep every configured ID.
    ids = sorted({identity for target, identity in state.items() if manifest_path(target) == manifest})
    if ids:
        host = Path(__file__).resolve().with_name('native_host.py')
        if os.name == 'nt':
            launcher = data / 'browser-host.bat'
            interpreter = Path(sys.executable)
            # Native messaging needs real stdin/stdout, including when setup is
            # opened by our windowless pythonw GUI.
            if interpreter.name.lower() == 'pythonw.exe':
                interpreter = interpreter.with_name('python.exe')
                if not interpreter.is_file():
                    raise OSError('Native messaging requires python.exe next to pythonw.exe.')
            if any(c in str(host) + str(interpreter) for c in '%\r\n'):
                raise ValueError('Proje ve Python yollarında yüzde işareti veya satır sonu bulunamaz.')
            environment = ''.join(f'set "{name}="\r\n' for name in ('PYTHONHOME', 'PYTHONPATH', 'TCL_LIBRARY', 'TK_LIBRARY'))
            launcher.write_text(f'@echo off\r\nchcp 65001 >nul\r\n{environment}set "PYTHONUTF8=1"\r\n"{interpreter}" "{host}"\r\n', encoding='utf-8')
        else:
            launcher = data / 'browser-host'
            launcher.write_text('#!/bin/sh\nexec ' + shlex.quote(sys.executable) + ' ' + shlex.quote(str(host)) + '\n', encoding='utf-8')
            launcher.chmod(0o700)
        content = {'name': HOST, 'description': 'Full Download Manager tarayıcı bağlantısı', 'path': str(launcher), 'type': 'stdio'}
        if browser == 'firefox':
            content['allowed_extensions'] = ids
        else:
            from browser_setup import extension_id as development_id
            ids = sorted(set(ids) | {development_id()})
            content['allowed_origins'] = [f'chrome-extension://{identity}/' for identity in ids]
        manifest.parent.mkdir(parents=True, exist_ok=True)
        manifest.write_text(json.dumps(content, indent=2), encoding='utf-8')
        if sys.platform == 'win32':
            import winreg
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, registry_key(browser)) as key:
                winreg.SetValueEx(key, '', 0, winreg.REG_SZ, str(manifest))
    else:
        if sys.platform == 'win32':
            import winreg
            try:
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, registry_key(browser))
            except FileNotFoundError:
                pass
        manifest.unlink(missing_ok=True)
    registrations.write_text(json.dumps(state, indent=2), encoding='utf-8')
    print('Tarayıcı bağlantısı kaldırıldı.' if remove else 'Bağlantı kuruldu. Tarayıcıyı tamamen kapatıp yeniden açın.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Full Download Manager tarayıcı bağlantısını kurar veya kaldırır.')
    parser.add_argument('--browser', choices=tuple(TARGETS), required=True)
    parser.add_argument('--extension-id')
    parser.add_argument('--remove', action='store_true')
    args = parser.parse_args()
    try:
        install(args.browser, args.extension_id, args.remove)
    except (ValueError, OSError) as exc:
        parser.exit(1, str(exc) + '\n')
