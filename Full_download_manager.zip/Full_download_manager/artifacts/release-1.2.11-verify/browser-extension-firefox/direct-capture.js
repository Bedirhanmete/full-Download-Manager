// Firefox supports asynchronous blocking before the download UI is created.
// Only ordinary GET attachment navigations are portable to the native engine.
async function captureResponse(details) {
  if (details.method !== 'GET' || details.statusCode !== 200 || !supported(details.url)) return {};
  const disposition = (details.responseHeaders || []).find(header =>
    header.name.toLowerCase() === 'content-disposition');
  if (!/^\s*attachment(?:\s*;|\s*$)/i.test(disposition?.value || '')) return {};
  const {enabled = true} = await api.storage.local.get('enabled');
  if (!enabled) return {};
  try {
    await send(details.url);
    return {cancel: true};
  } catch (error) {
    try { await report(error.message); } catch {}
    return {}; // No acknowledgement: let the browser download normally.
  }
}

api.webRequest.onHeadersReceived.addListener(captureResponse,
  {urls: ['http://*/*', 'https://*/*'], types: ['main_frame', 'sub_frame']},
  ['blocking', 'responseHeaders']);
