const api = typeof browser === "undefined" ? chrome : browser;
const checkbox = document.getElementById('enabled');
const language = document.getElementById('language');
function render(lang) {
  document.documentElement.lang = lang;
  const tr = lang === 'tr';
  document.getElementById('enabled-text').textContent = tr ? 'İndirmeleri uygulamada aç' : 'Open downloads in the app';
  document.getElementById('help').textContent = tr
    ? 'Dosya indirmelerine tıkladığınızda uygulamada bir onay penceresi açılır.'
    : 'A confirmation window opens in the app when you click a file download.';
  document.getElementById('context-help').textContent = tr
    ? 'Bağlantıya sağ tıklayarak Full Download Manager ile indir seçeneğini de kullanabilirsiniz.'
    : 'You can also right-click a link and select Download with Full Download Manager.';
  document.getElementById('ui-help').textContent = typeof api.downloads?.setUiOptions === 'function'
    ? (tr ? 'Yakalama açıkken tarayıcının indirme paneli gizlenir. Yakalamayı kapattığınızda veya aktarım başarısız olduğunda panel geri açılır.'
          : 'While capture is enabled, the browser download panel is hidden. Disabling capture or a failed handoff restores the panel.')
    : '';
}
const defaultLanguage = navigator.language.toLowerCase().startsWith('tr') ? 'tr' : 'en';
api.storage.local.get({enabled: true, lastError: '', language: defaultLanguage}).then(values => {
  checkbox.checked = values.enabled;
  language.value = values.language;
  render(values.language);
  document.getElementById('error').textContent = values.lastError;
});
checkbox.addEventListener('change', () => api.storage.local.set({enabled: checkbox.checked}));
language.addEventListener('change', () => {
  render(language.value);
  api.storage.local.set({language: language.value});
});

