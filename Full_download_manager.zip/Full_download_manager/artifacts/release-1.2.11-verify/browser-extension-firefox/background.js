const api = typeof browser === "undefined" ? chrome : browser;
const HOST = 'com.hizliindir.bridge';
const MENU = 'hizli-indir-link';

// This controls browser-wide download UI, not its security checks or downloads.
// Restore the UI when capture is disabled or a handoff falls back to the browser.
async function syncDownloadUI(captureEnabled) {
  if (typeof api.downloads.setUiOptions !== 'function') return;
  if (captureEnabled === undefined) {
    const values = await api.storage.local.get('enabled');
    captureEnabled = values.enabled !== false;
  }
  await api.downloads.setUiOptions({enabled: !captureEnabled});
}
function updateDownloadUI(value) {
  return syncDownloadUI(value).catch(() => {});
}

function supported(url) {
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol) && !parsed.username && !parsed.password;
  } catch { return false; }
}

async function report(error) {
  await api.storage.local.set({lastError: String(error)});
  await api.action.setBadgeText({text: '!'});
  await api.action.setBadgeBackgroundColor({color: '#b42318'});
}

async function send(url) {
  const response = await api.runtime.sendNativeMessage(HOST, {action: 'download', url});
  if (!response?.ok) throw new Error(response?.error || 'Uygulamaya bağlanılamadı.');
  // Cosmetic failures must not turn an acknowledged transfer into a retry.
  try {
    await api.storage.local.set({lastError: ''});
    await api.action.setBadgeText({text: ''});
  } catch {}
}

async function capture(item) {
  const {enabled = true} = await api.storage.local.get('enabled');
  const url = item.finalUrl || item.url;
  if (!enabled || !supported(url) || item.state !== 'in_progress') {
    await updateDownloadUI(false);
    return;
  }
  await updateDownloadUI(true);
  let paused = false;
  let handedOff = false;
  try {
    // Keep the browser entry until the desktop actually acknowledges its dialog.
    await api.downloads.pause(item.id);
    paused = true;
    await send(url);
    handedOff = true;
    await api.downloads.cancel(item.id);
    // Remove only this acknowledged handoff, never other browser history.
    try { await api.downloads.erase({id: item.id}); }
    catch (error) { await report(`Aktarım tamamlandı; tarayıcı kaydı temizlenemedi: ${error.message}`); }
  } catch (error) {
    if (handedOff) {
      await updateDownloadUI(false);
      await report('Uygulama penceresi açıldı. Tarayıcıdaki duraklatılmış kopyayı İndirilenler sayfasından iptal edin.');
      return;
    }
    await updateDownloadUI(false);
    if (paused) {
      try { await api.downloads.resume(item.id); }
      catch { error = new Error(`${error.message} Tarayıcı indirmesini İndirilenler sayfasından yeniden başlatın.`); }
    }
    await report(error.message);
  }
}

api.runtime.onInstalled.addListener(async () => {
  await updateDownloadUI();
  await api.contextMenus.removeAll();
  await api.contextMenus.create({id: MENU, title: 'Full Download Manager ile indir', contexts: ['link'],
                               targetUrlPatterns: ['http://*/*', 'https://*/*']});
});
api.contextMenus.onClicked.addListener(async info => {
  if (info.menuItemId !== MENU || !supported(info.linkUrl)) return;
  try { await send(info.linkUrl); } catch (error) { await report(error.message); }
});
api.downloads.onCreated.addListener(item => { capture(item).catch(error => report(error.message)); });
api.runtime.onStartup.addListener(() => { updateDownloadUI(); });
api.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.enabled) updateDownloadUI(changes.enabled.newValue !== false);
});
updateDownloadUI();
