"""Small keyboard-accessible rounded controls for the Fluent dark desktop theme."""
import tkinter as tk
from tkinter import font


def rounded(canvas, box, radius=8, **options):
    x1, y1, x2, y2 = box
    r = min(radius, (x2-x1)/2, (y2-y1)/2)
    return canvas.create_polygon(
        x1+r, y1, x2-r, y1, x2, y1, x2, y1+r, x2, y2-r, x2, y2,
        x2-r, y2, x1+r, y2, x1, y2, x1, y2-r, x1, y1+r, x1, y1,
        smooth=True, splinesteps=24, **options)


class FluentButton(tk.Canvas):
    def __init__(self, parent, text, command, primary=False, **options):
        self.values = {
            'text': text, 'command': command, 'state': 'normal', 'anchor': 'center',
            'font': ('Segoe UI', 10), 'padx': 15, 'pady': 9,
            'bg': '#60cdff' if primary else '#333333',
        }
        self.values.update(options)
        self.primary = primary
        self.hovered = False
        self.pressed = False
        self.focused = False
        super().__init__(parent, bg=parent.cget('bg'), highlightthickness=0, bd=0, takefocus=1)
        self.bind('<Configure>', lambda _: self.draw())
        self.bind('<Enter>', lambda _: self.hover(True))
        self.bind('<Leave>', lambda _: self.hover(False))
        self.bind('<ButtonPress-1>', self.press)
        self.bind('<ButtonRelease-1>', self.release)
        self.bind('<FocusIn>', lambda _: self.focus(True))
        self.bind('<FocusOut>', lambda _: self.focus(False))
        self.bind('<Return>', lambda _: self.invoke())
        self.bind('<space>', lambda _: self.invoke())
        self.bind('<Destroy>', self.release_resources)
        self.resize()

    def release_resources(self, event):
        if event.widget is self:
            self.face = None
            self.values['command'] = None

    def cget(self, name):
        return self.values[name] if name in self.values else super().cget(name)

    def configure(self, cnf=None, **options):
        if cnf:
            options.update(cnf)
        native = {key: value for key, value in options.items() if key not in self.values}
        self.values.update({key: value for key, value in options.items() if key in self.values})
        if native:
            super().configure(**native)
        if options:
            self.resize()
        return None

    config = configure

    def resize(self):
        self.face = font.Font(self, font=self.values['font'])
        width = self.face.measure(self.values['text']) + 2*self.values['padx']
        height = max(36, self.face.metrics('linespace') + 2*self.values['pady'])
        super().configure(width=width, height=height,
                          cursor='hand2' if self.values['state'] != 'disabled' else '')
        self.draw()

    def draw(self):
        self.delete('all')
        width = max(self.winfo_width(), self.winfo_reqwidth())
        height = max(self.winfo_height(), self.winfo_reqheight())
        disabled = self.values['state'] == 'disabled'
        color = self.values['bg']
        if disabled:
            color = '#303030'
        elif self.pressed:
            color = '#4ca5ce' if self.primary else '#292929'
        elif self.hovered:
            color = '#78d5ff' if self.primary else '#414141'
        border = '#80dcff' if self.focused else color if self.primary or self.values['anchor'] == 'w' else '#444444'
        rounded(self, (1, 1, width-1, height-1), radius=7, fill=color, outline=border)
        anchor = self.values['anchor']
        x = self.values['padx'] if anchor == 'w' else width/2
        self.create_text(x, height/2, text=self.values['text'], anchor=anchor,
                         fill='#777777' if disabled else '#10232c' if self.primary else '#f5f5f5',
                         font=self.face)

    def hover(self, state):
        self.hovered = state
        if not state:
            self.pressed = False
        self.draw()

    def focus(self, state):
        self.focused = state
        self.draw()

    def press(self, event):
        if self.values['state'] != 'disabled':
            self.focus_set()
            self.pressed = True
            self.draw()

    def release(self, event):
        was_pressed = self.pressed
        self.pressed = False
        self.draw()
        if was_pressed and 0 <= event.x < self.winfo_width() and 0 <= event.y < self.winfo_height():
            self.invoke()

    def invoke(self):
        if self.values['state'] != 'disabled':
            return self.values['command']()

