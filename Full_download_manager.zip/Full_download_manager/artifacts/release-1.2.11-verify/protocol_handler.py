"""Handle explicit hizli-indir:// links through the same confirmation queue."""
from pathlib import Path
import sys
from urllib.parse import parse_qs, urlsplit
from browser_bridge import deliver, validate_request
from native_host import launch


def decode_link(link):
    if not isinstance(link, str) or len(link) > 64000:
        raise ValueError('Uygulama bağlantısı geçersiz.')
    parts = urlsplit(link)
    if parts.scheme != 'hizli-indir' or parts.netloc != 'download' or parts.path not in ('', '/') or parts.fragment:
        raise ValueError('Uygulama bağlantısı geçersiz.')
    query = parse_qs(parts.query, strict_parsing=True)
    if set(query) != {'url'} or len(query['url']) != 1:
        raise ValueError('Tek bir dosya bağlantısı gerekir.')
    return {'action': 'download', **validate_request({'action': 'download', 'url': query['url'][0]})}


def main():
    try:
        if len(sys.argv) != 2:
            raise ValueError('Tek bir uygulama bağlantısı gerekir.')
        deliver(decode_link(sys.argv[1]), Path.home() / '.hizli-indir', launch)
    except Exception as exc:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror('Hızlı İndir', str(exc))
        root.destroy()


if __name__ == '__main__':
    main()
