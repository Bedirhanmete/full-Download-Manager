"""Full Download Manager — private aria2 engine and bilingual desktop UI."""
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import urllib.error
from urllib.parse import urlsplit
from download_files import DownloadFiles


class RpcError(RuntimeError):
    def __init__(self, error):
        super().__init__(error['message'])
        self.code = error.get('code')

    def missing_gid(self, gid):
        return self.code == 1 and gid.lower() in str(self).lower() and 'not found' in str(self).lower()


def paused_session(contents):
    """Force every restored URI to pause before aria2 can make a network request."""
    lines = []
    entry = False
    for line in contents.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith('#') and not line[0].isspace():
            if entry:
                lines.append('  pause=true')
            entry = True
        elif entry and stripped.partition('=')[0].strip() == 'pause':
            continue
        lines.append(line)
    if entry:
        lines.append('  pause=true')
    return '\n'.join(lines) + ('\n' if lines else '')


def valid_url(value):
    parts = urlsplit(value)
    if parts.scheme not in ('http', 'https') or not parts.hostname or any(c.isspace() for c in value):
        raise ValueError('Geçerli bir http:// veya https:// dosya bağlantısı girin.')
    if parts.username or parts.password:
        raise ValueError('Kullanıcı bilgisi içeren bağlantılar desteklenmiyor.')
    return value


def human(size):
    size = float(size)
    for unit in ('B', 'KiB', 'MiB', 'GiB', 'TiB'):
        if size < 1024 or unit == 'TiB':
            return f'{size:.1f} {unit}'
        size /= 1024


def find_aria2():
    """Find the Windows one-click runtime without requiring a PATH change."""
    if sys.platform == 'win32':
        local = os.environ.get('LOCALAPPDATA')
        if local:
            for folder in ('Full Download Manager', 'HizliIndir'):
                binary = Path(local) / folder / 'aria2' / 'aria2c.exe'
                if binary.is_file():
                    return str(binary)
    return shutil.which('aria2c')

class Engine:
    def __init__(self, data_dir=None, connections=16, concurrent_downloads=3):
        self.validate_performance(connections, concurrent_downloads)
        binary = find_aria2()
        if not binary:
            raise RuntimeError('aria2c bulunamadı. README içindeki aria2 kurulumunu tamamlayın ve uygulamayı yeniden açın.')
        self.data = Path(data_dir or Path.home() / '.hizli-indir')
        self.data.mkdir(parents=True, exist_ok=True)
        self.lock = open(self.data / 'app.lock', 'a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                self.lock.seek(0)
                self.lock.write(b'0')
                self.lock.flush()
                self.lock.seek(0)
                msvcrt.locking(self.lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.lock.close()
            raise RuntimeError('Uygulama zaten açık. Açık pencereyi kullanın.')
        self.files = DownloadFiles(self.data)
        self._monitor_stop = threading.Event()
        self._monitor = None
        self.session = self.data / 'session.txt'
        self.session.touch(exist_ok=True)
        contents = self.session.read_text(encoding='utf-8-sig')
        paused = paused_session(contents)
        if paused != contents:
            temporary = self.session.with_suffix('.startup.tmp')
            temporary.write_text(paused, encoding='utf-8')
            os.replace(temporary, self.session)
        self.secret = secrets.token_urlsafe(32)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        self.endpoint = f'http://127.0.0.1:{port}/jsonrpc'
        # This client only talks to our loopback engine, never through a web proxy.
        self.http = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.log = open(self.data / 'engine.log', 'w', encoding='utf-8')
        args = [binary, '--no-conf=true', '--enable-rpc=true', '--rpc-listen-all=false',
                f'--rpc-listen-port={port}', f'--rpc-secret={self.secret}',
                '--rpc-allow-origin-all=false', '--enable-dht=false', '--enable-dht6=false',
                '--enable-peer-exchange=false', '--bt-enable-lpd=false',
                f'--input-file={self.session}', f'--save-session={self.session}',
                '--save-session-interval=5', '--force-save=false', '--pause=true',
                '--continue=true', '--auto-file-renaming=true', '--allow-overwrite=false',
                f'--max-concurrent-downloads={concurrent_downloads}', f'--split={connections}', f'--max-connection-per-server={connections}',
                '--min-split-size=1M', '--disk-cache=64M', '--max-overall-download-limit=0',
                '--max-download-limit=0',
                '--file-allocation=trunc' if sys.platform == 'win32' else '--file-allocation=none',
                '--max-tries=5',
                '--retry-wait=3', '--connect-timeout=10', '--timeout=20',
                '--console-log-level=warn', '--summary-interval=0']
        self.process = subprocess.Popen(args, stdout=self.log, stderr=self.log,
                                        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        try:
            for _ in range(60):
                if self.process.poll() is not None:
                    raise RuntimeError('İndirme motoru açılamadı. engine.log dosyasını kontrol edin.')
                try:
                    self.call('getVersion')
                    self.configure(connections, concurrent_downloads)
                    self._monitor = threading.Thread(target=self._monitor_controls, daemon=True,
                                                     name='fdm-control-files')
                    self._monitor.start()
                    return
                except (OSError, ValueError):
                    time.sleep(.1)
            raise RuntimeError('İndirme motoru zamanında yanıt vermedi.')
        except Exception:
            self.process.terminate()
            self.process.wait(timeout=5)
            self.log.close()
            self.lock.close()
            raise

    def call(self, method, *params):
        body = json.dumps({'jsonrpc': '2.0', 'id': 'app', 'method': 'aria2.' + method,
                           'params': ['token:' + self.secret, *params]}).encode()
        req = urllib.request.Request(self.endpoint, body, {'Content-Type': 'application/json'})
        try:
            with self.http.open(req, timeout=2) as response:
                result = json.load(response)
        except urllib.error.HTTPError as exc:
            with exc:
                try:
                    result = json.load(exc)
                except (ValueError, UnicodeError):
                    raise exc
            if not isinstance(result, dict) or 'error' not in result:
                raise exc
        if 'error' in result:
            raise RpcError(result['error'])
        return result['result']

    def add(self, url, directory, connections):
        self.validate_performance(connections, 1)
        valid_url(url)
        Path(directory).mkdir(parents=True, exist_ok=True)
        record = self.files.begin(directory)
        gid = self.call('addUri', [url], {'dir': str(Path(directory).resolve()),
                         'split': str(connections), 'max-connection-per-server': str(connections),
                         'file-allocation': 'trunc' if sys.platform == 'win32' else 'none',
                         'force-save': 'false', 'min-split-size': '1M',
                         'continue': 'false', 'auto-file-renaming': 'true',
                         'allow-overwrite': 'false', 'max-download-limit': '0', 'pause': 'true'})
        try:
            self.files.register(gid, record)
            self.files.observe([self.call('tellStatus', gid)])
        except Exception:
            self.call('forceRemove', gid)
            self.call('removeDownloadResult', gid)
            raise
        self.call('unpause', gid)
        self.call('saveSession')
        return gid

    @staticmethod
    def validate_performance(connections, concurrent):
        if type(connections) is not int or not 1 <= connections <= 16:
            raise ValueError('Connections must be between 1 and 16.')
        if type(concurrent) is not int or not 1 <= concurrent <= 8:
            raise ValueError('Concurrent downloads must be between 1 and 8.')

    def configure(self, connections=16, concurrent_downloads=3):
        """Apply unlimited transfer to both new and restored tasks, without needless restarts."""
        self.validate_performance(connections, concurrent_downloads)
        options = {'split': str(connections), 'max-connection-per-server': str(connections),
                   'max-download-limit': '0', 'min-split-size': '1M',
                   'file-allocation': 'trunc' if sys.platform == 'win32' else 'none',
                   'force-save': 'false'}
        self.call('changeGlobalOption', dict(options, **{
            'max-overall-download-limit': '0', 'max-concurrent-downloads': str(concurrent_downloads)}))
        tasks = self.call('tellActive') + self.call('tellWaiting', 0, 1000)
        for task in tasks:
            current = self.call('getOption', task['gid'])
            # aria2 restores the saved output name before populating its file path.
            if not any(entry.get('path') for entry in task.get('files', [])) and current.get('out'):
                task['files'] = [{'path': str(Path(current['dir']) / current['out'])}]
            changed = {key: value for key, value in options.items()
                       if key != 'min-split-size' and current.get(key) != value}
            if current.get('min-split-size') not in ('1M', '1048576'):
                changed['min-split-size'] = '1M'
            if changed:
                self.call('changeOption', task['gid'], changed)
        self.files.observe(tasks)
        self.call('saveSession')

    def snapshot(self):
        items = (self.call('tellActive') + self.call('tellWaiting', 0, 1000)
                 + self.call('tellStopped', 0, 1000))
        self.files.observe(items)
        return items

    def _monitor_controls(self):
        next_discovery = 0
        while not self._monitor_stop.wait(.15):
            try:
                if time.monotonic() >= next_discovery:
                    items = self.call('tellActive') + self.call('tellWaiting', 0, 1000)
                    self.files.observe(items)
                    next_discovery = time.monotonic() + .6
                else:
                    self.files.hide_controls()
            except (OSError, ValueError, RuntimeError):
                if self._monitor_stop.is_set():
                    break

    def cancel(self, gid):
        """Stop file writes before deleting only the chosen download's partial files."""
        item = self.call('tellStatus', gid)
        if item['status'] == 'complete':
            return 'complete'
        self.files.observe([item])
        result_missing = False
        if item['status'] in ('active', 'waiting', 'paused'):
            try:
                self.call('forceRemove', gid)
            except RpcError:
                if self.call('tellStatus', gid)['status'] == 'complete':
                    return 'complete'
                raise
            deadline = time.monotonic() + 10
            while True:
                try:
                    item = self.call('tellStatus', gid)
                except RpcError as exc:
                    # aria2 drops never-started queued/paused jobs without a stopped result.
                    if not exc.missing_gid(gid):
                        raise
                    item = dict(item, status='removed')
                    result_missing = True
                    break
                if item['status'] == 'complete':
                    return 'complete'
                if item['status'] in ('removed', 'error'):
                    break
                if time.monotonic() >= deadline:
                    raise RuntimeError('Download did not stop; partial files were not deleted.')
                time.sleep(.05)
        self.call('saveSession')
        others = (self.call('tellActive') + self.call('tellWaiting', 0, 1000)
                  + self.call('tellStopped', 0, 1000))
        preserved = self.files.delete_partials(item, others)
        if not result_missing:
            self.call('removeDownloadResult', gid)
        self.files.forget(gid)
        self.call('saveSession')
        return 'preserved' if preserved else 'cancelled'

    def close(self):
        self._monitor_stop.set()
        if self._monitor:
            self._monitor.join(timeout=5)
        error = None
        try:
            self.call('forcePauseAll')
            self.call('saveSession')
            self.files.observe(self.call('tellActive') + self.call('tellWaiting', 0, 1000))
            self.call('shutdown')
        except Exception as exc:
            error = exc
        try:
            self.process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            try:
                self.process.wait(timeout=4)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        finally:
            self.files.hide_controls()
            self.log.close()
            self.lock.close()
        if error:
            raise RuntimeError(f'Motor kapatıldı; oturum kaydı doğrulanamadı: {error}')


def main():
    from desktop_ui import launch
    launch()


if __name__ == '__main__':
    main()
