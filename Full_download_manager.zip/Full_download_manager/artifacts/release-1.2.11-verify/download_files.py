"""Track download ownership and handle only exact, validated download paths."""
import json
import os
from pathlib import Path
import threading


def hide_windows_file(path):
    if os.name != 'nt' or path.is_symlink() or not path.is_file():
        return
    import ctypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetFileAttributesW.argtypes = [ctypes.c_wchar_p]
    kernel.GetFileAttributesW.restype = ctypes.c_uint32
    kernel.SetFileAttributesW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
    kernel.SetFileAttributesW.restype = ctypes.c_int
    attributes = kernel.GetFileAttributesW(str(path))
    if attributes != 0xFFFFFFFF and not attributes & 2:
        if not kernel.SetFileAttributesW(str(path), attributes | 2):
            raise ctypes.WinError(ctypes.get_last_error())


class DownloadFiles:
    def __init__(self, data):
        self.path = Path(data) / 'download-files.json'
        self.lock = threading.RLock()
        try:
            records = json.loads(self.path.read_text(encoding='utf-8'))
            self.records = {gid: record for gid, record in records.items()
                            if isinstance(gid, str) and isinstance(record, dict)
                            and isinstance(record.get('directory'), str)
                            and isinstance(record.get('protected'), list)
                            and isinstance(record.get('paths'), list)} if isinstance(records, dict) else {}
        except (OSError, ValueError):
            self.records = {}

    def save(self):
        temporary = self.path.with_suffix('.tmp')
        with temporary.open('w', encoding='utf-8') as stream:
            json.dump(self.records, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, self.path)

    @staticmethod
    def begin(directory):
        root = Path(directory).resolve()
        return {'directory': str(root), 'protected': [entry.name for entry in root.iterdir()], 'paths': []}

    def register(self, gid, record):
        with self.lock:
            self.records[gid] = record
            self.save()

    @staticmethod
    def checked_path(value, record):
        path = Path(value)
        root = Path(record['directory']).resolve()
        if not path.is_absolute() or path.is_symlink():
            raise ValueError('Download cleanup refused an unsafe path.')
        resolved = path.resolve()
        if resolved.parent != root:
            raise ValueError('Download cleanup refused a path outside the download folder.')
        if path.exists() and not path.is_file():
            raise ValueError('Download cleanup refused a non-file path.')
        return path

    def observe(self, items):
        with self.lock:
            changed = False
            for item in items:
                gid = item['gid']
                paths = [entry['path'] for entry in item.get('files', []) if entry.get('path')]
                if gid not in self.records:
                    if item['status'] in ('complete', 'removed') or not item.get('dir'):
                        continue
                    # Adopt jobs restored from older application sessions conservatively.
                    record = self.begin(item['dir'])
                    record['legacy'] = True
                    self.records[gid] = record
                    changed = True
                record = self.records[gid]
                valid = [str(self.checked_path(value, record)) for value in paths]
                total = int(item.get('totalLength', 0))
                done = int(item.get('completedLength', 0))
                if record.get('legacy') and total > 0 and done < total:
                    for value in valid:
                        path = Path(value)
                        control = Path(value + '.aria2')
                        if path.is_file() and control.is_file():
                            for owned in (path.name, control.name, control.name + '__temp'):
                                if owned in record['protected']:
                                    record['protected'].remove(owned)
                                    changed = True
                # Restored jobs can have empty file paths until their first network request.
                if valid and record['paths'] != valid:
                    record['paths'] = valid
                    changed = True
            if changed:
                self.save()
        self.hide_controls()

    def hide_controls(self):
        with self.lock:
            paths = [value for record in self.records.values() for value in record.get('paths', [])]
        for value in paths:
            for suffix in ('.aria2', '.aria2__temp'):
                path = Path(value + suffix)
                try:
                    hide_windows_file(path)
                except OSError:
                    # An atomic control-file replacement can disappear during attribute changes.
                    pass

    def delete_partials(self, item, other_items):
        """Delete only this job's files, never whole folders or pre-existing files."""
        with self.lock:
            record = self.records.get(item['gid'])
            if not record:
                raise ValueError('Download ownership could not be verified.')
            occupied = {str(Path(entry['path']).resolve())
                        for other in other_items if other['gid'] != item['gid']
                        for entry in other.get('files', []) if entry.get('path')}
            targets = []
            preserved = False
            current_paths = [entry['path'] for entry in item.get('files', []) if entry.get('path')]
            if not current_paths and not record['paths'] and record.get('legacy'):
                return True
            for value in current_paths or record['paths']:
                path = self.checked_path(value, record)
                if str(path.resolve()) in occupied or path.name in record['protected']:
                    preserved = True
                    continue
                # A hard link can expose a file owned outside the download job.
                if path.exists() and path.stat().st_nlink > 1:
                    preserved = True
                    continue
                targets.append(path)
                for suffix in ('.aria2', '.aria2__temp'):
                    control = self.checked_path(str(path) + suffix, record)
                    if control.name not in record['protected']:
                        targets.append(control)
            # Complete validation precedes the first deletion.
            for path in targets:
                for attempt in range(6):
                    try:
                        path.unlink(missing_ok=True)
                        break
                    except PermissionError:
                        if attempt == 5:
                            raise
                        import time
                        time.sleep(.1)
            return preserved

    def forget(self, gid):
        with self.lock:
            self.records.pop(gid, None)
            self.save()

