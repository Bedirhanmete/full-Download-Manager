"""Validated, atomic user preferences. Legacy data path preserves existing sessions."""
import json
import os
from pathlib import Path

DATA_DIR = Path.home() / '.hizli-indir'
DEFAULTS = {
    'language': 'tr', 'connections': 16, 'concurrent_downloads': 3,
    'internet_mbps': 0.0, 'download_directory': str(Path.home() / 'Downloads' / 'Full Download Manager'),
}


def normalize(values):
    result = dict(DEFAULTS)
    if not isinstance(values, dict):
        return result
    if values.get('language') in ('tr', 'en'):
        result['language'] = values['language']
    for key, low, high in (('connections', 1, 16), ('concurrent_downloads', 1, 8)):
        value = values.get(key)
        if type(value) is int and low <= value <= high:
            result[key] = value
    value = values.get('internet_mbps')
    if type(value) in (int, float) and 0 <= value <= 100000:
        result['internet_mbps'] = float(value)
    directory = values.get('download_directory')
    if isinstance(directory, str) and directory.strip():
        result['download_directory'] = directory.strip()
    return result


def load(path=None):
    path = Path(path) if path else DATA_DIR / 'settings.json'
    try:
        return normalize(json.loads(path.read_text(encoding='utf-8-sig')))
    except (OSError, ValueError):
        return dict(DEFAULTS)


def save(values, path=None):
    path = Path(path) if path else DATA_DIR / 'settings.json'
    values = normalize(values)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    try:
        with temporary.open('w', encoding='utf-8') as stream:
            json.dump(values, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return values
