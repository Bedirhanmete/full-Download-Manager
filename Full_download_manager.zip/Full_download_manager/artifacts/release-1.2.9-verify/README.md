# Full Download Manager

Windows için terminal penceresi açmadan çalışan, Türkçe ve İngilizce arayüzlü bir indirme yöneticisi. İndirme motoru aria2; ek Python paketi gerekmez.

## Kurulum

**dist/FullDownloadManager-Setup.exe** dosyasını açıp **Kur** düğmesine basın. Kurulum dosyasını tek başına başka bir Windows 10/11 bilgisayarına da taşıyabilirsiniz.

- Eksik Python/Tkinter ve aria2 indirilir. Python yükleyicisinin yayıncı imzası, aria2 arşivinin SHA-256 özeti doğrulanır.
- Python kurulumu mevcut bir dizini güncellerse çalışan yorumlayıcı yeniden bulunur. Tkinter doğrulanamazsa imzası doğrulanmış Python yükleyicisiyle onarım denenir. Alt işlemler eski Python/Tcl ortam yönlendirmelerinden arındırılır; kullanıcının ortam ayarları değiştirilmez. Doğrulama ve onarım ayrıntıları **%LOCALAPPDATA%\Full Download Manager\python-validation.log**, **python-install.log** ve **python-repair.log** dosyalarındadır.
- Uygulama kullanıcı hesabına kurulur; yönetici izni veya WinGet gerekmez.
- Masaüstü ve Başlat menüsüne **Full Download Manager** EXE kısayolları eklenir.
- Varsayılan tarayıcı algılanır ve yerel mesajlaşma bağlantısı hazırlanır.
- Windows Ayarları → Uygulamalar → **Full Download Manager** üzerinden kaldırılabilir. İndirilen dosyalar, kayıtlı oturum ve çalışma zamanı bileşenleri korunur.
- Güncellemeden önce açık uygulamada **Kaydet ve çık** düğmesine basın.

İlk kurulum için internet gerekir. Yeni kurulum **%LOCALAPPDATA%\Full Download Manager\app** konumunu kullanır. Eski kurulumun Python/aria2 bileşenleri gerektiğinde yeniden kullanılabilir; oturum ve ayarlar korunur. Proje kaynaklarını taşımak veya tutmak, EXE ile kurulmuş uygulama için gerekli değildir.

**dist/FullDownloadManager-Uninstall.exe** ayrı kaldırıcıdır; kurulu uygulama klasörüne de eklenir ve Windows Uygulamalar listesinden çağrılır. Onaydan sonra uygulamayı ve kendi kısayollarını kaldırır; indirmeleri, ayarları ve paylaşılan çalışma zamanı bileşenlerini korur. Açık indirme uygulamasını zorla kapatmaz; önce Kaydet ve çık kullanılmalıdır.

Uzantılar ayrı paketler halinde **dist** klasöründedir: **Chromium-1.2.0-STORE.zip** Chrome/Edge mağazasına gönderilir; **Chromium-1.2.0-UNPACKED.zip** çıkartılıp geliştirici modunda Paketlenmemiş öğe yükle ile açılır. **Firefox-1.2.0-UNSIGNED.zip** Mozilla imza/mağaza başvurusuna gönderilir; **Firefox-1.2.0-TEMPORARY.zip** çıkartılıp about:debugging ekranında Geçici eklenti yükle ile manifest.json seçilir. Firefox geçici eklentisi tarayıcı kapanınca kalkar; Chromium geliştirici kopyası kaldırılana kadar kalabilir. Mağaza ve geliştirici kimlikleri yerel köprü tarafından birlikte desteklenir.

Bu EXE kod imzalama sertifikasıyla imzalanmadı. Python yükleyicisinin imzası ve aria2 arşivinin özeti ayrıca doğrulanır.

## Yeni arayüz ve kullanım

Windows 11 stilinde koyu gri tema, yuvarlatılmış düğmeler, mavi vurgu rengi, indirme simgesi, sol menü, dosya kartları ve gerçek ölçümlere dayanan hız grafiği vardır. Görünüm filtreleri:

- **Tüm indirmeler:** bütün oturum kayıtları.
- **Aktif indirmeler:** indirilen ve sırada bekleyen dosyalar.
- **Tamamlananlar:** başarıyla tamamlanan dosyalar.
- **Duraklatılanlar:** duraklatılmış dosyalar.

**Yeni indirme** veya **Ctrl+N** ile HTTP/HTTPS dosya bağlantısını girin ve kayıt klasörünü seçin. Dosya kartından duraklatın, devam ettirin veya **İptal** düğmesini kullanın. Tamamlanan kartın **Klasörü aç** düğmesi kayıt konumunu açar. **İptal**, indirmeyi durdurup o indirmeye ait yarım dosyayı ve .aria2 devam kaydını siler. Önceden var olan, tamamlanmış veya başka bir indirmeye ait dosyalar korunur. Duraklatma ve normal kapanış yarım dosyayı silmez.

**Kaydet ve çık** veya pencerenin X düğmesi indirmeleri duraklatır, oturumu kaydeder ve uygulamanın başlattığı aria2 sürecini kapatır. Sonraki açılışta yarım işler duraklatılmış halde yüklenir.

Açılışta varsayılan bir dosya veya ISO bağlantısı eklenmez. Kayıtlı oturumdaki eski otomatik devam et seçenekleri de açılıştan önce duraklatmaya çevrilir. İndirme yalnızca **İndirmeyi başlat**, **Devam et** veya **Tümünü başlat** seçildiğinde başlar.

### .aria2 devam dosyası

Bu dosya duraklatılan indirmeyi kaldığı yerden sürdürmek için gereklidir. Windows'ta gizli dosya özniteliğiyle saklanır; klasörün gizli öğeler görünümünü değiştirmez. Başarılı indirme sonunda motor tarafından kaldırılır. İptal edildiğinde yarım dosyayla birlikte temizlenir. Normal kapanışta devam edebilmek için gizli olarak korunur.

## Türkçe / English

**Ayarlar → Dil → Türkçe / English → Kaydet**. Dil tercihi kalıcıdır ve açık uygulamaya yeniden başlatmadan uygulanır. İndirmeler bu işlem sırasında korunur. Ana ekran, dosya pencereleri, ayarlar, hız göstergeleri ve tarayıcı bağlantısı yönergeleri iki dili destekler.

**Settings → Language → English → Save** changes the interface immediately and saves your choice for future launches. The product name stays **Full Download Manager** in both languages.

## İndirme performansı

- Dosya başına **1–16 bağlantı**, varsayılan 16. Aynı sunucu için standart aria2 sınırı 16'dır; arayüz gerçekte kullanılmayan 32 bağlantı göstermez.
- **1–8 eşzamanlı dosya**, varsayılan 3. Aynı anda birden fazla dosya indirilirse hat kapasitesi dosyalar arasında paylaşılır.
- Genel ve dosya bazlı hız sınırı **0 / sınırsız**. Ayarlar yeni ve oturumdan dönen indirmelere uygulanır.
- 1 MiB en küçük parça, 64 MiB disk önbelleği.
- Windows'ta **trunc** dosya hazırlama yöntemi: NTFS'de sparse dosya kullanarak büyük paralel indirmelerde aradaki boş alanların yazılmasını önler.
- Hız grafiği ve dosya kartları gerçek motor verilerini kullanır. İnternet kapasitesi bilinmiyorsa kullanım yüzdesi uydurulmaz.

**Ayarlar → İnternet paketi hızı (Mbps)** yalnızca kapasiteyle karşılaştırma içindir; hız sınırlamaz ve bir hız testi yapmaz. Değeri internet paketinizle aynı girin.

**500 Mbps ≈ 62,5 MB/s**. MB/s dosya aktarımını, Mbps hat hızını gösterir. Hız göstergeleri ondalık birimleri kullanır. Kaynak sunucu, Range desteği, Wi-Fi, disk, diğer ağ trafiği ve ağ yolu erişilebilen hızı etkiler; uygulama her kaynaktan hat hızını garanti edemez.

16 Ekim 2026'da kullanıcı tarafından sağlanan Microsoft ISO bağlantısında kısa ölçüm yapıldı. Tek bağlantılı 32 MiB Range testi yaklaşık 309,8 Mbps, 16 bağlantılı test yaklaşık 481,8 Mbps verdi. Gerçek aria2 motorunun yaklaşık 108 MiB kısmi aktarımında başlangıç dahil 2,1 saniyelik ortalama 429,4 Mbps, motorun anlık tepe ölçümü 527,3 Mbps oldu. Bunlar kısa test sonuçlarıdır; sürekli aktarım garantisi değildir. Ölçüm özeti: **artifacts/engine-speed-test.json**. Test parçaları silindi; ISO'nun tamamı indirilmedi.

Kaynak: [aria2 bağlantı, hız sınırı, disk önbelleği ve dosya hazırlama seçenekleri](https://aria2.github.io/manual/en/html/aria2c.html), [Windows sparse dosya uygulaması](https://github.com/aria2/aria2/blob/master/src/AbstractDiskWriter.cc), [trunc hazırlama yolu](https://github.com/aria2/aria2/blob/master/src/TruncFileAllocationIterator.cc).

## Tarayıcı bağlantısı

Yakalanan indirme onayı, uygulama küçültülmüş olsa bile geri açılır ve kısa süreli en üst pencere olarak tarayıcının önüne getirilir; sürekli “her zaman üstte” kalmaz. Chromium uzantısı 1.2.0, **downloads.ui** izniyle yakalama açıkken tarayıcının otomatik indirme panelini gizler. Bu API tarayıcı genelini etkiler. Yakalama kapatılırsa veya aktarım tarayıcıya geri dönerse panel yeniden etkinleştirilir. Desteklemeyen tarayıcılarda yakalama çalışır; panel gizleme uygulanmaz. İndirilenler sayfasını elle açmak, Farklı kaydet penceresi ve sitelerin kendi pencereleri bu API’nin kapsamı dışındadır. Mevcut mağaza uzantısı için **1.2.0 STORE ZIP** aynı mağaza kaydına güncelleme olarak gönderilmeli; yeni izin tarayıcıda onaylanmalıdır.

EXE kurulumu Windows'un HTTP/HTTPS varsayılan tarayıcısını okur. Chrome, Edge, Brave, Opera, Vivaldi, Chromium ve Firefox ailesi için uygun yerel mesajlaşma kaydı oluşturulur. Zen Browser, Firefox tabanlı bağlantıyı kullanır. Varsayılan tarayıcı tercihi değiştirilmez.

Yayımlanan Chrome Web Store uzantısının kimliği **assets/extension-stores.json** içinde bulunur. Kullanıcı tarafından ayrıca bir kimlik seçilmediyse bu kimlik kullanılır. Varsayılan tarayıcı Zen/Firefox olsa bile Chrome/Brave köprüsü de hazırlanır; mağaza uzantısının eski geliştirme kimliği yüzünden reddedilmesi önlenir. Mevcut mağaza uzantısını yeniden yayımlamak gerekmez.

**Tarayıcı bağlantısı** düğmesi veya Başlat menüsündeki **Full Download Manager Browser Integration** kısayolu yönergeleri yeniden açar. Yerel bağlantının hazır olması eklentinin etkinleştirildiği anlamına gelmez; arayüz bunu otomatik yakalama açıkmış gibi göstermez.

### Eklentinin etkinleştirilmesi

Eklenti henüz mağazalarda yayımlanmadığından bu son adım tarayıcıda yapılır:

- **Chromium ailesi:** kalıcı mağaza dağıtımı için **dist/FullDownloadManager-Chromium-1.2.0-STORE.zip** dosyasını Chrome Web Store veya Edge Partner Center’a yükleyin. **assets/chromium-publishing.html** yayınlama adımlarını, izin açıklamalarını ve gizlilik metnini içerir. Başvuru/yayın kullanıcı hesabında tamamlanır. Uygulamada **Tarayıcı bağlantısı** ekranının üstünden tarayıcı seçilebilir; varsayılan tarayıcı değiştirilmez. Mağazanın verdiği gerçek uzantı kimliğini girip **Mağaza uzantısını uygulamaya bağla** düğmesine basın. Chrome kimliği Chrome, Brave, Vivaldi, Opera ve Chromium için paylaşılır; Edge mağaza kimliği ayrı tutulur. **Mağazadan kalıcı kur** düğmesi mağaza sayfasını seçilen tarayıcıda açar; bulunamazsa adresi kopyalar. Mağaza kurulumu kullanıcı onayı gerektirir. Windows Chrome’da yerel imzalı CRX normal mağaza kurulumunun yerine geçmez. Geliştirme testi için eklentiler sayfasında geliştirici moduyla **browser-extension** klasörü yüklenebilir; bu kopyanın sabit geliştirme kimliği mağaza kimliği değildir.
- **Firefox / Zen:** kalıcı kurulum Mozilla imzalı XPI gerektirir. **Tarayıcı bağlantısı → Kalıcı kurulum rehberi**, imzaya hazır ZIP’i ve Mozilla hesabında yapılacak başvuru adımlarını açar. ZIP kalıcı kurulum dosyası değildir. Mozilla’dan alınan imzalı XPI, **about:addons → dişli menüsü → Dosyadan eklenti yükle** yoluyla yüklenir; tarayıcı yeniden başlatıldığında kalır. Kaynakta **assets/FullDownloadManager-Firefox.xpi** adıyla yerleştirilip EXE yeniden derlenirse kurulum yardımcısı paketi algılar. Tarayıcı imzayı doğrular. İmza denetimi kapatılmaz; geçici yükleme normal kurulum yöntemi olarak sunulmaz. Uzantı Firefox/Zen 140 ve üzerini destekler.
- **Diğer tarayıcılar:** açıkça seçilen **hizli-indir://** bağlantısı kurulur; **browser-link.html** üzerinden dosya bağlantısı uygulamaya gönderilebilir.

[Chrome dağıtım kuralları](https://developer.chrome.com/docs/extensions/how-to/distribute/install-extensions), [Firefox imza kuralları](https://extensionworkshop.com/documentation/publish/signing-and-distribution-overview/).

Zen/Firefox uzantısı GET gezinmelerindeki **Content-Disposition: attachment** yanıtlarını, tarayıcı indirmesi oluşmadan uygulamaya aktarır. Uygulama onay penceresi açılmazsa tarayıcı isteği devam eder. Diğer yakalanabilir indirmelerde ve Chromium’da uzantı indirmeyi duraklatır; uygulamanın onayından sonra tarayıcıdaki kopyayı iptal eder ve **yalnızca bu aktarımın** geçmiş kaydını siler. Diğer indirme geçmişine dokunmaz. Bu yedek yöntemde tarayıcı indirmesi kısa süreli görünebilir; kalıcı “İptal edildi” kaydı bırakılmaz. İptal veya geçmiş temizleme başarısız olursa uzantı hata rozeti gösterir. Sağ tık menüsü doğrudan aktarım sağlar. Eklenti penceresinde yakalamayı kapatabilir ve eklenti dilini seçebilirsiniz.

Oturum çerezleri, özel HTTP başlıkları, POST indirmeleri, blob/data kaynakları ve DRM video akışları aktarılmaz. Bu kaynaklarda tarayıcıyla indirmeyi kullanın. Çok küçük dosyalar yakalanmadan tamamlanabilir.

### Kaynak koddan elle kurulum

Windows'ta **Baslat.vbs** kaynak konumundan otomatik bileşen kurulumunu ve terminalsiz açılışı sağlar. **Baslat.bat** aynı başlatıcıya yönlendirir.

Tarayıcı kaydını elle oluşturmak için:

~~~powershell
py -3 setup_browser.py --browser firefox
py -3 setup_browser.py --browser chrome --extension-id EKLENTI_KIMLIGI
~~~

Kaldırmak için ilgili tarayıcıyla **--remove** kullanın. Protokol kaydı için **setup_protocol.py**, kaldırmak için aynı betikle **--remove** kullanılabilir.

### Linux / macOS

Python 3.10+, Tkinter ve PATH'te aria2c gerekir. Debian/Ubuntu: **sudo apt install python3 python3-tk aria2**. macOS/Homebrew: **brew install python@3.12 python-tk@3.12 aria2**. Ardından **python3 app.py** veya seçilen Python sürümüyle çalıştırın. Kaynak kod bu sistemlerde çalışacak şekilde tutulur; son GUI ve EXE doğrulaması Windows'ta yapıldı.

## Geliştirme ve doğrulama

Windows'un .NET Framework C# derleyicisiyle EXE oluşturulur; ek derleyici veya Python paketi indirmesi gerekmez:

~~~powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File installer/build.ps1
~~~

Testler yerel HTTP sunucusunda gerçek motoru kullanır. Oturum geri yükleme, eski hız sınırlarının kaldırılması, dosya bütünlüğü, paralel aktarım, Range desteği olmayan sunucu, tarayıcı aktarımı, iki dilde ayarlar ve arayüz kontrolleri sınanır:

~~~powershell
py -3.13 -m unittest discover -s tests -v
node tests/test_extension.cjs
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests/test_windows_setup.ps1
~~~

GUI olmayan bir ortamda GUI testlerini açıkça atlamak için **FDM_SKIP_GUI=1** kullanılabilir; gerçek motor testleri aria2 bulunamazsa atlanır. Tarayıcı API testleri taklit API kullanır; gerçek tarayıcı eklentilerinin uçtan uca yüklenmesi bu testlerin kapsamı dışındadır.

## Sorun giderme

- Kurulum: **%LOCALAPPDATA%\Full Download Manager\setup.log**.
- Beklenmeyen açılış hatası: **%USERPROFILE%\.hizli-indir\startup.log**.
- Motor günlüğü: **%USERPROFILE%\.hizli-indir\engine.log**.
- Ayarlar: aynı dizindeki **settings.json**. Eski oturum ve tarayıcı kayıtları uyumluluk için aynı dizinde kalır.
- Süresi dolan dosya bağlantılarında kaynaktan yeni bağlantı alın.
- Hata durumundaki dosyalar karttaki **Yeniden dene** ile tekrar kuyruğa eklenebilir.

aria2 ayrı bir projedir ve kendi lisansına tabidir.

