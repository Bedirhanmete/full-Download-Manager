"""Native-messaging framing and a short-lived, local desktop request queue."""
import contextlib
import json
import os
from pathlib import Path
import struct
import time
import uuid
from app import valid_url

HOST = 'com.hizliindir.bridge'
MAX_MESSAGE = 65536


def read_message(stream):
    header = stream.read(4)
    if not header:
        return None
    if len(header) != 4:
        raise ValueError('Eksik mesaj başlığı.')
    size = struct.unpack('<I', header)[0]
    if not 0 < size <= MAX_MESSAGE:
        raise ValueError('Mesaj boyutu geçersiz.')
    data = stream.read(size)
    if len(data) != size:
        raise ValueError('Eksik mesaj.')
    return json.loads(data)


def write_message(stream, value):
    data = json.dumps(value, ensure_ascii=False).encode('utf-8')
    stream.write(struct.pack('<I', len(data)) + data)
    stream.flush()


def validate_request(value):
    if not isinstance(value, dict) or value.get('action') != 'download':
        raise ValueError('Geçersiz istek.')
    url = value.get('url')
    if not isinstance(url, str) or len(url) > 16000:
        raise ValueError('Bağlantı geçersiz veya çok uzun.')
    valid_url(url)
    return {'url': url}


@contextlib.contextmanager
def file_lock(path, blocking=True):
    path.parent.mkdir(parents=True, exist_ok=True)
    file = open(path, 'a+b')
    try:
        if os.name == 'nt':
            import msvcrt
            file.seek(0)
            file.write(b'0')
            file.flush()
            file.seek(0)
            msvcrt.locking(file.fileno(), msvcrt.LK_LOCK if blocking else msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(file, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        yield
    finally:
        file.close()


def running(data):
    try:
        with file_lock(data / 'app.lock', blocking=False):
            return False
    except OSError:
        return True


def deliver(value, data, launch, timeout=15):
    request = validate_request(value)
    inbox = data / 'inbox'
    inbox.mkdir(parents=True, exist_ok=True)
    # Serialize startup: multiple simultaneous browser downloads launch one desktop.
    with file_lock(data / 'launch.lock'):
        identity = uuid.uuid4().hex
        pending = inbox / (identity + '.json')
        receipt = inbox / (identity + '.ack')
        request['expires'] = time.time() + timeout
        temp = pending.with_suffix('.tmp')
        temp.write_text(json.dumps(request), encoding='utf-8')
        temp.replace(pending)
        try:
            if not running(data):
                launch()
            until = time.monotonic() + timeout
            while time.monotonic() < until:
                if receipt.exists():
                    return {'ok': True}
                time.sleep(.1)
            if receipt.exists():
                return {'ok': True}
            raise RuntimeError('Uygulama penceresi açılamadı. Python, Tkinter ve aria2 kurulumunu kontrol edin.')
        finally:
            pending.unlink(missing_ok=True)
            receipt.unlink(missing_ok=True)


def receive_requests(data, show):
    inbox = data / 'inbox'
    for pending in sorted(inbox.glob('*.json'))[:10]:
        try:
            value = json.loads(pending.read_text(encoding='utf-8'))
            request = validate_request({'action': 'download', **value})
            if value.get('expires', 0) < time.time():
                continue
            show(request['url'])
            pending.with_suffix('.ack').touch()
        except (ValueError, OSError):
            pass
        finally:
            pending.unlink(missing_ok=True)
