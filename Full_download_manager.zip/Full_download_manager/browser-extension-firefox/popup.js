const api = typeof browser === "undefined" ? chrome : browser;
const checkbox = document.getElementById('enabled');
const language = document.getElementById('language');
let lastCapture = null;
let siteAccess = null;
let build = api.runtime.getManifest().version;
const origins = api.runtime.getManifest().host_permissions || [];
const grant = document.getElementById('grant-access');
function renderDiagnostics(lang) {
  const tr = lang === 'tr';
  document.getElementById('build').textContent = build;
  const routes = {
    'link-click': tr ? 'Tıklama anında, indirme oluşmadan' : 'Link click, before browser download',
    'response-before-download': tr ? 'Yanıt başlığında, indirme oluşmadan' : 'Response headers, before browser download',
    'download-fallback': tr ? 'Tarayıcı indirmesi oluştuktan sonra (yedek yöntem)' : 'After browser download creation (fallback)',
    'context-menu': tr ? 'Sağ tık menüsü' : 'Context menu'
  };
  document.getElementById('capture-route').textContent = lastCapture
    ? (tr ? 'Son aktarım: ' : 'Last handoff: ') + (routes[lastCapture.route] || lastCapture.route)
    : (tr ? 'Henüz aktarım yapılmadı.' : 'No handoff yet.');
  document.getElementById('site-access').textContent = siteAccess === null ? '' : siteAccess
    ? (tr ? 'Site erişimi açık. Yeni yüklediyseniz indirme sayfasını yenileyin.' : 'Site access enabled. Reload the download page after updating.')
    : (tr ? 'Site erişimi kapalı: indirme oluşmadan yakalama çalışamaz.' : 'Site access missing: capture before download cannot run.');
  grant.hidden = siteAccess !== false;
  grant.textContent = tr ? 'Web sitelerinde yakalamayı etkinleştir' : 'Enable capture on websites';
}
function render(lang) {
  document.documentElement.lang = lang;
  const tr = lang === 'tr';
  document.getElementById('enabled-text').textContent = tr ? 'İndirmeleri uygulamada aç' : 'Open downloads in the app';
  document.getElementById('help').textContent = tr
    ? 'Yakalanan bağlantı ana ekranda bekler. İndirmek için uygulamadaki İndir düğmesine basın.'
    : 'Captured links wait on the main screen. Press Download in the app to start.';
  document.getElementById('context-help').textContent = tr
    ? 'Bağlantıya sağ tıklayarak Full Download Manager ile indir seçeneğini de kullanabilirsiniz.'
    : 'You can also right-click a link and select Download with Full Download Manager.';
  document.getElementById('ui-help').textContent = typeof api.downloads?.setUiOptions === 'function'
    ? (tr ? 'Yakalama açıkken tarayıcının indirme paneli gizlenir. Yakalamayı kapattığınızda veya aktarım başarısız olduğunda panel geri açılır.'
          : 'While capture is enabled, the browser download panel is hidden. Disabling capture or a failed handoff restores the panel.')
    : '';
  renderDiagnostics(lang);
}
const defaultLanguage = navigator.language.toLowerCase().startsWith('tr') ? 'tr' : 'en';
api.storage.local.get({enabled: true, lastError: '', lastCapture: null, language: defaultLanguage}).then(values => {
  lastCapture = values.lastCapture;
  checkbox.checked = values.enabled;
  language.value = values.language;
  render(values.language);
  document.getElementById('error').textContent = values.lastError;
});
api.runtime.sendMessage({action: 'capture-diagnostics'}).then(value => {
  if (value?.build) build = value.build;
  renderDiagnostics(language.value || defaultLanguage);
}).catch(() => {});
if (origins.length && api.permissions) {
  api.permissions.contains({origins}).then(value => {
    siteAccess = value;
    renderDiagnostics(language.value || defaultLanguage);
  }).catch(() => {});
}
grant.addEventListener('click', () => {
  api.permissions.request({origins}).then(value => {
    siteAccess = value;
    renderDiagnostics(language.value || defaultLanguage);
  }).catch(error => {document.getElementById('error').textContent = error.message;});
});
checkbox.addEventListener('change', () => api.storage.local.set({enabled: checkbox.checked}));
language.addEventListener('change', () => {
  render(language.value);
  api.storage.local.set({language: language.value});
});

