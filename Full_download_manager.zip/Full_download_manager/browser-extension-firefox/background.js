const api = typeof browser === "undefined" ? chrome : browser;
const HOST = 'com.hizliindir.bridge';
const MENU = 'hizli-indir-link';
const BUILD = '1.3.0 / ZEN-02';
const freshTabs = new Map();
const acknowledgedDownloads = new Map();

async function cleanTransferredDownload(id) {
  if ((acknowledgedDownloads.get(id) || 0) < Date.now()) return;
  try {
    // Do not erase a copy the user has explicitly restarted in the browser.
    if (typeof api.downloads.search === 'function') {
      const [item] = await api.downloads.search({id});
      if (item?.state === 'in_progress') return;
    }
    await api.downloads.erase({id});
  } catch (error) {
    await report(`Aktarım tamamlandı; tarayıcı kaydı temizlenemedi: ${error.message}`);
  }
}

api.downloads.onChanged?.addListener(delta => {
  // Firefox/Zen may publish the final cancellation after cancel() resolves.
  // Erasing only once before that event can leave a late "Cancelled" entry.
  if (delta.state?.current === 'interrupted' && acknowledgedDownloads.has(delta.id)) {
    cleanTransferredDownload(delta.id).catch(() => {});
  }
});
// Only a newly opened, still blank child tab can be a disposable download tab.
// Existing pages, pinned tabs and tabs with a committed page are never closed.
if (api.tabs) {
  api.tabs.onCreated.addListener(tab => {
    for (const [id, value] of freshTabs) {
      if (Date.now() - value.created > 30000) freshTabs.delete(id);
    }
    if (tab.openerTabId !== undefined && !tab.pinned) {
      freshTabs.set(tab.id, {created: Date.now(), url: tab.pendingUrl || tab.url || '', committed: false});
    }
  });
  api.tabs.onUpdated.addListener((id, changes, tab) => {
    const value = freshTabs.get(id);
    if (value && changes.status === 'complete' && supported(changes.url || tab?.url)) value.committed = true;
  });
  api.tabs.onRemoved.addListener(id => freshTabs.delete(id));
}

async function closeDownloadTab(tabId, urls) {
  if (!api.tabs) return;
  const candidates = Number.isInteger(tabId) && tabId >= 0 ? [tabId] :
    [...freshTabs.keys()].filter(id => urls.includes(freshTabs.get(id).url));
  for (const id of candidates) {
    const value = freshTabs.get(id);
    if (!value || value.committed || Date.now() - value.created > 30000) continue;
    try {
      const tab = await api.tabs.get(id);
      if (tab.pinned || tab.openerTabId === undefined || tab.url !== 'about:blank') continue;
      // A user may already have navigated away while native messaging was pending.
      if (tab.pendingUrl && !urls.includes(tab.pendingUrl) && tab.pendingUrl !== 'about:blank') continue;
      await api.tabs.remove(id);
      freshTabs.delete(id);
    } catch {} // Closing a cosmetic tab must never cause a duplicate handoff.
  }
}

// This controls browser-wide download UI, not its security checks or downloads.
// Restore the UI when capture is disabled or a handoff falls back to the browser.
async function syncDownloadUI(captureEnabled) {
  if (typeof api.downloads.setUiOptions !== 'function') return;
  if (captureEnabled === undefined) {
    const values = await api.storage.local.get('enabled');
    captureEnabled = values.enabled !== false;
  }
  await api.downloads.setUiOptions({enabled: !captureEnabled});
}
function updateDownloadUI(value) {
  return syncDownloadUI(value).catch(() => {});
}

function supported(url) {
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol) && !parsed.username && !parsed.password;
  } catch { return false; }
}

async function report(error) {
  await api.storage.local.set({lastError: String(error)});
  await api.action.setBadgeText({text: '!'});
  await api.action.setBadgeBackgroundColor({color: '#b42318'});
}

async function send(url, route = 'context-menu') {
  const response = await api.runtime.sendNativeMessage(HOST, {action: 'download', url});
  if (!response?.ok) throw new Error(response?.error || 'Uygulamaya bağlanılamadı.');
  // Cosmetic failures must not turn an acknowledged transfer into a retry.
  try {
    await api.storage.local.set({lastError: '', lastCapture: {build: BUILD, route, at: Date.now()}});
    await api.action.setBadgeText({text: ''});
  } catch {}
}

async function capture(item) {
  const {enabled = true} = await api.storage.local.get('enabled');
  const url = item.finalUrl || item.url;
  if (!enabled || !supported(url) || item.state !== 'in_progress') {
    await updateDownloadUI(false);
    return;
  }
  await updateDownloadUI(true);
  let paused = false;
  let handedOff = false;
  try {
    // Keep the browser entry until the desktop acknowledges its main screen.
    await api.downloads.pause(item.id);
    paused = true;
    await send(url, 'download-fallback');
    handedOff = true;
    for (const [id, expires] of acknowledgedDownloads) {
      if (expires < Date.now()) acknowledgedDownloads.delete(id);
    }
    acknowledgedDownloads.set(item.id, Date.now() + 5000);
    await api.downloads.cancel(item.id);
    // Remove only this acknowledged handoff, never other browser history.
    await cleanTransferredDownload(item.id);
    await closeDownloadTab(item.tabId, [item.url, item.finalUrl].filter(Boolean));
  } catch (error) {
    if (handedOff) {
      await updateDownloadUI(false);
      await report('Uygulama penceresi açıldı. Tarayıcıdaki duraklatılmış kopyayı İndirilenler sayfasından iptal edin.');
      return;
    }
    await updateDownloadUI(false);
    if (paused) {
      try { await api.downloads.resume(item.id); }
      catch { error = new Error(`${error.message} Tarayıcı indirmesini İndirilenler sayfasından yeniden başlatın.`); }
    }
    await report(error.message);
  }
}

api.runtime.onInstalled.addListener(async () => {
  await updateDownloadUI();
  await api.contextMenus.removeAll();
  await api.contextMenus.create({id: MENU, title: 'Full Download Manager ile indir', contexts: ['link'],
                               targetUrlPatterns: ['http://*/*', 'https://*/*']});
});
api.contextMenus.onClicked.addListener(async info => {
  if (info.menuItemId !== MENU || !supported(info.linkUrl)) return;
  try { await send(info.linkUrl); } catch (error) { await report(error.message); }
});
api.downloads.onCreated.addListener(item => { capture(item).catch(error => report(error.message)); });
api.runtime.onStartup.addListener(() => { updateDownloadUI(); });
api.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.enabled) updateDownloadUI(changes.enabled.newValue !== false);
});
// Chromium MV3 cannot asynchronously block a response like Firefox can.
// Capture explicit file-link clicks before a download/Save As dialog exists.
api.runtime.onMessage?.addListener((message, sender, respond) => {
  if (message?.action === 'capture-diagnostics' && sender.id === api.runtime.id) {
    respond({build: BUILD});
    return false;
  }
  if (message?.action !== 'capture-link' || sender.id !== api.runtime.id || !sender.tab ||
      !supported(message.url)) return false;
  (async () => {
    const {enabled = true} = await api.storage.local.get('enabled');
    if (!enabled) return {ok: false};
    await updateDownloadUI(true);
    try { await send(message.url, 'link-click'); return {ok: true}; }
    catch (error) { await updateDownloadUI(false); await report(error.message); return {ok: false}; }
  })().then(respond, () => respond({ok: false}));
  return true;
});
updateDownloadUI();
