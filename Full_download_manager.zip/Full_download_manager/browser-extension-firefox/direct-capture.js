// Firefox supports asynchronous blocking before the download UI is created.
// Capture before a browser DownloadItem exists, including binary responses that
// omit Content-Disposition. Never capture page fetches, POSTs or inline media.
async function captureResponse(details) {
  if (details.method !== 'GET' || ![200, 206].includes(details.statusCode) || !supported(details.url)) return {};
  const disposition = (details.responseHeaders || []).find(header =>
    header.name.toLowerCase() === 'content-disposition');
  const attachment = /^\s*attachment(?:\s*;|\s*$)/i.test(disposition?.value || '');
  const contentType = (details.responseHeaders || []).find(header =>
    header.name.toLowerCase() === 'content-type')?.value || '';
  const binary = /^(?:application\/(?:octet-stream|x-msdownload|x-iso9660-image|zip|x-7z-compressed|x-rar-compressed))\s*(?:;|$)/i.test(contentType);
  if (!attachment && (disposition || !binary)) return {};
  const {enabled = true} = await api.storage.local.get('enabled');
  if (!enabled) return {};
  try {
    await send(details.url, 'response-before-download');
    // Return cancellation first; then remove only a fresh blank download tab.
    setTimeout(() => closeDownloadTab(details.tabId, [details.url]), 150);
    return {cancel: true};
  } catch (error) {
    try { await report(error.message); } catch {}
    return {}; // No acknowledgement: let the browser download normally.
  }
}

api.webRequest.onHeadersReceived.addListener(captureResponse,
  {urls: ['http://*/*', 'https://*/*'], types: ['main_frame', 'sub_frame', 'other']},
  ['blocking', 'responseHeaders']);
