(() => {
  const api = typeof browser === 'undefined' ? chrome : browser;
  const files = /\.(?:iso|img|zip|7z|rar|tar|gz|bz2|xz|exe|msi|msix|dmg|pkg|deb|rpm|mp4|mkv|mp3|flac|wav)$/i;
  let enabled = true;
  let replay = null;
  const pending = new Set();
  api.storage.local.get('enabled').then(values => { enabled = values.enabled !== false; }).catch(() => {});
  api.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.enabled) enabled = changes.enabled.newValue !== false;
  });
  document.addEventListener('click', event => {
    if (!enabled || !event.isTrusted || event.defaultPrevented || event.button !== 0 || event.altKey ||
        event.ctrlKey || event.metaKey || event.shiftKey) return;
    const anchor = event.composedPath().find(node => node?.tagName === 'A' && node.href);
    if (!anchor || anchor === replay) return;
    let url;
    try { url = new URL(anchor.href); } catch { return; }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password ||
        (!anchor.hasAttribute('download') && !files.test(url.pathname))) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (pending.has(url.href)) return;
    pending.add(url.href);
    const fallback = () => {
      // Replay the original link, including its target/download attributes.
      // Our own listener skips exactly this synchronous replay.
      replay = anchor;
      try { anchor.click(); } finally { replay = null; }
    };
    let request;
    try { request = api.runtime.sendMessage({action: 'capture-link', url: url.href}); }
    catch { fallback(); pending.delete(url.href); return; }
    request
      .then(response => { if (!response?.ok) fallback(); }, fallback)
      .finally(() => pending.delete(url.href));
  }, true);
})();
