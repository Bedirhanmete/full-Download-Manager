"""Windows notification icon. Its message loop never calls Tk from a worker."""
import ctypes
from ctypes import wintypes as w
from pathlib import Path
import queue
import threading
import os


class WindowsTray:
    def __init__(self, language='tr'):
        self.language = language
        self.events = queue.SimpleQueue()
        self.ready = threading.Event()
        self.handle = None
        self.error = None
        self.thread = None

    def start(self):
        if os.name != 'nt':
            raise OSError('Windows notification area is unavailable')
        self.thread = threading.Thread(target=self._run, name='notification-icon', daemon=True)
        self.thread.start()
        if not self.ready.wait(3) or self.error:
            self.stop()
            raise OSError('Could not create notification icon') from self.error
        return self

    def stop(self):
        if self.handle:
            ctypes.windll.user32.PostMessageW(self.handle, 0x0010, 0, 0)
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=1)

    def _run(self):
        user, shell, kernel = ctypes.windll.user32, ctypes.windll.shell32, ctypes.windll.kernel32
        result_type = ctypes.c_ssize_t
        proc_type = ctypes.WINFUNCTYPE(result_type, w.HWND, w.UINT, w.WPARAM, w.LPARAM)

        class WindowClass(ctypes.Structure):
            _fields_ = [('style', w.UINT), ('proc', proc_type), ('class_extra', ctypes.c_int),
                        ('window_extra', ctypes.c_int), ('instance', w.HINSTANCE),
                        ('icon', w.HICON), ('cursor', w.HANDLE), ('background', w.HBRUSH),
                        ('menu', w.LPCWSTR), ('name', w.LPCWSTR)]

        class NotifyIcon(ctypes.Structure):
            _fields_ = [('size', w.DWORD), ('window', w.HWND), ('id', w.UINT),
                        ('flags', w.UINT), ('message', w.UINT), ('icon', w.HICON),
                        ('tip', w.WCHAR * 128), ('state', w.DWORD), ('state_mask', w.DWORD),
                        ('info', w.WCHAR * 256), ('version', w.UINT), ('info_title', w.WCHAR * 64),
                        ('info_flags', w.DWORD), ('guid', ctypes.c_byte * 16), ('balloon', w.HICON)]

        user.DefWindowProcW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
        user.DefWindowProcW.restype = result_type
        user.CreateWindowExW.argtypes = [w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.HWND, w.HMENU, w.HINSTANCE, w.LPVOID]
        user.CreateWindowExW.restype = w.HWND
        kernel.GetModuleHandleW.argtypes = [w.LPCWSTR]
        kernel.GetModuleHandleW.restype = w.HMODULE
        user.LoadImageW.argtypes = [w.HINSTANCE, w.LPCWSTR, w.UINT, ctypes.c_int, ctypes.c_int, w.UINT]
        user.LoadImageW.restype = w.HANDLE
        user.CreatePopupMenu.restype = w.HMENU
        user.AppendMenuW.argtypes = [w.HMENU, w.UINT, ctypes.c_size_t, w.LPCWSTR]
        user.TrackPopupMenu.argtypes = [w.HMENU, w.UINT, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, w.HWND, w.LPVOID]
        user.DestroyMenu.argtypes = [w.HMENU]
        user.SetForegroundWindow.argtypes = [w.HWND]
        user.DestroyWindow.argtypes = [w.HWND]
        user.IsWindow.argtypes = [w.HWND]
        user.GetMessageW.argtypes = [ctypes.POINTER(w.MSG), w.HWND, w.UINT, w.UINT]
        user.TranslateMessage.argtypes = [ctypes.POINTER(w.MSG)]
        user.DispatchMessageW.argtypes = [ctypes.POINTER(w.MSG)]
        user.DispatchMessageW.restype = result_type
        user.PostMessageW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
        user.DestroyIcon.argtypes = [w.HICON]
        user.RegisterClassW.argtypes = [ctypes.POINTER(WindowClass)]
        user.UnregisterClassW.argtypes = [w.LPCWSTR, w.HINSTANCE]
        shell.Shell_NotifyIconW.argtypes = [w.DWORD, ctypes.POINTER(NotifyIcon)]
        icon = None
        data = None
        instance = kernel.GetModuleHandleW(None)
        name = f'FullDownloadManagerTray-{os.getpid()}'
        taskbar_created = user.RegisterWindowMessageW('TaskbarCreated')

        @proc_type
        def window_proc(handle, message, first, second):
            if message == taskbar_created and data is not None:
                shell.Shell_NotifyIconW(0, ctypes.byref(data))
            elif message == 0x8001:
                if second in (0x0203, 0x0202):  # double click / left release
                    self.events.put('show')
                elif second in (0x0205, 0x007B):
                    menu = user.CreatePopupMenu()
                    try:
                        english = self.language == 'en'
                        user.AppendMenuW(menu, 0, 1, 'Open' if english else 'Aç')
                        user.AppendMenuW(menu, 0, 2, 'Exit' if english else 'Çıkış')
                        point = w.POINT()
                        user.GetCursorPos(ctypes.byref(point))
                        user.SetForegroundWindow(handle)
                        command = user.TrackPopupMenu(menu, 0x0102, point.x, point.y, 0, handle, None)
                        if command:
                            self.events.put('show' if command == 1 else 'exit')
                        user.PostMessageW(handle, 0, 0, 0)
                    finally:
                        user.DestroyMenu(menu)
            elif message == 0x0010:
                user.DestroyWindow(handle)
                return 0
            elif message == 0x0002:
                user.PostQuitMessage(0)
                return 0
            return user.DefWindowProcW(handle, message, first, second)

        klass = WindowClass(instance=instance, name=name, proc=window_proc)
        try:
            if not user.RegisterClassW(ctypes.byref(klass)):
                raise ctypes.WinError()
            self.handle = user.CreateWindowExW(0, name, name, 0, 0, 0, 0, 0, None, None, instance, None)
            if not self.handle:
                raise ctypes.WinError()
            path = str(Path(__file__).with_name('assets') / 'app.ico')
            icon = user.LoadImageW(None, path, 1, 0, 0, 0x0010 | 0x0040)
            if not icon:
                raise ctypes.WinError()
            data = NotifyIcon(size=ctypes.sizeof(NotifyIcon), window=self.handle, id=1,
                              flags=7, message=0x8001, icon=icon, tip='Full Download Manager')
            if not shell.Shell_NotifyIconW(0, ctypes.byref(data)):
                raise ctypes.WinError()
            self.ready.set()
            message = w.MSG()
            while user.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
                user.TranslateMessage(ctypes.byref(message))
                user.DispatchMessageW(ctypes.byref(message))
        except Exception as exc:
            self.error = exc
            self.ready.set()
        finally:
            if data is not None:
                shell.Shell_NotifyIconW(2, ctypes.byref(data))
            if self.handle and user.IsWindow(self.handle):
                user.DestroyWindow(self.handle)
            self.handle = None
            if icon:
                user.DestroyIcon(icon)
            user.UnregisterClassW(name, instance)
