﻿param([switch]$Quiet)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$allowed = @(
    [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Full Download Manager/app')).TrimEnd('\'),
    [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'HizliIndir/app')).TrimEnd('\')
)
$actual = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
if ($actual -notin $allowed) { throw 'Kaldırıcı yalnızca kurulu uygulama klasöründe çalıştırılabilir.' }
if (-not $Quiet) {
    $answer = [System.Windows.Forms.MessageBox]::Show('Full Download Manager kaldırılsın mı? İndirdiğiniz dosyalar ve kayıtlı oturumunuz korunur.', 'Full Download Manager', 'YesNo', 'Question')
    if ($answer -ne 'Yes') { exit 0 }
}
try {
    $lockPath = Join-Path $env:USERPROFILE '.hizli-indir/app.lock'
    if (Test-Path -LiteralPath $lockPath) {
        try { $lock = [IO.File]::Open($lockPath, 'Open', 'ReadWrite', 'None'); $lock.Dispose() }
        catch { throw 'Önce Full Download Manager uygulamasında Kaydet ve çık düğmesine basın.' }
    }
    $targets = @()
    foreach ($candidate in $allowed) {
        if (-not (Test-Path -LiteralPath $candidate)) { continue }
        $item = Get-Item -LiteralPath $candidate -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Uygulama klasörü bir bağlantı olamaz.' }
        $parent = Get-Item -LiteralPath (Split-Path $candidate -Parent) -Force
        if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Kurulum üst klasörü bir bağlantı olamaz.' }
        if (-not (Test-Path -LiteralPath (Join-Path $candidate 'FullDownloadManager.exe')) -or
            -not (Test-Path -LiteralPath (Join-Path $candidate 'windows_setup.ps1'))) { continue }
        $links = @(Get-ChildItem -LiteralPath $candidate -Force -Recurse | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })
        if ($links.Count -gt 0) { throw 'Uygulama klasöründe bağlantı bulundu; otomatik kaldırma durduruldu.' }
        $targets += $candidate
    }
    # Remove our optional store-download requests even if Python was removed.
    $requestsFile = Join-Path $env:USERPROFILE '.hizli-indir/extension-install-requests.json'
    if (Test-Path -LiteralPath $requestsFile) {
        $requests = @(Get-Content -LiteralPath $requestsFile -Raw -Encoding UTF8 | ConvertFrom-Json)
        foreach ($request in $requests) {
            if ($request.owner -notin $allowed -or $request.id -notmatch '^[a-p]{32}$') { continue }
            if ($request.provider -eq 'chrome') {
                $product = 'Google\Chrome'
                $update = 'https://clients2.google.com/service/update2/crx'
            } elseif ($request.provider -eq 'edge') {
                $product = 'Microsoft\Edge'
                $update = 'https://edge.microsoft.com/extensionwebstorebase/v1/crx'
            } else { continue }
            $key = 'HKCU:\Software\' + $product + '\Extensions\' + $request.id
            if (Test-Path -LiteralPath $key) {
                $registration = Get-ItemProperty -LiteralPath $key
                if ($registration.fdm_owner -eq $request.owner -and $registration.update_url -eq $update) {
                    Remove-Item -LiteralPath $key -Force
                }
            }
        }
    }
    . (Join-Path $actual 'windows_setup.ps1') -FunctionsOnly
    $python = Find-Python
    if ($python) {
        $result = Invoke-Hidden $python ('"' + (Join-Path $actual 'browser_setup.py') + '" --remove-installed')
        if ($result.ExitCode -ne 0) { throw $result.ErrorText }
    }
    $shell = New-Object -ComObject WScript.Shell
    foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
        if ([string]::IsNullOrWhiteSpace($folder) -or -not [IO.Directory]::Exists($folder)) { continue }
        foreach ($name in @('Full Download Manager.lnk', 'Full Download Manager Browser Integration.lnk', 'Hızlı İndir.lnk', 'Hızlı İndir Tarayıcı Bağlantısı.lnk')) {
            $link = Join-Path $folder $name
            if (Test-Path -LiteralPath $link) {
                $shortcut = $shell.CreateShortcut($link)
                if ($shortcut.WorkingDirectory -in $targets) { Remove-Item -LiteralPath $link -Force }
            }
        }
    }
    foreach ($name in @('FullDownloadManager', 'HizliIndir')) {
        $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\' + $name
        if (Test-Path -LiteralPath $key) {
            $registration = Get-ItemProperty -LiteralPath $key
            if ($registration.InstallLocation -in $targets) { Remove-Item -LiteralPath $key -Force }
        }
    }
    foreach ($target in $targets) {
        # Each absolute path was matched against the two exact install roots.
        Remove-Item -LiteralPath $target -Recurse -Force
    }
    if (-not $Quiet) { [void][System.Windows.Forms.MessageBox]::Show('Full Download Manager kaldırıldı. İndirmeleriniz ve ayarlarınız korundu.', 'Full Download Manager') }
} catch {
    if ($Quiet) { [Console]::Error.WriteLine($_.Exception.Message) }
    else { [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Kaldırılamadı', 'OK', 'Error') }
    exit 1
}
