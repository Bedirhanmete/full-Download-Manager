﻿# Windows PowerShell 5.1; launched invisibly by Baslat.vbs.
param([switch]$NoLaunch, [switch]$FunctionsOnly, [switch]$Headless, [switch]$ConfigureBrowser, [switch]$RegisterInstall, [switch]$BrowserHelp, [switch]$BrowserInstall, [ValidateSet('chrome','brave','edge','vivaldi','opera','chromium','firefox','zen')][string]$Browser)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$runtimeRoot = Join-Path $env:LOCALAPPDATA 'Full Download Manager'
$pythonRoot = Join-Path $runtimeRoot 'Python313'
$ariaRoot = Join-Path $runtimeRoot 'aria2'
$script:form = $null
$script:statusLabel = $null
if ($Headless) {
    # The EXE reads redirected PowerShell output as UTF-8.
    [Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
}

function Show-Status([string]$Text) {
    if ($Headless) { [Console]::WriteLine($Text); return }
    if (-not $script:form) {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        $script:form = New-Object System.Windows.Forms.Form
        $script:form.Text = 'Full Download Manager — Kurulum'
        $script:form.ClientSize = New-Object System.Drawing.Size(500, 145)
        $script:form.StartPosition = 'CenterScreen'
        $script:form.FormBorderStyle = 'FixedDialog'
        $script:form.MaximizeBox = $false
        $script:form.ControlBox = $false
        $script:statusLabel = New-Object System.Windows.Forms.Label
        $script:statusLabel.Location = New-Object System.Drawing.Point(20, 20)
        $script:statusLabel.Size = New-Object System.Drawing.Size(460, 65)
        $script:statusLabel.Font = New-Object System.Drawing.Font('Segoe UI', 10)
        $bar = New-Object System.Windows.Forms.ProgressBar
        $bar.Location = New-Object System.Drawing.Point(20, 100)
        $bar.Size = New-Object System.Drawing.Size(460, 20)
        $bar.Style = 'Marquee'
        $script:form.Controls.AddRange(@($script:statusLabel, $bar))
        $script:form.Show()
    }
    $script:statusLabel.Text = $Text
    [System.Windows.Forms.Application]::DoEvents()
}

function Set-ChildPythonEnvironment($Info) {
    $Info.EnvironmentVariables['PYTHONUTF8'] = '1'
    $Info.EnvironmentVariables['PYTHONIOENCODING'] = 'utf-8:strict'
    foreach ($name in @('PYTHONHOME', 'PYTHONPATH', 'TCL_LIBRARY', 'TK_LIBRARY')) {
        $Info.EnvironmentVariables.Remove($name)
    }
}

function Start-PythonWindow([string]$File, [string]$Arguments) {
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $File
    $info.Arguments = $Arguments
    $info.WorkingDirectory = $projectRoot
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    Set-ChildPythonEnvironment $info
    $process = [Diagnostics.Process]::Start($info)
    $process.Dispose()
}

function Invoke-Hidden([string]$File, [string]$Arguments, [int]$TimeoutSeconds = 900) {
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $File
    $info.Arguments = $Arguments
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.StandardOutputEncoding = [Text.Encoding]::UTF8
    $info.StandardErrorEncoding = [Text.Encoding]::UTF8
    # A redirected Python process otherwise uses the Windows locale (e.g.
    # cp1252), which cannot print Turkish letters such as U+011F.
    # Clean only the child environment; never edit the user's settings.
    Set-ChildPythonEnvironment $info
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $info
    try {
        [void]$process.Start()
        $output = $process.StandardOutput.ReadToEndAsync()
        $errors = $process.StandardError.ReadToEndAsync()
        $timer = [Diagnostics.Stopwatch]::StartNew()
        while (-not $process.WaitForExit(100)) {
            if ($script:form) { [System.Windows.Forms.Application]::DoEvents() }
            if ($timer.Elapsed.TotalSeconds -gt $TimeoutSeconds) {
                $process.Kill()
                throw "İşlem zaman aşımına uğradı: $File"
            }
        }
        return [pscustomobject]@{
            ExitCode = $process.ExitCode
            Output = $output.GetAwaiter().GetResult().Trim()
            ErrorText = $errors.GetAwaiter().GetResult().Trim()
        }
    } finally { $process.Dispose() }
}

function Save-PythonDiagnostic([string]$File, [string]$Detail) {
    $script:pythonDiagnostic = $File + ': ' + $Detail
    try {
        [void](New-Item -ItemType Directory -Path $runtimeRoot -Force)
        $stamp = [DateTime]::Now.ToString('s')
        Add-Content -LiteralPath (Join-Path $runtimeRoot 'python-validation.log') -Value ("[$stamp] " + $script:pythonDiagnostic) -Encoding UTF8
    } catch { } # Diagnostics must not mask the original validation failure.
}

function Test-Python([string]$File) {
    if (-not (Test-Path -LiteralPath $File -PathType Leaf)) {
        Save-PythonDiagnostic $File 'python.exe not found'
        return $false
    }
    if (-not (Test-Path -LiteralPath (Join-Path (Split-Path $File) 'pythonw.exe'))) {
        Save-PythonDiagnostic $File 'pythonw.exe not found'
        return $false
    }
    try {
        $result = Invoke-Hidden $File '-c "import sys, tkinter; assert sys.version_info >= (3, 10); r = tkinter.Tk(); r.withdraw(); r.destroy()"' 30
        if ($result.ExitCode -ne 0) {
            Save-PythonDiagnostic $File ("Exit $($result.ExitCode): " + $result.ErrorText)
        }
        return ($result.ExitCode -eq 0)
    } catch {
        Save-PythonDiagnostic $File $_.Exception.Message
        return $false
    }
}

function Find-Python {
    $privatePython = Join-Path $pythonRoot 'python.exe'
    if (Test-Python $privatePython) { return $privatePython }
    # Registry discovery avoids Windows Store aliases and console flashes.
    $candidates = @()
    $config = Join-Path $runtimeRoot 'python-path.txt'
    if (Test-Path -LiteralPath $config) {
        $cached = (Get-Content -LiteralPath $config -Raw -Encoding UTF8).Trim()
        if ($cached -and (Test-Python $cached)) { return $cached }
    }
    $legacyConfig = Join-Path $env:LOCALAPPDATA 'HizliIndir/python-path.txt'
    if (Test-Path -LiteralPath $legacyConfig) {
        $cached = (Get-Content -LiteralPath $legacyConfig -Raw -Encoding UTF8).Trim()
        if ($cached -and (Test-Python $cached)) { return $cached }
    }
    foreach ($key in @('HKCU:\Software\Python\PythonCore', 'HKLM:\Software\Python\PythonCore', 'HKLM:\Software\WOW6432Node\Python\PythonCore')) {
        if (Test-Path $key) {
            foreach ($version in Get-ChildItem $key) {
                $installKey = Join-Path $version.PSPath 'InstallPath'
                if (Test-Path $installKey) {
                    $path = (Get-Item $installKey).GetValue('')
                    if ($path) { $candidates += Join-Path $path 'python.exe' }
                }
            }
        }
    }
    $command = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($command -and $command.Source -notlike '*\WindowsApps\*') { $candidates += $command.Source }
    # Installers can reuse a standard per-user location rather than TargetDir.
    $standardRoot = Join-Path $env:LOCALAPPDATA 'Programs/Python'
    if (Test-Path -LiteralPath $standardRoot) {
        foreach ($directory in Get-ChildItem -LiteralPath $standardRoot -Directory -Filter 'Python*') {
            $candidates += Join-Path $directory.FullName 'python.exe'
        }
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Test-Python $candidate) { return $candidate }
    }
    return $null
}

function Receive-File([string]$Url, [string]$Destination) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    # Download asynchronously to keep the progress window responsive.
    $client = New-Object Net.WebClient
    try {
        $task = $client.DownloadFileTaskAsync([uri]$Url, $Destination)
        $timer = [Diagnostics.Stopwatch]::StartNew()
        while (-not $task.IsCompleted) {
            if ($script:form) { [System.Windows.Forms.Application]::DoEvents() }
            if ($timer.Elapsed.TotalMinutes -gt 15) {
                $client.CancelAsync()
                throw 'İndirme zaman aşımına uğradı. İnternet bağlantınızı kontrol edip yeniden deneyin.'
            }
            Start-Sleep -Milliseconds 100
        }
        $task.GetAwaiter().GetResult()
    } finally { $client.Dispose() }
}

function Resolve-InstalledPython {
    $candidate = Join-Path $pythonRoot 'python.exe'
    if (Test-Python $candidate) { return $candidate }
    return (Find-Python)
}

function Install-Python {
    Show-Status "Python ve Tkinter indiriliyor…`r`nİlk kurulum birkaç dakika sürebilir."
    $installer = Join-Path $runtimeRoot 'python-installer.exe'
    $architecture = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') {
        'arm64'
    } elseif ([Environment]::Is64BitOperatingSystem) { 'amd64' } else { 'win32' }
    $suffix = if ($architecture -eq 'win32') { '' } else { "-$architecture" }
    Receive-File "https://www.python.org/ftp/python/3.13.16/python-3.13.16$suffix.exe" $installer
    $signature = Get-AuthenticodeSignature -LiteralPath $installer
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
        throw 'Python kurulum dosyasının yayıncı imzası doğrulanamadı.'
    }
    Show-Status 'Python ve Tkinter kuruluyor…'
    $installLog = Join-Path $runtimeRoot 'python-install.log'
    $arguments = '/quiet /log "' + $installLog + '" InstallAllUsers=0 Include_launcher=0 Include_test=0 Include_doc=0 Include_pip=0 Include_tcltk=1 PrependPath=0 Shortcuts=0 TargetDir="' + $pythonRoot + '"'
    $result = Invoke-Hidden $installer $arguments
    if ($result.ExitCode -notin @(0, 3010)) {
        throw "Python kurulamadı (kod: $($result.ExitCode)). $($result.ErrorText)"
    }
    # An existing Python of the same version may have been updated in place.
    $python = Resolve-InstalledPython
    if (-not $python) {
        Show-Status 'Python/Tkinter dosyaları onarılıyor…'
        $repairLog = Join-Path $runtimeRoot 'python-repair.log'
        $repairArguments = '/repair /quiet /log "' + $repairLog + '" InstallAllUsers=0 Include_tcltk=1'
        $repair = Invoke-Hidden $installer $repairArguments
        if ($repair.ExitCode -in @(0, 3010)) {
            $python = Resolve-InstalledPython
        } else {
            Save-PythonDiagnostic $installer ("Repair exit $($repair.ExitCode): " + $repair.ErrorText)
        }
    }
    if (-not $python) {
        $validationLog = Join-Path $runtimeRoot 'python-validation.log'
        $detail = $script:pythonDiagnostic
        throw "Python/Tkinter doğrulanamadı. $detail`r`nAyrıntılar: $validationLog`r`nPython kurulum günlüğü: $installLog`r`nOnarım günlüğü: $repairLog"
    }
    Remove-Item -LiteralPath $installer -Force
    return $python
}

function Find-Aria {
    $bundled = Join-Path $projectRoot 'assets/aria2-32/aria2c.exe'
    if ([Environment]::Is64BitOperatingSystem -and (Test-Path -LiteralPath $bundled -PathType Leaf)) {
        if ((Get-FileHash -LiteralPath $bundled -Algorithm SHA256).Hash -ne '0274F7176F8613E8BA7A4BE57BB0E2B49F7004660484C825C86C9EDB51A8CDF6') {
            throw 'Paket içindeki indirme motorunun bütünlüğü doğrulanamadı. Kurulumu yeniden çalıştırın.'
        }
        $result = Invoke-Hidden $bundled '--version' 15
        if ($result.ExitCode -eq 0) { return $bundled }
    }
    $privateAria = Join-Path $ariaRoot 'aria2c.exe'
    $candidates = @($privateAria, (Join-Path $env:LOCALAPPDATA 'HizliIndir/aria2/aria2c.exe'))
    $command = Get-Command aria2c.exe -ErrorAction SilentlyContinue
    if ($command) { $candidates += $command.Source }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            try {
                $result = Invoke-Hidden $candidate '--version' 15
                if ($result.ExitCode -eq 0) { return $candidate }
            } catch {}
        }
    }
    return $null
}

function Install-Aria {
    Show-Status 'aria2 indirme motoru indiriliyor…'
    # Official release; hashes pinned from Microsoft's winget manifest.
    if ([Environment]::Is64BitOperatingSystem) {
        $bits = '64'
        $expected = '67D015301EEF0B612191212D564C5BB0A14B5B9C4796B76454276A4D28D9B288'
    } else {
        $bits = '32'
        $expected = '35F6514CC5DD7E98A87B3C4C2D25A0754B9B063DBE59BC0F22D483464F61E5B6'
    }
    $name = "aria2-1.37.0-win-${bits}bit-build1"
    $archive = Join-Path $runtimeRoot 'aria2.zip'
    Receive-File "https://github.com/aria2/aria2/releases/download/release-1.37.0/$name.zip" $archive
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne $expected) {
        throw 'aria2 dosyasının bütünlüğü doğrulanamadı. Yeniden deneyin.'
    }
    Show-Status 'İndirme motoru hazırlanıyor…'
    $staging = Join-Path $runtimeRoot ('unpack-' + [guid]::NewGuid().ToString('N'))
    try {
        Expand-Archive -LiteralPath $archive -DestinationPath $staging
        $source = Join-Path $staging $name
        [void](New-Item -ItemType Directory -Path $ariaRoot -Force)
        Get-ChildItem -LiteralPath $source | Copy-Item -Destination $ariaRoot -Recurse -Force
    } finally {
        # Delete only the unique staging folder we just created.
        if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
    }
    if (-not (Find-Aria)) { throw 'aria2 motoru çalıştırılamadı.' }
    Remove-Item -LiteralPath $archive -Force
}

function Save-Shortcuts {
    $shell = New-Object -ComObject WScript.Shell
    $launcher = Join-Path $projectRoot 'FullDownloadManager.exe'
    foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
        if (-not $folder) { continue }
        $shortcut = $shell.CreateShortcut((Join-Path $folder 'Full Download Manager.lnk'))
        if (Test-Path -LiteralPath $launcher) {
            $shortcut.TargetPath = $launcher
            $shortcut.Arguments = ''
            $shortcut.IconLocation = "$launcher,0"
            $icon = Join-Path $projectRoot 'assets/app.ico'
            if (Test-Path -LiteralPath $icon) { $shortcut.IconLocation = "$icon,0" }
        } else {
            $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
            $shortcut.Arguments = '"' + (Join-Path $projectRoot 'Baslat.vbs') + '"'
        }
        $shortcut.WorkingDirectory = $projectRoot
        $shortcut.Description = 'Full Download Manager'
        $shortcut.WindowStyle = 1
        $shortcut.Save()
    }
    # Remove only legacy shortcuts owned by the application being upgraded.
    foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
        foreach ($name in @('Hızlı İndir.lnk', 'Hızlı İndir Tarayıcı Bağlantısı.lnk')) {
            $legacy = Join-Path $folder $name
            if (Test-Path -LiteralPath $legacy) {
                $old = $shell.CreateShortcut($legacy)
                if ($old.WorkingDirectory -eq $projectRoot) {
                    Remove-Item -LiteralPath $legacy -Force
                }
            }
        }
    }
    if (Test-Path -LiteralPath $launcher) {
        $folder = [Environment]::GetFolderPath('Programs')
        $help = $shell.CreateShortcut((Join-Path $folder 'Full Download Manager Browser Integration.lnk'))
        $help.TargetPath = $launcher
        $help.Arguments = '--browser-help'
        $help.WorkingDirectory = $projectRoot
        $help.Save()
    }
}

function Register-Installation {
    $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\FullDownloadManager'
    [void](New-Item -Path $key -Force)
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $uninstaller = Join-Path $projectRoot 'FullDownloadManager-Uninstall.exe'
    $uninstall = '"' + $uninstaller + '"'
    $values = @{
        DisplayName = 'Full Download Manager'; DisplayVersion = '1.3.0'; Publisher = 'Full Download Manager';
        InstallLocation = $projectRoot; DisplayIcon = (Join-Path $projectRoot 'FullDownloadManager.exe');
        UninstallString = $uninstall; QuietUninstallString = "$uninstall --quiet"
    }
    foreach ($name in $values.Keys) {
        [void](New-ItemProperty -Path $key -Name $name -Value $values[$name] -PropertyType String -Force)
    }
    foreach ($name in @('NoModify', 'NoRepair')) {
        [void](New-ItemProperty -Path $key -Name $name -Value 1 -PropertyType DWord -Force)
    }
    $legacyKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\HizliIndir'
    if (Test-Path -LiteralPath $legacyKey) {
        $legacy = Get-ItemProperty -LiteralPath $legacyKey
        $legacyApp = Join-Path $env:LOCALAPPDATA 'HizliIndir/app'
        if ($legacy.InstallLocation -eq $legacyApp) { Remove-Item -LiteralPath $legacyKey -Force }
    }
}


if ($FunctionsOnly) { return }
$mutex = New-Object Threading.Mutex($false, 'Local\HizliIndirSetup')
$ownsMutex = $false
try {
    try { $ownsMutex = $mutex.WaitOne(60000) }
    catch [System.Threading.AbandonedMutexException] { $ownsMutex = $true }
    if (-not $ownsMutex) { throw 'Diğer kurulum işlemi henüz tamamlanmadı. Biraz sonra tekrar deneyin.' }
    [void](New-Item -ItemType Directory -Path $runtimeRoot -Force)
    $python = Find-Python
    if (-not $python) { $python = Install-Python }
    if (-not (Find-Aria)) { Install-Aria }
    # Persist only a working interpreter, with atomic replacement.
    $config = Join-Path $runtimeRoot 'python-path.txt'
    Set-Content -LiteralPath "$config.tmp" -Value $python -Encoding UTF8
    Move-Item -LiteralPath "$config.tmp" -Destination $config -Force
    Save-Shortcuts
    if ($RegisterInstall) { Register-Installation }
    if ($ConfigureBrowser) {
        Show-Status 'Tarayıcı bağlantısı hazırlanıyor…'
        $browserArgument = if ($Browser) { ' --browser ' + $Browser } else { '' }
        $result = Invoke-Hidden $python ('"' + (Join-Path $projectRoot 'browser_setup.py') + '"' + $browserArgument)
        if ($result.ExitCode -ne 0) { throw $result.ErrorText }
        if ($Headless) { [Console]::WriteLine($result.Output) }
    }
    if ($BrowserInstall) {
        $pythonw = Join-Path (Split-Path $python) 'pythonw.exe'
        $browserArgument = if ($Browser) { ' --browser ' + $Browser } else { '' }
        Start-PythonWindow $pythonw ('"' + (Join-Path $projectRoot 'browser_setup.py') + '" --install-extension' + $browserArgument)
        $NoLaunch = $true
    } elseif ($BrowserHelp) {
        $pythonw = Join-Path (Split-Path $python) 'pythonw.exe'
        Start-PythonWindow $pythonw ('"' + (Join-Path $projectRoot 'browser_setup.py') + '" --guide')
        $NoLaunch = $true
    }
    if (-not $NoLaunch) {
        $pythonw = Join-Path (Split-Path $python) 'pythonw.exe'
        Start-PythonWindow $pythonw ('"' + (Join-Path $projectRoot 'app_start.pyw') + '"')
    }
} catch {
    $message = $_.Exception.Message
    try {
        $_ | Out-String | Add-Content -LiteralPath (Join-Path $runtimeRoot 'setup.log') -Encoding UTF8
    } catch {}
    if ($Headless) { [Console]::Error.WriteLine($message); exit 1 }
    Add-Type -AssemblyName System.Windows.Forms
    [void][System.Windows.Forms.MessageBox]::Show(
        "Kurulum tamamlanamadı.`r`n`r`n$message`r`n`r`nİnternet bağlantınızı kontrol edip Baslat.vbs dosyasını yeniden açın.`r`nGünlük: $runtimeRoot\setup.log",
        'Full Download Manager', 'OK', 'Error')
    exit 1
} finally {
    if ($script:form) { $script:form.Dispose() }
    if ($ownsMutex) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
