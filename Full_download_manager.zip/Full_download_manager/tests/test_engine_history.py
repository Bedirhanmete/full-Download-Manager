import unittest
from unittest.mock import Mock, call

from app import Engine, RpcError


class HistoryTests(unittest.TestCase):
    def test_only_terminal_records_are_forgotten_without_file_deletion(self):
        engine = object.__new__(Engine)
        engine.files = Mock()
        records = [{'gid':status,'status':status} for status in
                   ('complete','error','removed','active','waiting','paused')]
        engine.call = Mock(side_effect=lambda method,*_: records if method == 'tellStopped' else 'OK')
        self.assertEqual(engine.clear_history(), 3)
        self.assertEqual(engine.call.call_args_list, [call('tellStopped',0,1000),
            call('removeDownloadResult','complete'),call('removeDownloadResult','error'),
            call('removeDownloadResult','removed'),call('saveSession')])
        self.assertEqual(engine.files.method_calls, [call.forget('complete'),call.forget('error'),call.forget('removed')])

    def test_concurrently_removed_record_is_safe_but_rpc_errors_are_not_hidden(self):
        engine = object.__new__(Engine)
        engine.files = Mock()
        def rpc(method,*args):
            if method == 'tellStopped':
                return [{'gid':'abcd','status':'complete'}]
            if method == 'removeDownloadResult':
                raise RpcError({'code':1,'message':'GID abcd is not found'})
        engine.call = Mock(side_effect=rpc)
        self.assertEqual(engine.clear_history(), 0)
        engine.files.forget.assert_not_called()
        engine.call = Mock(side_effect=RpcError({'code':1,'message':'RPC failure'}))
        with self.assertRaises(RpcError):
            engine.clear_history()
