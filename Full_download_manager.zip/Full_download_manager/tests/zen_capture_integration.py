"""Opt-in real Zen test, using an isolated profile and localhost-only files.

Run directly. Marionette drives trusted mouse clicks. The packaged background
code is unchanged except that native messaging is replaced by a local test ACK.
No user profile, browser settings, native host registry or real download is used.
"""
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parents[1]


class Marionette:
    def __init__(self, port):
        deadline = time.monotonic() + 25
        while True:
            try:
                self.socket = socket.create_connection(('127.0.0.1', port), timeout=2)
                break
            except OSError:
                if time.monotonic() > deadline:
                    raise
                time.sleep(.2)
        self.socket.settimeout(20)
        self.reader = self.socket.makefile('rb')
        self.sequence = 0
        self.receive()

    def receive(self):
        length = b''
        while not length.endswith(b':'):
            value = self.reader.read(1)
            if not value:
                raise EOFError('Marionette closed')
            length += value
        return json.loads(self.reader.read(int(length[:-1])))

    def call(self, name, **values):
        self.sequence += 1
        data = json.dumps([0, self.sequence, name, values]).encode()
        self.socket.sendall(str(len(data)).encode() + b':' + data)
        response = self.receive()
        if response[2]:
            raise RuntimeError(f'{name}: {response[2]}')
        return response[3]

    def script(self, script):
        return self.call('WebDriver:ExecuteAsyncScript', script=script, args=[],
                         newSandbox=True, sandbox='default', scriptTimeout=10000)


def main():
    handoffs = []
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_POST(self):
            value = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            handoffs.append(value)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{"ok":true}')

        def do_GET(self):
            self.send_response(200)
            if self.path == '/':
                self.send_header('Content-Type', 'text/html')
                self.end_headers()
                self.wfile.write(b'<a id="file" href="/file.iso">ISO</a> '
                                 b'<a id="opaque" href="/opaque">attachment</a> '
                                 b'<a id="blank" href="/opaque?blank" target="_blank">new tab</a> '
                                 b'<button id="script" onclick="const a=document.createElement(\'a\');'
                                 b'a.href=\'/opaque?script\';a.click()">Script download</button> '
                                 b'<button id="frame" onclick="const f=document.createElement(\'iframe\');'
                                 b'f.src=\'/opaque?frame\';document.body.appendChild(f)">Frame</button>')
            else:
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition', 'attachment; filename="file.iso"')
                self.end_headers()
                try:
                    self.wfile.write(b'x' * 8192)
                except (BrokenPipeError, ConnectionResetError):
                    pass

    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}'
    with tempfile.TemporaryDirectory(prefix='fdm-zen-test-') as directory:
        work = Path(directory)
        profile = work / 'profile'
        profile.mkdir()
        with socket.socket() as reservation:
            reservation.bind(('127.0.0.1', 0))
            port = reservation.getsockname()[1]
        prefs = {'marionette.port': port, 'browser.shell.checkDefaultBrowser': False,
                 'browser.aboutwelcome.enabled': False, 'browser.startup.page': 0,
                 'browser.startup.homepage': 'about:blank', 'browser.download.useDownloadDir': True,
                 'browser.download.folderList': 2, 'browser.download.dir': str(work / 'downloads'),
                 'datareporting.policy.dataSubmissionPolicyBypassNotification': True,
                 'zen.welcome-screen.seen': True}
        (profile / 'user.js').write_text(''.join(f'user_pref({json.dumps(k)}, {json.dumps(v)});\n'
                                                for k, v in prefs.items()), encoding='utf-8')
        addon = work / 'addon'
        shutil.copytree(ROOT / 'browser-extension-firefox', addon)
        background = addon / 'background.js'
        source = background.read_text(encoding='utf-8')
        native = "await api.runtime.sendNativeMessage(HOST, {action: 'download', url})"
        assert native in source
        source = source.replace(native, f"await fetch('{base}/handoff', {{method:'POST',body:JSON.stringify({{url}})}}).then(r => r.json())")
        background.write_text(source, encoding='utf-8')
        binary = os.environ.get('FDM_ZEN_BINARY', r'C:\Program Files\Zen Browser\zen.exe')
        with (work / 'zen.log').open('wb') as log:
            process = subprocess.Popen([binary, '-no-remote', '-headless', '-profile', str(profile),
                                        '--marionette', '-remote-allow-system-access', 'about:blank'],
                                       stdout=log, stderr=log,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            client = None
            try:
                client = Marionette(port)
                session = client.call('WebDriver:NewSession', capabilities={'alwaysMatch': {'acceptInsecureCerts': True}})
                print('session', json.dumps(session), flush=True)
                print('install', client.call('Addon:Install', path=str(addon), temporary=True), flush=True)
                for number, selector in enumerate(('file', 'opaque', 'blank', 'script', 'frame'), 1):
                    client.call('WebDriver:Navigate', url=base + '/')
                    element = client.call('WebDriver:FindElement', using='css selector', value='#' + selector)
                    element = element.get('value', element)
                    client.call('WebDriver:ElementClick', id=next(iter(element.values())))
                    time.sleep(1)
                    client.call('Marionette:SetContext', value='chrome')
                    downloads = client.script('''
                        const done = arguments[arguments.length-1];
                        (async () => {
                          const {Downloads} = ChromeUtils.importESModule('resource://gre/modules/Downloads.sys.mjs');
                          const {DownloadHistory} = ChromeUtils.importESModule('resource://gre/modules/DownloadHistory.sys.mjs');
                          const list = await Downloads.getList(Downloads.ALL);
                          const history = await DownloadHistory.getList({type:Downloads.ALL});
                          return {panel:(await list.getAll()).length, library:(await history.getAll()).length};
                        })().then(done, e => done({error:String(e)}));
                    ''')
                    downloads = downloads.get('value', downloads)
                    client.call('Marionette:SetContext', value='content')
                    print(selector, 'handoffs', len(handoffs), 'downloads', json.dumps(downloads), flush=True)
                    assert len(handoffs) == number, (selector, handoffs)
                    assert downloads == {'panel':0, 'library':0}, (selector, downloads)
                client.call('Marionette:SetContext', value='chrome')
                popup = client.script("arguments[arguments.length-1](WebExtensionPolicy.getByID('hizli-indir@local.invalid').getURL('popup.html'));")['value']
                client.call('Marionette:SetContext', value='content')
                client.call('WebDriver:Navigate', url=popup)
                time.sleep(.5)
                diagnostics = client.script("arguments[arguments.length-1]({build:document.getElementById('build').textContent, access:document.getElementById('site-access').textContent, route:document.getElementById('capture-route').textContent});")['value']
                print('popup', json.dumps(diagnostics), flush=True)
                assert diagnostics['build'] == '1.3.0 / ZEN-02', diagnostics
                assert 'Response headers' in diagnostics['route'] or 'Yanıt başlığında' in diagnostics['route'], diagnostics
            except Exception:
                print((work / 'zen.log').read_text(encoding='utf-8', errors='replace')[-3000:], flush=True)
                raise
            finally:
                if client:
                    try:
                        client.call('Marionette:Quit', flags=['eForceQuit'])
                    except Exception:
                        pass
                    client.reader.close()
                    client.socket.close()
                try:
                    process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    process.terminate()
                    process.wait(timeout=5)
    server.shutdown()


if __name__ == '__main__':
    main()
