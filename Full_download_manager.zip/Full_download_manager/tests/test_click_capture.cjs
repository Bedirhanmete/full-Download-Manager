const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

async function click({url='https://example.com/windows.iso', enabled=true, ok=true,
  download=false, nativeThrows=false, extra={}, directory='browser-extension'} = {}) {
  let listener, prevented=0, replayed=0, sent=[];
  const anchor = {tagName:'A', href:url, hasAttribute: name => name === 'download' && download,
    click() { replayed++; listener(event); }};
  const event = {isTrusted:true, button:0, composedPath:() => [anchor],
    preventDefault() {prevented++;}, stopImmediatePropagation() {}, ...extra};
  const api = {
    storage:{local:{get:async () => ({enabled})}, onChanged:{addListener() {}}},
    runtime:{sendMessage:async value => {sent.push(value.url); if (nativeThrows) throw Error('Missing'); return {ok};}}
  };
  const context = vm.createContext({chrome:api, URL, document:{addEventListener(type, fn) {listener=fn;}}});
  vm.runInContext(fs.readFileSync(`${directory}/click-capture.js`, 'utf8'), context);
  await Promise.resolve();
  listener(event);
  await new Promise(resolve => setImmediate(resolve));
  return {prevented, replayed, sent};
}

(async () => {
  assert.deepEqual(await click(), {prevented:1, replayed:0, sent:['https://example.com/windows.iso']});
  assert.equal((await click({ok:false})).replayed, 1);
  assert.equal((await click({nativeThrows:true})).replayed, 1);
  assert.equal((await click({download:true,url:'https://example.com/get?id=12'})).prevented, 1);
  assert.deepEqual(await click({directory:'browser-extension-firefox'}),
    {prevented:1,replayed:0,sent:['https://example.com/windows.iso']});
  assert.equal((await click({directory:'browser-extension-firefox',ok:false})).replayed, 1);
  for (const values of [{enabled:false}, {url:'https://example.com/page'}, {url:'blob:https://example.com/abc'},
    {url:'https://user:pass@example.com/file.iso'}, {extra:{ctrlKey:true}}, {extra:{button:1}},
    {extra:{isTrusted:false}}, {extra:{defaultPrevented:true}}]) {
    assert.deepEqual(await click(values), {prevented:0,replayed:0,sent:[]});
  }
  console.log('14 Chromium/Firefox file-link click capture and fallback checks passed');
})().catch(error => {console.error(error); process.exitCode=1;});
