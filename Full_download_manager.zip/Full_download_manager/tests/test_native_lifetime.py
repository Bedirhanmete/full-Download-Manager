"""Reproduce a browser killing its native host job after an acknowledged handoff."""
import ctypes
from ctypes import wintypes
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import native_host
from browser_bridge import read_message, write_message

ROOT = Path(__file__).resolve().parents[1]


class NativeLaunchTests(unittest.TestCase):
    def test_desktop_is_detached_and_uses_logged_entrypoint(self):
        with patch.dict(os.environ, {'PYTHONHOME': 'bad', 'TCL_LIBRARY': 'bad'}), \
             patch('native_host.subprocess.Popen') as launch:
            native_host.launch()
        command = launch.call_args.args[0]
        options = launch.call_args.kwargs
        self.assertEqual(Path(command[1]), ROOT / 'app_start.pyw')
        self.assertNotIn('PYTHONHOME', options['env'])
        self.assertNotIn('TCL_LIBRARY', options['env'])
        self.assertEqual(options['stdout'], subprocess.DEVNULL)
        if os.name == 'nt':
            self.assertTrue(options['creationflags'] & subprocess.CREATE_BREAKAWAY_FROM_JOB)
            self.assertTrue(options['creationflags'] & subprocess.CREATE_NO_WINDOW)
        else:
            self.assertTrue(options['start_new_session'])


@unittest.skipUnless(os.name == 'nt', 'Windows browser job lifetime')
class BrowserJobTests(unittest.TestCase):
    def exercise(self, detached):
        class Basic(ctypes.Structure):
            _fields_ = [('process_time', ctypes.c_int64), ('job_time', ctypes.c_int64),
                        ('flags', wintypes.DWORD), ('min_working_set', ctypes.c_size_t),
                        ('max_working_set', ctypes.c_size_t), ('active_limit', wintypes.DWORD),
                        ('affinity', ctypes.c_size_t), ('priority', wintypes.DWORD), ('scheduling', wintypes.DWORD)]
        class Counters(ctypes.Structure):
            _fields_ = [(name, ctypes.c_uint64) for name in ('reads', 'writes', 'other', 'read_bytes', 'write_bytes', 'other_bytes')]
        class Extended(ctypes.Structure):
            _fields_ = [('basic', Basic), ('io', Counters), ('process_memory', ctypes.c_size_t),
                        ('job_memory', ctypes.c_size_t), ('peak_process', ctypes.c_size_t), ('peak_job', ctypes.c_size_t)]
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        kernel.CreateJobObjectW.restype = wintypes.HANDLE
        kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        job = kernel.CreateJobObjectW(None, None)
        self.assertTrue(job)
        limits = Extended()
        limits.basic.flags = 0x2000 | 0x800  # KILL_ON_JOB_CLOSE | BREAKAWAY_OK
        self.assertTrue(kernel.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)))
        child_handle = None
        host = None
        try:
            with tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                gate, ready = root / 'gate', root / 'desktop.pid'
                desktop = root / 'desktop.py'
                desktop.write_text(f'''
import os, sys, time
from pathlib import Path
sys.path.insert(0, {str(ROOT)!r})
from browser_bridge import file_lock, receive_requests
data = Path.home() / '.hizli-indir'
with file_lock(data / 'app.lock'):
    Path({str(ready)!r}).write_text(str(os.getpid()))
    until = time.monotonic() + 20
    while time.monotonic() < until:
        receive_requests(data, lambda url: None)
        time.sleep(.02)
''', encoding='utf-8')
                worker = root / 'host.py'
                worker.write_text(f'''
import sys, time
from pathlib import Path
sys.path.insert(0, {str(ROOT)!r})
while not Path({str(gate)!r}).exists(): time.sleep(.01)
import native_host
original = native_host.subprocess.Popen
def standin(command, **options):
    if not {detached!r}:
        options['creationflags'] &= ~native_host.subprocess.CREATE_BREAKAWAY_FROM_JOB
    return original([sys.executable, {str(desktop)!r}], **options)
native_host.subprocess.Popen = standin
native_host.find_aria2 = lambda: 'fixture-aria2'
native_host.main()
''', encoding='utf-8')
                environment = os.environ.copy()
                environment['USERPROFILE'] = str(root)
                environment['PYTHONUTF8'] = '1'
                host = subprocess.Popen([sys.executable, str(worker)], stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                        env=environment, creationflags=subprocess.CREATE_NO_WINDOW)
                self.assertTrue(kernel.AssignProcessToJobObject(job, int(host._handle)), ctypes.get_last_error())
                gate.touch()
                buffer = io.BytesIO()
                write_message(buffer, {'action': 'download', 'url': 'https://example.com/test.zip'})
                output, error = host.communicate(buffer.getvalue(), timeout=10)
                self.assertEqual(host.returncode, 0, error.decode(errors='replace'))
                self.assertEqual(read_message(io.BytesIO(output)), {'ok': True})
                child_handle = kernel.OpenProcess(0x1000 | 0x1 | 0x100000, False, int(ready.read_text()))
                self.assertTrue(child_handle)
                kernel.CloseHandle(job)
                job = None
                exit_code = wintypes.DWORD()
                deadline = time.monotonic() + 1
                while True:
                    self.assertTrue(kernel.GetExitCodeProcess(child_handle, ctypes.byref(exit_code)))
                    if exit_code.value != 259 or time.monotonic() >= deadline:
                        break
                    time.sleep(.02)
                self.assertEqual(exit_code.value == 259, detached)
                if detached:
                    kernel.TerminateProcess(child_handle, 0)
                self.assertEqual(kernel.WaitForSingleObject(child_handle, 5000), 0)
        finally:
            if job:
                kernel.CloseHandle(job)
            if child_handle:
                kernel.TerminateProcess(child_handle, 0)
                kernel.CloseHandle(child_handle)
            if host is not None and host.poll() is None:
                host.kill()
                host.wait()

    def test_old_launch_is_killed_with_browser_job(self):
        self.exercise(False)

    def test_fixed_launch_survives_native_reply_and_browser_job_close(self):
        self.exercise(True)


if __name__ == '__main__':
    unittest.main()
