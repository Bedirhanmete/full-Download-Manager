"""Real aria2 integration tests against a local HTTP fixture; no external download."""
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import os
from pathlib import Path
import shutil
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import Engine, valid_url, find_aria2

DATA = os.urandom(12 * 1024 * 1024)


class Handler(BaseHTTPRequestHandler):
    ranges = 0
    requests = 0

    def log_message(self, *args):
        pass

    def do_GET(self):
        Handler.requests += 1
        start, end = 0, len(DATA) - 1
        ranged = self.path != '/plain' and self.headers.get('Range')
        if ranged:
            Handler.ranges += 1
            limits = self.headers['Range'].split('=')[1].split('-')
            start = int(limits[0])
            if limits[1]:
                end = int(limits[1])
        self.send_response(206 if ranged else 200)
        self.send_header('Content-Length', str(end - start + 1))
        if ranged:
            self.send_header('Content-Range', f'bytes {start}-{end}/{len(DATA)}')
        self.end_headers()
        try:
            for pos in range(start, end + 1, 16384):
                self.wfile.write(DATA[pos:min(pos + 16384, end + 1)])
                time.sleep(.004)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass


@unittest.skipUnless(find_aria2(), 'aria2c required')
class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.url = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def wait_for(self, fn, timeout=30):
        until = time.monotonic() + timeout
        while time.monotonic() < until:
            result = fn()
            if result:
                return result
            time.sleep(.1)
        self.fail('Condition timed out')

    def test_parallel_pause_shutdown_restore_integrity(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            engine = Engine(folder / 'state')
            try:
                with self.assertRaisesRegex(RuntimeError, 'zaten açık'):
                    Engine(folder / 'state')
                gid = engine.add(self.url + '/large.bin', folder / 'files', 16)
                self.wait_for(lambda: int(engine.call('tellStatus', gid)['completedLength']) > 500000)
                engine.call('forcePause', gid)
                self.wait_for(lambda: engine.call('tellStatus', gid)['status'] == 'paused')
                saved = int(engine.call('tellStatus', gid)['completedLength'])
                self.assertGreater(saved, 0)
                engine.call('unpause', gid)
                self.wait_for(lambda: engine.call('tellStatus', gid)['status'] == 'active')
            finally:
                engine.close()
            self.assertIsNotNone(engine.process.poll())
            restored = Engine(folder / 'state')
            try:
                tasks = restored.snapshot()
                self.assertEqual(len(tasks), 1)
                self.assertEqual(tasks[0]['status'], 'paused')
                gid = tasks[0]['gid']
                restored.call('unpause', gid)
                self.wait_for(lambda: restored.call('tellStatus', gid)['status'] == 'complete')
                self.assertGreater(Handler.ranges, 1)
                actual = (folder / 'files' / 'large.bin').read_bytes()
                self.assertEqual(hashlib.sha256(actual).digest(), hashlib.sha256(DATA).digest())
            finally:
                restored.close()
            self.assertIsNotNone(restored.process.poll())

    def test_restored_limits_are_cleared_and_sparse_allocation_is_enabled(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            engine = Engine(folder / 'state')
            try:
                gid = engine.add(self.url + '/restored.bin', folder / 'files', 16)
                engine.call('forcePause', gid)
                engine.call('changeOption', gid, {
                    'split': '1', 'max-connection-per-server': '1',
                    'max-download-limit': '64K', 'file-allocation': 'none', 'min-split-size': '20M'})
                engine.call('saveSession')
            finally:
                engine.close()
            restored = Engine(folder / 'state', connections=16, concurrent_downloads=2)
            try:
                item = restored.snapshot()[0]
                self.assertEqual(item['status'], 'paused')
                options = restored.call('getOption', item['gid'])
                self.assertEqual(options['split'], '16')
                self.assertEqual(options['max-connection-per-server'], '16')
                self.assertEqual(options['max-download-limit'], '0')
                self.assertEqual(options['min-split-size'], '1048576')
                if sys.platform == 'win32':
                    self.assertEqual(options['file-allocation'], 'trunc')
                global_options = restored.call('getGlobalOption')
                self.assertEqual(global_options['max-overall-download-limit'], '0')
                self.assertEqual(global_options['max-concurrent-downloads'], '2')
            finally:
                restored.close()

    def test_parallel_transfer_is_faster_than_a_single_throttled_connection(self):
        results = {}
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(Path(tmp) / 'state')
            try:
                for connections in (1, 16):
                    started = time.monotonic()
                    gid = engine.add(self.url + '/speed.bin', Path(tmp) / str(connections), connections)
                    self.wait_for(lambda: engine.call('tellStatus', gid)['status'] == 'complete')
                    results[connections] = time.monotonic() - started
                    self.assertEqual((Path(tmp) / str(connections) / 'speed.bin').read_bytes(), DATA)
                self.assertLess(results[16], results[1] * .8)
            finally:
                engine.close()


    def test_cancel_active_deletes_only_its_partial_files_and_session_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            destination = folder / 'files'
            destination.mkdir()
            sentinel = destination / 'keep.txt'
            sentinel.write_text('Keep my file.', encoding='utf-8')
            engine = Engine(folder / 'state')
            try:
                gid = engine.add(self.url + '/cancel.bin', destination, 1)
                self.wait_for(lambda: int(engine.call('tellStatus', gid)['completedLength']) > 131072)
                path = Path(engine.call('tellStatus', gid)['files'][0]['path'])
                self.assertTrue(path.exists())
                self.assertEqual(engine.cancel(gid), 'cancelled')
                self.assertFalse(path.exists())
                self.assertFalse(Path(str(path) + '.aria2').exists())
                self.assertFalse(Path(str(path) + '.aria2__temp').exists())
                self.assertEqual(sentinel.read_text(encoding='utf-8'), 'Keep my file.')
                self.assertNotIn(gid, [item['gid'] for item in engine.snapshot()])
            finally:
                engine.close()
            self.assertNotIn('cancel.bin', (folder / 'state/session.txt').read_text(encoding='utf-8'))
            restored = Engine(folder / 'state')
            try:
                self.assertEqual(restored.snapshot(), [])
            finally:
                restored.close()

    def test_paused_control_is_hidden_and_restored_cancel_cleans_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            engine = Engine(folder / 'state')
            try:
                gid = engine.add(self.url + '/paused.bin', folder / 'files', 1)
                self.wait_for(lambda: int(engine.call('tellStatus', gid)['completedLength']) > 131072)
                engine.call('forcePause', gid)
                self.wait_for(lambda: engine.call('tellStatus', gid)['status'] == 'paused')
                path = Path(engine.call('tellStatus', gid)['files'][0]['path'])
                control = Path(str(path) + '.aria2')
                self.wait_for(control.exists)
                if os.name == 'nt':
                    self.wait_for(lambda: bool(control.stat().st_file_attributes & 2))
            finally:
                engine.close()
            self.assertTrue(control.exists())
            if os.name == 'nt':
                self.assertTrue(control.stat().st_file_attributes & 2)
            restored = Engine(folder / 'state')
            try:
                gid = restored.snapshot()[0]['gid']
                self.assertEqual(restored.cancel(gid), 'cancelled')
                self.assertFalse(path.exists())
                self.assertFalse(control.exists())
            finally:
                restored.close()

    def test_cancel_waiting_job_keeps_the_active_download(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            engine = Engine(folder / 'state', concurrent_downloads=1)
            try:
                first = engine.add(self.url + '/keep-active.bin', folder / 'files', 1)
                self.wait_for(lambda: int(engine.call('tellStatus', first)['completedLength']) > 131072)
                queued = engine.add(self.url + '/queued.bin', folder / 'files', 1)
                self.assertEqual(engine.call('tellStatus', queued)['status'], 'waiting')
                self.assertEqual(engine.cancel(queued), 'cancelled')
                self.assertEqual(engine.call('tellStatus', first)['status'], 'active')
                self.assertFalse((folder / 'files/queued.bin').exists())
                engine.cancel(first)
            finally:
                engine.close()

    def test_preexisting_file_survives_cancel_of_auto_renamed_download(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            destination = folder / 'files'
            destination.mkdir()
            original = destination / 'collision.bin'
            original.write_bytes(b'Existing user content')
            engine = Engine(folder / 'state')
            try:
                gid = engine.add(self.url + '/collision.bin', destination, 1)
                self.wait_for(lambda: int(engine.call('tellStatus', gid)['completedLength']) > 131072)
                partial = Path(engine.call('tellStatus', gid)['files'][0]['path'])
                self.assertNotEqual(partial, original)
                self.assertEqual(engine.cancel(gid), 'cancelled')
                self.assertFalse(partial.exists())
                self.assertEqual(original.read_bytes(), b'Existing user content')
            finally:
                engine.close()

    def test_completion_removes_control_and_cancel_preserves_completed_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            engine = Engine(folder / 'state')
            try:
                gid = engine.add(self.url + '/finished.bin', folder / 'files', 16)
                self.wait_for(lambda: engine.call('tellStatus', gid)['status'] == 'complete')
                path = folder / 'files/finished.bin'
                self.assertFalse(Path(str(path) + '.aria2').exists())
                self.assertEqual(engine.cancel(gid), 'complete')
                self.assertEqual(path.read_bytes(), DATA)
            finally:
                engine.close()
            self.assertNotIn('finished.bin', (folder / 'state/session.txt').read_text(encoding='utf-8'))
            self.assertFalse(Path(str(path) + '.aria2').exists())


    def test_saved_auto_resume_never_starts_a_download_at_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            engine = Engine(folder / 'state')
            try:
                gid = engine.add(self.url + '/do-not-autostart.bin', folder / 'files', 1)
                self.wait_for(lambda: int(engine.call('tellStatus', gid)['completedLength']) > 131072)
            finally:
                engine.close()
            session = folder / 'state/session.txt'
            session.write_text(session.read_text(encoding='utf-8') + '  pause=false\n', encoding='utf-8')
            before = Handler.requests
            restored = Engine(folder / 'state')
            try:
                time.sleep(.4)
                items = restored.snapshot()
                self.assertEqual(len(items), 1)
                self.assertEqual(items[0]['status'], 'paused')
                self.assertEqual(restored.call('tellActive'), [])
                self.assertEqual(Handler.requests, before)
            finally:
                restored.close()


    def test_server_without_range(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(Path(tmp) / 'state')
            try:
                gid = engine.add(self.url + '/plain', Path(tmp) / 'files', 16)
                self.wait_for(lambda: engine.call('tellStatus', gid)['status'] == 'complete')
                self.assertEqual((Path(tmp) / 'files' / 'plain').read_bytes(), DATA)
            finally:
                engine.close()


class URLTests(unittest.TestCase):
    def test_only_http_file_links(self):
        for bad in ['file:///etc/passwd', 'ftp://example.com/a', 'https://', 'https://a/b c', 'https://u:p@a/b']:
            with self.assertRaises(ValueError):
                valid_url(bad)
        self.assertEqual(valid_url('https://example.com/file.zip?a=1'), 'https://example.com/file.zip?a=1')


if __name__ == '__main__':
    unittest.main()
