# Read-only UI verification against the compiled EXE. Never starts installation.
$ErrorActionPreference = 'Stop'
$setupFile = Join-Path (Split-Path $PSScriptRoot) 'dist/FullDownloadManager-Setup.exe'
$assembly = [Reflection.Assembly]::LoadFile($setupFile)
$type = $assembly.GetType('SetupWindow')
$flags = [Reflection.BindingFlags]'Instance,Public,NonPublic'
$form = [Activator]::CreateInstance($type, $flags, $null, @($false), $null)
function Assert($Value, $Message) { if (-not $Value) { throw $Message } }
try {
    $choice = $type.GetField('browserChoice', $flags).GetValue($form)
    $checkbox = $type.GetField('browser', $flags).GetValue($form)
    $selected = $type.GetMethod('SelectedBrowser', $flags)
    Assert ($choice.Items.Count -eq 9) 'Browser selection list incomplete'
    Assert ($selected.Invoke($form, $null) -eq '') 'Initial selection must require a user choice'
    $type.GetMethod('BeginInstall', $flags).Invoke($form, $null)
    Assert (-not $type.GetField('running', $flags).GetValue($form)) 'Installation started without a browser choice'
    $checkbox.Checked = $false
    Assert (-not $choice.Enabled) 'Browser choice should be disabled when store opening is off'
    $checkbox.Checked = $true
    Assert $choice.Enabled 'Browser choice was not re-enabled'
    $expected = @('chrome','brave','edge','vivaldi','opera','chromium','firefox','zen')
    for ($index = 0; $index -lt $expected.Count; $index++) {
        $choice.SelectedIndex = $index + 1
        Assert ($selected.Invoke($form, $null) -eq $expected[$index]) 'Browser selection mapped to the wrong target'
    }
    foreach ($control in $form.Controls) {
        Assert ($control.Bottom -le $form.ClientSize.Height) 'Installer control clipped below window'
    }
    Write-Output 'Compiled installer browser selection passed: eight targets, required choice, opt-out and layout.'
} finally { $form.Dispose() }
