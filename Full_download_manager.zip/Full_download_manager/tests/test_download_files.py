"""Deletion boundaries and ownership protection; no recursive filesystem cleanup."""
from pathlib import Path
import os
import tempfile
import unittest
from download_files import DownloadFiles


class DownloadFileSafetyTests(unittest.TestCase):
    def test_legacy_file_with_unknown_progress_is_not_assumed_to_be_partial(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / 'old.bin'
            path.write_bytes(b'potentially completed file')
            Path(str(path) + '.aria2').write_bytes(b'legacy control')
            manager = DownloadFiles(root)
            item = {'gid': 'legacy', 'status': 'paused', 'dir': str(root),
                    'totalLength': '0', 'completedLength': '0', 'files': [{'path': str(path)}]}
            manager.observe([item])
            self.assertTrue(manager.delete_partials(item, []))
            self.assertEqual(path.read_bytes(), b'potentially completed file')

    def test_preexisting_files_and_controls_are_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / 'existing.bin'
            control = root / 'existing.bin.aria2'
            path.write_bytes(b'original')
            control.write_bytes(b'original resume data')
            manager = DownloadFiles(root)
            manager.register('job', manager.begin(root))
            result = manager.delete_partials({'gid': 'job', 'files': [{'path': str(path)}]}, [])
            self.assertTrue(result)
            self.assertEqual(path.read_bytes(), b'original')
            self.assertEqual(control.read_bytes(), b'original resume data')

    def test_other_download_using_the_same_path_is_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manager = DownloadFiles(root)
            manager.register('job', manager.begin(root))
            path = root / 'shared.bin'
            path.write_bytes(b'other download')
            item = {'gid': 'job', 'files': [{'path': str(path)}]}
            other = dict(item, gid='other')
            self.assertTrue(manager.delete_partials(item, [other]))
            self.assertEqual(path.read_bytes(), b'other download')

    def test_outside_path_rejects_entire_cleanup_before_deleting_any_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            destination = root / 'downloads'
            destination.mkdir()
            manager = DownloadFiles(root)
            manager.register('job', manager.begin(destination))
            own = destination / 'partial.bin'
            own.write_bytes(b'partial')
            outside = root / 'important.bin'
            outside.write_bytes(b'important')
            item = {'gid': 'job', 'files': [{'path': str(own)}, {'path': str(outside)}]}
            with self.assertRaises(ValueError):
                manager.delete_partials(item, [])
            self.assertTrue(own.exists())
            self.assertEqual(outside.read_bytes(), b'important')

    def test_ownership_protection_survives_application_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            original = root / 'keep.bin'
            original.write_bytes(b'keep')
            manager = DownloadFiles(root)
            manager.register('job', manager.begin(root))
            restored = DownloadFiles(root)
            self.assertTrue(restored.delete_partials({'gid': 'job', 'files': [{'path': str(original)}]}, []))
            self.assertEqual(original.read_bytes(), b'keep')

    def test_hard_link_to_an_existing_file_is_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            original = root / 'original.bin'
            original.write_bytes(b'keep')
            manager = DownloadFiles(root)
            manager.register('job', manager.begin(root))
            link = root / 'partial.bin'
            try:
                os.link(original, link)
            except OSError:
                self.skipTest('Hard links unavailable')
            self.assertTrue(manager.delete_partials({'gid': 'job', 'files': [{'path': str(link)}]}, []))
            self.assertEqual(original.read_bytes(), b'keep')
            self.assertTrue(link.exists())

