import base64
import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
import types
import unittest
import zipfile
from unittest.mock import patch

import browser_setup


class DefaultBrowserTests(unittest.TestCase):
    def test_explicit_firefox_and_zen_are_not_confused(self):
        for chosen, default_exe, expected in [('firefox', 'zen.exe', 'firefox.exe'), ('zen', 'firefox.exe', 'zen.exe')]:
            with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, {'LOCALAPPDATA':directory}), \
                 patch('browser_setup.detect_default_browser', return_value={'browser':'firefox','name':'Default','executable':default_exe}), \
                 patch('browser_setup.browser_executable', return_value=expected) as find, \
                 patch('browser_setup.store_identity', return_value=None), \
                 patch('setup_browser.install') as install, patch('setup_protocol.install'), \
                 contextlib.redirect_stdout(io.StringIO()):
                state = browser_setup.prepare(chosen)
                self.assertEqual(state['executable'], expected)
                self.assertEqual(state['browser'], 'firefox')
                find.assert_called_once_with(chosen)
                install.assert_called_once_with('firefox', None)
    def test_edge_without_own_store_listing_uses_chrome_store_and_edge_host(self):
        from unittest.mock import call
        with tempfile.TemporaryDirectory() as directory, patch('pathlib.Path.home', return_value=Path(directory)), \
             patch.dict(os.environ, {'LOCALAPPDATA': directory}), \
             patch('browser_setup.detect_default_browser', return_value={'browser': 'edge', 'name': 'Edge', 'executable': '', 'progid': 'MSEdgeHTM'}), \
             patch('browser_setup.store_identity', side_effect=lambda browser, identity=None: 'a' * 32 if browser == 'chrome' else None), \
             patch('setup_browser.install') as install, patch('setup_protocol.install'), \
             contextlib.redirect_stdout(io.StringIO()):
            result = browser_setup.prepare()
            self.assertEqual(result['store_channel'], 'chrome')
            self.assertEqual(result['store_url'], 'https://chromewebstore.google.com/detail/' + 'a' * 32)
            self.assertIn(call('edge', 'a' * 32), install.call_args_list)

    def test_store_ids_persist_separately_and_reject_invalid_values(self):
        with tempfile.TemporaryDirectory() as directory, patch('pathlib.Path.home', return_value=Path(directory)), \
             patch('browser_setup.ROOT', Path(directory)):
            self.assertIsNone(browser_setup.store_identity('chrome'))
            self.assertEqual(browser_setup.store_identity('chrome', 'a' * 32), 'a' * 32)
            self.assertEqual(browser_setup.store_identity('edge', 'b' * 32), 'b' * 32)
            for browser in ('chrome', 'brave', 'opera', 'chromium', 'vivaldi'):
                self.assertEqual(browser_setup.store_identity(browser), 'a' * 32)
            self.assertEqual(browser_setup.store_identity('edge'), 'b' * 32)
            for bad in ('', 'a' * 31, 'z' * 32, '../file', 'https://example.com', 'A' * 32):
                with self.assertRaises(ValueError):
                    browser_setup.store_identity('chrome', bad)
            self.assertEqual(browser_setup.store_identity('chrome'), 'a' * 32)

    def test_publisher_store_id_is_connected_even_when_default_is_zen(self):
        published = json.loads((browser_setup.ROOT / 'assets/extension-stores.json').read_text())['chrome']
        with tempfile.TemporaryDirectory() as directory, patch('pathlib.Path.home', return_value=Path(directory)), \
             patch.dict(os.environ, {'LOCALAPPDATA': directory}), \
             patch('browser_setup.detect_default_browser', return_value={'browser': 'firefox', 'name': 'Zen', 'executable': 'zen.exe', 'progid': 'Firefox'}), \
             patch('setup_browser.install') as install, patch('setup_protocol.install'), \
             contextlib.redirect_stdout(io.StringIO()):
            result = browser_setup.prepare()
            self.assertEqual(result['browser'], 'firefox')
            self.assertEqual(result['store_channel'], 'firefox')
            self.assertEqual(result['store_url'], 'https://addons.mozilla.org/tr/firefox/addon/full-download-manager/')
            self.assertEqual(install.call_args_list[0].args, ('firefox', None))
            self.assertEqual(install.call_args_list[1].args, ('chrome', published))
            self.assertEqual(browser_setup.store_identity('brave'), published)

    def test_browser_override_uses_real_store_id_without_changing_default(self):
        with tempfile.TemporaryDirectory() as directory, patch('pathlib.Path.home', return_value=Path(directory)), \
             patch.dict(os.environ, {'LOCALAPPDATA': directory}), \
             patch('browser_setup.detect_default_browser', return_value={'browser': 'firefox', 'name': 'Zen', 'executable': 'zen.exe', 'progid': 'Firefox'}), \
             patch('browser_setup.browser_executable', return_value='chrome.exe'), \
             patch('setup_browser.install') as install, patch('setup_protocol.install'), \
             contextlib.redirect_stdout(io.StringIO()):
            result = browser_setup.prepare('chrome', 'c' * 32)
            install.assert_called_once_with('chrome', 'c' * 32)
            self.assertEqual(result['executable'], 'chrome.exe')
            self.assertEqual(result['store_url'], 'https://chromewebstore.google.com/detail/' + 'c' * 32)
            self.assertFalse(result['extension_enabled'])
            result = browser_setup.prepare('brave')
            self.assertEqual(result['extension_id'], 'c' * 32)
            result = browser_setup.prepare('edge', 'd' * 32)
            self.assertEqual(result['store_url'], 'https://microsoftedge.microsoft.com/addons/detail/' + 'd' * 32)

    def test_permanent_package_requires_signature_files_and_matching_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'assets').mkdir()
            with patch('browser_setup.ROOT', root):
                self.assertIsNone(browser_setup.permanent_package())
                for identity, signatures, expected in [
                    ('hizli-indir@local.invalid', False, False),
                    ('wrong@local.invalid', True, False),
                    ('hizli-indir@local.invalid', True, True),
                ]:
                    package = root / 'assets/FullDownloadManager-Firefox.xpi'
                    with zipfile.ZipFile(package, 'w') as archive:
                        archive.writestr('manifest.json', json.dumps({'browser_specific_settings': {'gecko': {'id': identity}}}))
                        if signatures:
                            archive.writestr('META-INF/mozilla.rsa', 'fixture, not a cryptographic signature')
                            archive.writestr('META-INF/mozilla.sf', 'fixture')
                    self.assertEqual(browser_setup.permanent_package(), package if expected else None)
                package.write_bytes(b'corrupt archive')
                self.assertIsNone(browser_setup.permanent_package())

    def test_branded_browsers_and_unknown(self):
        for progid, exe, expected in [
            ('FirefoxURL-123', '', 'firefox'),
            ('MSEdgeHTM', '', 'edge'),
            ('ChromeHTML', r'C:\Apps\Brave\Application\brave.exe', 'brave'),
            ('ChromeHTML', r'C:\Apps\Vivaldi\Application\vivaldi.exe', 'vivaldi'),
            ('OperaStable', '', 'opera'),
            ('ChromiumHTM', '', 'chromium'),
            ('ChromeHTML', '', 'chrome'),
            ('UnknownBrowserHTML', r'C:\Apps\unknown.exe', None),
        ]:
            with self.subTest(progid=progid, exe=exe):
                self.assertEqual(browser_setup.classify_browser(progid, exe), expected)

    def test_executable_parsing_discards_browser_arguments(self):
        self.assertEqual(browser_setup.command_executable(r'"C:\Program Files\Browser\firefox.exe" -osint -url "%1"'),
                         r'C:\Program Files\Browser\firefox.exe')
        self.assertEqual(browser_setup.command_executable(r'C:\Browser\msedge.exe --single-argument %1'),
                         r'C:\Browser\msedge.exe')
        self.assertEqual(browser_setup.command_executable('invalid-command'), '')

    def test_https_default_and_http_fallback(self):
        for https_exists in (True, False):
            opened = []
            class Key:
                def __init__(self, path):
                    self.path = path
                def __enter__(self):
                    return self
                def __exit__(self, *args):
                    return False
            def open_key(hive, path):
                opened.append(path)
                if '\\https\\' in path and not https_exists:
                    raise FileNotFoundError
                return Key(path)
            def read(key, value):
                if value == 'ProgId':
                    return ('MSEdgeHTM', 1)
                return (r'"C:\Edge\msedge.exe" --single-argument "%1"', 1)
            registry = types.SimpleNamespace(HKEY_CURRENT_USER=1, HKEY_CLASSES_ROOT=2,
                                            OpenKey=open_key, QueryValueEx=read)
            with patch.dict('sys.modules', {'winreg': registry}):
                result = browser_setup.detect_default_browser()
            self.assertEqual(result['browser'], 'edge')
            self.assertEqual(result['executable'], r'C:\Edge\msedge.exe')
            self.assertEqual(any('\\http\\' in path for path in opened), not https_exists)

    def test_no_default_does_not_guess_a_browser(self):
        registry = types.SimpleNamespace(HKEY_CURRENT_USER=1, HKEY_CLASSES_ROOT=2,
                                         OpenKey=lambda *args: (_ for _ in ()).throw(FileNotFoundError()))
        with patch.dict('sys.modules', {'winreg': registry}):
            self.assertIsNone(browser_setup.detect_default_browser()['browser'])

    def test_extension_identity_is_valid_and_stable_across_paths(self):
        identity = browser_setup.extension_id()
        self.assertRegex(identity, r'^[a-p]{32}$')
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'browser-extension').mkdir()
            (root / 'browser-extension/manifest.json').write_bytes(
                (browser_setup.ROOT / 'browser-extension/manifest.json').read_bytes())
            with patch('browser_setup.ROOT', root):
                self.assertEqual(browser_setup.extension_id(), identity)

    def test_prepare_registers_matching_host_and_keeps_activation_pending(self):
        for browser in ('firefox', 'edge', None):
            with self.subTest(browser=browser), tempfile.TemporaryDirectory() as directory:
                result = {'browser': browser, 'name': 'Test browser', 'executable': '', 'progid': 'test'}
                with patch('browser_setup.detect_default_browser', return_value=result), \
                     patch('browser_setup.store_identity', return_value=None), \
                     patch('setup_browser.install') as install, \
                     patch('setup_protocol.install') as protocol, \
                     patch.dict(os.environ, {'LOCALAPPDATA': directory}), \
                     contextlib.redirect_stdout(io.StringIO()):
                    state = browser_setup.prepare()
                protocol.assert_called_once_with()
                if browser:
                    install.assert_called_once_with(browser, None if browser == 'firefox' else browser_setup.extension_id())
                else:
                    install.assert_not_called()
                self.assertFalse(state['extension_enabled'])
                self.assertEqual(state['native_host_ready'], bool(browser))
                saved = json.loads((Path(directory) / 'Full Download Manager/browser-setup.json').read_text(encoding='utf-8'))
                self.assertEqual(saved, state)
