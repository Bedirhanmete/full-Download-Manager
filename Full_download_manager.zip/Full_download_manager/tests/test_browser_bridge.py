import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from browser_bridge import (deliver, file_lock, read_message, receive_requests,
                            running, validate_request, write_message)


class BridgeTests(unittest.TestCase):
    def test_early_desktop_exit_reports_error_without_waiting_for_timeout(self):
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as directory:
            started = time.monotonic()
            with patch('browser_bridge.running', return_value=False), self.assertRaisesRegex(RuntimeError, 'startup.log'):
                deliver({'action': 'download', 'url': 'https://example.com/file.zip'}, Path(directory),
                        lambda: SimpleNamespace(poll=lambda: 1), timeout=5)
            self.assertLess(time.monotonic() - started, 1)

    def test_native_framing_and_invalid_input(self):
        buffer = io.BytesIO()
        write_message(buffer, {'ok': True, 'text': 'İndirme'})
        buffer.seek(0)
        self.assertEqual(read_message(buffer), {'ok': True, 'text': 'İndirme'})
        self.assertIsNone(read_message(buffer))
        for value in [b'\x01', struct.pack('<I', 65537), struct.pack('<I', 10) + b'{}']:
            with self.assertRaises(ValueError):
                read_message(io.BytesIO(value))
        for value in [None, {}, {'action': 'download', 'url': 'file:///a'},
                      {'action': 'download', 'url': ['https://a']},
                      {'action': 'download', 'url': 'https://u:p@a/'}]:
            with self.assertRaises(ValueError):
                validate_request(value)

    def test_cold_launch_delivers_to_dialog_before_ack(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            shown = []
            threads = []
            def launch():
                def desktop():
                    receive_requests(data, shown.append)
                thread = threading.Thread(target=desktop)
                threads.append(thread)
                thread.start()
            result = deliver({'action': 'download', 'url': 'https://example.com/a.zip'}, data, launch, timeout=2)
            for thread in threads:
                thread.join()
            self.assertEqual(result, {'ok': True})
            self.assertEqual(shown, ['https://example.com/a.zip'])
            self.assertEqual(list((data / 'inbox').iterdir()), [])

    def test_warm_delivery_does_not_launch_and_no_auto_download(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            shown = []
            with file_lock(data / 'app.lock'):
                self.assertTrue(running(data))
                def consume():
                    for _ in range(30):
                        receive_requests(data, shown.append)
                        if shown:
                            return
                        time.sleep(.02)
                thread = threading.Thread(target=consume)
                thread.start()
                with patch('browser_bridge.running', return_value=True):
                    result = deliver({'action': 'download', 'url': 'https://example.com/a'}, data,
                                     lambda: self.fail('Must reuse running desktop'), timeout=2)
                thread.join()
            self.assertEqual(result, {'ok': True})
            self.assertEqual(shown, ['https://example.com/a'])

    def test_no_desktop_ack_leaves_browser_fallback_possible(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            with self.assertRaises(RuntimeError):
                deliver({'action': 'download', 'url': 'https://example.com/a'}, data, lambda: None, timeout=.1)
            self.assertEqual(list((data / 'inbox').iterdir()), [])

    def test_install_and_remove_user_host_manifest(self):
        from setup_browser import install
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            with patch('pathlib.Path.home', return_value=home), patch('sys.platform', 'linux'):
                install('chrome', 'a' * 32)
                path = home / '.config/google-chrome/NativeMessagingHosts/com.hizliindir.bridge.json'
                manifest = json.loads(path.read_text())
                from browser_setup import extension_id
                self.assertEqual(set(manifest['allowed_origins']), {'chrome-extension://' + 'a' * 32 + '/', 'chrome-extension://' + extension_id() + '/'})
                self.assertTrue(Path(manifest['path']).exists())
                install('chrome', None, remove=True)
                self.assertFalse(path.exists())
                with self.assertRaises(ValueError):
                    install('edge', '../invalid')

    def test_expired_requests_do_not_open_a_dialog(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            inbox = data / 'inbox'
            inbox.mkdir()
            (inbox / 'old.json').write_text(json.dumps({'url': 'https://example.com/a', 'expires': 0}))
            (inbox / 'bad.json').write_text('{}')
            receive_requests(data, lambda _: self.fail('Must not show stale request'))
            self.assertEqual(list(inbox.iterdir()), [])


if __name__ == '__main__':
    unittest.main()
