// Exercise the actual service worker with mocked browser APIs.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

async function run({enabled = true, nativeFails = false, pauseFails = false, cancelFails = false, eraseFails = false, firefox = false, direct = false, response = {}, ui = false, uiFails = false, toggle, tab, existingTab = false, committed = false} = {}) {
  const calls = [];
  const uiCalls = [];
  let changeListener;
  let created;
  let updated;
  const scheduled = [];
  const chrome = {
    storage: {local: {get: async () => ({enabled}), set: async () => {}}, onChanged: {addListener(fn) {changeListener = fn;}}},
    action: {setBadgeText: async () => {}, setBadgeBackgroundColor: async () => {}},
    runtime: {onInstalled: {addListener() {}}, onStartup: {addListener() {}}, sendNativeMessage: async (host, value) => {
      calls.push(['native', value.url]);
      return nativeFails ? {ok: false, error: 'Unavailable'} : {ok: true};
    }},
    contextMenus: {onClicked: {addListener() {}}},
    webRequest: {onHeadersReceived: {addListener() {}}},
    downloads: {
      onCreated: {addListener() {}},
      pause: async id => { calls.push(['pause', id]); if (pauseFails) throw Error('Finished'); },
      cancel: async id => { calls.push(['cancel', id]); if (cancelFails) throw Error('Cancel failed'); },
      erase: async query => { calls.push(['erase', query.id]); if (eraseFails) throw Error('Erase failed'); return [query.id]; },
      resume: async id => calls.push(['resume', id])
    }
  };
  if (tab) chrome.tabs = {
    onCreated: {addListener(fn) {created = fn;}},
    onUpdated: {addListener(fn) {updated = fn;}},
    onRemoved: {addListener() {}},
    get: async () => ({id:8, url:'about:blank', openerTabId:1, ...tab}),
    remove: async id => calls.push(['close-tab', id])
  };
  if (!firefox) chrome.downloads.setUiOptions = async options => {
    uiCalls.push(options.enabled);
    if (uiFails) throw Error('UI unavailable');
  };
  const extras = {URL, setTimeout: fn => scheduled.push(fn)};
  const context = vm.createContext(firefox ? {browser: chrome, ...extras} : {chrome, ...extras});
  vm.runInContext(fs.readFileSync('browser-extension/background.js', 'utf8'), context);
  if (tab && !existingTab) created({id:8, url:'about:blank', openerTabId:1, ...tab});
  if (tab && committed) updated(8, {status:'complete', url:'https://example.com/page'});
  if (direct) {
    vm.runInContext(fs.readFileSync('browser-extension-firefox/direct-capture.js', 'utf8'), context);
    context.response = {tabId:8, method: 'GET', statusCode: 200, url: 'https://example.com/file.zip',
      responseHeaders: [{name: 'Content-Disposition', value: 'attachment; filename="file.zip"'}], ...response};
    const result = await vm.runInContext('captureResponse(response)', context);
    calls.push(['result', Boolean(result.cancel)]);
    for (const fn of scheduled) await fn();
  } else {
    await vm.runInContext("capture({id: 7, state: 'in_progress', url: 'https://example.com/file.zip'})", context);
  }
  if (toggle !== undefined) {
    changeListener({enabled: {newValue: toggle}}, 'local');
    await Promise.resolve();
  }
  return ui ? {calls, uiCalls} : calls;
}
(async () => {
  assert.deepEqual((await run()).map(x => x[0]), ['pause', 'native', 'cancel', 'erase']);
  assert.deepEqual((await run()).at(-1), ['erase', 7]);
  assert.deepEqual((await run({eraseFails: true})).map(x => x[0]), ['pause', 'native', 'cancel', 'erase']);
  assert.deepEqual((await run({nativeFails: true})).map(x => x[0]), ['pause', 'native', 'resume']);
  assert.deepEqual(await run({enabled: false}), []);
  assert.deepEqual((await run({pauseFails: true})).map(x => x[0]), ['pause']);
  assert.deepEqual((await run({cancelFails: true})).map(x => x[0]), ['pause', 'native', 'cancel']);
  assert.deepEqual((await run({firefox: true})).map(x => x[0]), ['pause', 'native', 'cancel', 'erase']);
  assert.deepEqual((await run({firefox: true, nativeFails: true})).map(x => x[0]), ['pause', 'native', 'resume']);
  assert.deepEqual(await run({firefox: true, direct: true}), [['native', 'https://example.com/file.zip'], ['result', true]]);
  assert.deepEqual(await run({firefox: true, direct: true, nativeFails: true}), [['native', 'https://example.com/file.zip'], ['result', false]]);
  for (const response of [{method:'POST'}, {statusCode:302}, {responseHeaders:[]},
    {responseHeaders:[{name:'Content-Disposition', value:'inline'}]}, {url:'file:///private'}]) {
    assert.deepEqual(await run({firefox: true, direct: true, response}), [['result', false]]);
  }
  assert.deepEqual(await run({firefox:true, direct:true, enabled:false}), [['result', false]]);
  for (const response of [{statusCode:206},
    {responseHeaders:[{name:'Content-Type',value:'application/octet-stream'}]},
    {responseHeaders:[{name:'Content-Type',value:'application/zip; charset=binary'}]}]) {
    assert.deepEqual(await run({firefox:true,direct:true,response}),
      [['native','https://example.com/file.zip'],['result',true]]);
  }
  for (const responseHeaders of [[{name:'Content-Type',value:'text/html'}],
    [{name:'Content-Type',value:'video/mp4'}],
    [{name:'Content-Disposition',value:'inline'},{name:'Content-Type',value:'application/octet-stream'}]]) {
    assert.deepEqual(await run({firefox:true,direct:true,response:{responseHeaders}}), [['result',false]]);
  }
  assert.ok((await run({ui:true})).uiCalls.every(value => value === false));
  assert.equal((await run({ui:true,enabled:false})).uiCalls.at(-1), true);
  assert.equal((await run({ui:true,nativeFails:true})).uiCalls.at(-1), true);
  assert.equal((await run({ui:true,pauseFails:true})).uiCalls.at(-1), true);
  assert.equal((await run({ui:true,toggle:false})).uiCalls.at(-1), true);
  assert.equal((await run({ui:true,enabled:false,toggle:true})).uiCalls.at(-1), false);
  assert.deepEqual((await run({uiFails:true})).map(x => x[0]), ['pause', 'native', 'cancel', 'erase']);
  assert.deepEqual((await run({firefox:true,ui:true})).uiCalls, []);
  assert.equal((await run({firefox:true,direct:true,tab:{}})).at(-1)[0], 'close-tab');
  for (const values of [{tab:{pinned:true}}, {tab:{},existingTab:true},
    {tab:{},committed:true}, {tab:{url:'https://example.com/source'}},
    {tab:{pendingUrl:'https://example.com/other'}}, {tab:{},nativeFails:true}]) {
    assert.ok(!(await run({firefox:true,direct:true,...values})).some(call => call[0] === 'close-tab'));
  }
  console.log('39 browser handoff, response interception and safe tab cleanup checks passed');
})().catch(error => {console.error(error); process.exitCode = 1;});
