import contextlib
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from tools import package_extension


class ExtensionPackageTests(unittest.TestCase):
    def test_changed_archive_is_replaced_without_truncating_loaded_destination(self):
        with tempfile.TemporaryDirectory() as directory:
            source, target = Path(directory) / 'new.zip', Path(directory) / 'loaded.zip'
            source.write_bytes(b'new archive')
            target.write_bytes(b'loaded archive')
            copy = shutil.copyfile
            def guarded_copy(left, right):
                self.assertNotEqual(Path(right), target)
                return copy(left, right)
            with patch('tools.package_extension.shutil.copyfile', side_effect=guarded_copy):
                package_extension.copy_if_changed(source, target)
            self.assertEqual(target.read_bytes(), b'new archive')
            self.assertFalse(list(Path(directory).glob('.fdm-package-*')))

    def test_unchanged_open_zip_is_not_replaced_for_timestamp_changes(self):
        with tempfile.TemporaryDirectory() as directory:
            left, right = Path(directory) / 'left.zip', Path(directory) / 'right.zip'
            for path, year in ((left, 2026), (right, 2025)):
                with zipfile.ZipFile(path, 'w') as archive:
                    archive.writestr(zipfile.ZipInfo('manifest.json', (year, 1, 1, 0, 0, 0)), '{}')
            before = right.read_bytes()
            with patch('tools.package_extension.shutil.copyfile', side_effect=PermissionError('ZIP in use')):
                package_extension.copy_if_changed(left, right)
            self.assertEqual(right.read_bytes(), before)

    def test_store_archive_has_complete_resources_and_no_development_identity(self):
        source = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'assets').mkdir()
            for folder in ('browser-extension', 'browser-extension-firefox'):
                shutil.copytree(source / folder, root / folder)
            (root / 'browser-extension' / 'private.pem').write_text('not for distribution')
            with patch.object(package_extension, 'ROOT', root), contextlib.redirect_stdout(io.StringIO()):
                package_extension.build()
            version = json.loads((root / 'browser-extension/manifest.json').read_text(encoding='utf-8'))['version']
            store = root / f'dist/FullDownloadManager-Chromium-{version}-STORE.zip'
            with zipfile.ZipFile(store) as archive:
                manifest = json.loads(archive.read('manifest.json'))
                self.assertNotIn('key', manifest)
                self.assertNotIn('webRequestBlocking', manifest['permissions'])
                self.assertNotIn('host_permissions', manifest)
                self.assertIn('downloads.ui', manifest['permissions'])
                self.assertIn('tabs', manifest['permissions'])
                self.assertNotIn('private.pem', archive.namelist())
                self.assertNotIn('direct-capture.js', archive.namelist())
                for name in [manifest['background']['service_worker'], manifest['action']['default_popup'],
                             *manifest['icons'].values(), 'popup.js',
                             *manifest['content_scripts'][0]['js']]:
                    self.assertIn(name, archive.namelist())
            self.assertIn('key', json.loads((root / 'browser-extension/manifest.json').read_text(encoding='utf-8')))
            self.assertEqual(store.read_bytes(), (root / 'assets/FullDownloadManager-Chromium-STORE.zip').read_bytes())
            with zipfile.ZipFile(root / f'dist/FullDownloadManager-Chromium-{version}-UNPACKED.zip') as archive:
                self.assertIn('key', json.loads(archive.read('manifest.json')))
            with zipfile.ZipFile(root / f'dist/FullDownloadManager-Firefox-{version}-TEMPORARY.zip') as archive:
                self.assertIn('direct-capture.js', archive.namelist())
                manifest = json.loads(archive.read('manifest.json'))
                self.assertIn('click-capture.js', manifest['content_scripts'][0]['js'])
                self.assertEqual(archive.read('click-capture.js'),
                                 (root / 'browser-extension/click-capture.js').read_bytes())


if __name__ == '__main__':
    unittest.main()
