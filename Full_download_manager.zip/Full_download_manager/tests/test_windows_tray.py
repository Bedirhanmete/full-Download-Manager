import ctypes
import os
import unittest

from windows_tray import WindowsTray


@unittest.skipUnless(os.name == 'nt', 'Windows notification icon')
class TrayTests(unittest.TestCase):
    def test_real_icon_message_loop_dispatches_and_stops(self):
        tray = WindowsTray().start()
        try:
            self.assertIsNone(tray.error)
            self.assertTrue(tray.handle)
            ctypes.windll.user32.PostMessageW(tray.handle, 0x8001, 1, 0x0202)
            self.assertEqual(tray.events.get(timeout=2), 'show')
        finally:
            tray.stop()
            tray.thread.join(timeout=3)
        self.assertFalse(tray.thread.is_alive())
        self.assertIsNone(tray.handle)


if __name__ == '__main__':
    unittest.main()
