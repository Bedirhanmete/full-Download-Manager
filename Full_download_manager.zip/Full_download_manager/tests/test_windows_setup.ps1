﻿# Offline installer checks. Run with powershell -NoProfile -ExecutionPolicy Bypass -File tests/test_windows_setup.ps1
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path $PSScriptRoot) 'windows_setup.ps1') -FunctionsOnly
function Assert($Value, $Message) { if (-not $Value) { throw $Message } }
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('hizli-setup-test-' + [guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $testRoot)
$runtimeRoot = $testRoot
$pythonRoot = Join-Path $testRoot 'Python313'
$ariaRoot = Join-Path $testRoot 'aria2'
function Show-Status([string]$Text) {}
try {
    $result = Invoke-Hidden "$env:SystemRoot\System32\cmd.exe" '/d /c echo hidden-process-ok' 10
    Assert ($result.ExitCode -eq 0 -and $result.Output -eq 'hidden-process-ok') 'Hidden process output failed'
    Assert (-not (Test-Python (Join-Path $testRoot 'missing.exe'))) 'Missing Python accepted'

    # Reproduce the reported failure under a Western Windows pipe encoding,
    # then verify Invoke-Hidden overrides it for both stdout and stderr.
    $python = Find-Python
    Assert ([bool]$python) 'A real Python interpreter is required for encoding regression checks'
    $savedIOEncoding = $env:PYTHONIOENCODING
    $savedUTF8 = $env:PYTHONUTF8
    try {
        $env:PYTHONIOENCODING = 'cp1252:strict'
        $env:PYTHONUTF8 = '0'
        $baseline = New-Object Diagnostics.ProcessStartInfo
        $baseline.FileName = $python
        $baseline.Arguments = '-c "print(chr(0x11f))"'
        $baseline.UseShellExecute = $false
        $baseline.CreateNoWindow = $true
        $baseline.RedirectStandardOutput = $true
        $baseline.RedirectStandardError = $true
        $baselineProcess = [Diagnostics.Process]::Start($baseline)
        try {
            $baselineError = $baselineProcess.StandardError.ReadToEnd()
            $baselineProcess.WaitForExit()
            Assert ($baselineProcess.ExitCode -ne 0 -and $baselineError.Contains('UnicodeEncodeError')) 'Original cp1252 failure was not reproduced'
        } finally { $baselineProcess.Dispose() }
        $encoded = Invoke-Hidden $python '-c "import sys; print(chr(0x11f)); print(chr(0x130), file=sys.stderr)"' 30
        Assert ($encoded.ExitCode -eq 0) 'UTF-8 subprocess failed'
        Assert ($encoded.Output -eq [string][char]0x11f) 'Turkish stdout was corrupted'
        Assert ($encoded.ErrorText -eq [string][char]0x130) 'Turkish stderr was corrupted'
        $setupScript = Join-Path (Split-Path $PSScriptRoot) 'windows_setup.ps1'
        $shellArguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command ". ''{0}'' -Headless -FunctionsOnly; Show-Status ([string][char]0x11f)"' -f $setupScript
        $headlessOutput = Invoke-Hidden (Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe') $shellArguments 30
        Assert ($headlessOutput.ExitCode -eq 0 -and $headlessOutput.Output -eq [string][char]0x11f) 'Headless installer output was not UTF-8'
    } finally {
        $env:PYTHONIOENCODING = $savedIOEncoding
        $env:PYTHONUTF8 = $savedUTF8
    }

    # Conflicting Tcl/Python settings must not reject a healthy interpreter,
    # and cleaning a child process must not change the user's environment.
    $savedOverrides = @{}
    $overrideNames = @('PYTHONHOME', 'PYTHONPATH', 'TCL_LIBRARY', 'TK_LIBRARY')
    try {
        foreach ($name in $overrideNames) {
            $savedOverrides[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
            [Environment]::SetEnvironmentVariable($name, 'C:\nonexistent-fdm-test-library', 'Process')
        }
        Assert (Test-Python $python) 'Healthy Tkinter rejected because of inherited environment overrides'
        foreach ($name in $overrideNames) {
            Assert ([Environment]::GetEnvironmentVariable($name, 'Process') -eq 'C:\nonexistent-fdm-test-library') 'Parent environment was modified'
        }
    } finally {
        foreach ($name in $overrideNames) { [Environment]::SetEnvironmentVariable($name, $savedOverrides[$name], 'Process') }
    }

    # Corrupt downloads must never be extracted or executed.
    function Receive-File([string]$Url, [string]$Destination) {
        [IO.File]::WriteAllText($Destination, 'invalid download')
    }
    $rejected = $false
    try { Install-Aria } catch { $rejected = $_.Exception.Message -like '*bütünlüğü*' }
    Assert $rejected 'Corrupt aria2 download was not rejected'
    Assert (-not (Test-Path $ariaRoot)) 'Corrupt aria2 was extracted'
    $rejected = $false
    try { Install-Python } catch { $rejected = $_.Exception.Message -like '*imzası*' }
    Assert $rejected 'Unsigned Python installer was not rejected'

    # A valid cached interpreter must be reused without needing PATH or a download.
    function Test-Python([string]$File) { return ($File -eq 'cached-python.exe') }
    Set-Content -LiteralPath (Join-Path $runtimeRoot 'python-path.txt') -Value 'cached-python.exe' -Encoding UTF8
    Assert ((Find-Python) -eq 'cached-python.exe') 'Cached Python was not reused'

    # Simulate the signed installer succeeding in the requested directory OR
    # updating an already installed Python elsewhere, without running it.
    function Get-AuthenticodeSignature { return [pscustomobject]@{Status='Valid'; SignerCertificate=[pscustomobject]@{Subject='Python Software Foundation'}} }
    $script:installerExitCode = 0
    $script:repairCandidate = $null
    function Invoke-Hidden([string]$File, [string]$Arguments, [int]$TimeoutSeconds = 900) {
        Assert ($File -eq (Join-Path $runtimeRoot 'python-installer.exe')) 'Unexpected subprocess in installer simulation'
        Assert ($Arguments.Contains('Include_tcltk=1') -and $Arguments.Contains('/log')) 'Tkinter or install logging option missing'
        if ($Arguments.Contains('/repair') -and $script:repairCandidate) { $script:installedCandidate = $script:repairCandidate }
        return [pscustomobject]@{ExitCode=$script:installerExitCode; Output=''; ErrorText='fixture installer error'}
    }
    function Test-Python([string]$File) {
        if ($File -eq $script:installedCandidate) { return $true }
        Save-PythonDiagnostic $File 'fixture: requested Python/Tkinter unavailable'
        return $false
    }
    function Find-Python { return $script:installedCandidate }
    foreach ($candidate in @((Join-Path $pythonRoot 'python.exe'), (Join-Path $testRoot 'existing-python/python.exe'))) {
        $script:installedCandidate = $candidate
        Assert ((Install-Python) -eq $candidate) 'Working interpreter was not accepted after installation'
    }
    $script:installerExitCode = 3010
    Assert ((Install-Python) -eq $script:installedCandidate) 'Working relocated Python rejected with reboot exit code'
    $script:installedCandidate = $null
    $script:repairCandidate = Join-Path $testRoot 'repaired-python/python.exe'
    Assert ((Install-Python) -eq $script:repairCandidate) 'Successful Tkinter repair was not accepted'
    $script:repairCandidate = $null
    $script:installedCandidate = $null
    $rejected = $false
    try { Install-Python } catch {
        $rejected = $_.Exception.Message.Contains('python-validation.log') -and $_.Exception.Message.Contains('python-install.log')
    }
    Assert $rejected 'Missing Tkinter failure did not include diagnostic log paths'
    Assert (Test-Path -LiteralPath (Join-Path $runtimeRoot 'python-validation.log')) 'Detailed validation log missing'
    $script:installerExitCode = 1603
    $rejected = $false
    try { Install-Python } catch { $rejected = $_.Exception.Message.Contains('1603') }
    Assert $rejected 'Installer failure was incorrectly accepted'
    Write-Output 'Windows setup checks passed: encoding, Tcl environment isolation, cached/private/relocated Python, exit codes and diagnostics'
} finally {
    # testRoot is an absolute, unique directory created by this test.
    if ((Split-Path $testRoot) -ne [IO.Path]::GetTempPath().TrimEnd('\')) { throw 'Unsafe test cleanup path' }
    Remove-Item -LiteralPath $testRoot -Recurse -Force
}
