import contextlib
import io
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch
from urllib.parse import quote

from protocol_handler import decode_link
from setup_browser import FIREFOX_ID, TARGETS, install, manifest_path, registry_key
from setup_protocol import desktop_quote, apple_string
from browser_setup import extension_id


class BrowserSupportTests(unittest.TestCase):
    @unittest.skipUnless(__import__('os').name == 'nt', 'Windows pythonw host registration')
    def test_windowless_guide_registers_console_python_for_native_pipes(self):
        registry = types.SimpleNamespace(HKEY_CURRENT_USER=1, REG_SZ=1, CreateKey=MagicMock(), SetValueEx=MagicMock())
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'python.exe').write_bytes(b'fixture')
            with patch('pathlib.Path.home', return_value=root), patch('sys.platform', 'win32'), \
                 patch('sys.executable', str(root / 'pythonw.exe')), \
                 patch.dict('sys.modules', {'winreg': registry}), contextlib.redirect_stdout(io.StringIO()):
                install('chrome', 'a' * 32)
            launcher = (root / '.hizli-indir/browser-host.bat').read_text(encoding='utf-8')
            self.assertIn(str(root / 'python.exe'), launcher)
            self.assertNotIn('pythonw.exe', launcher)

    def test_target_paths_are_user_level_and_firefox_format_differs(self):
        home = Path('/test-home')
        for platform in ('linux', 'darwin', 'win32'):
            for target in TARGETS:
                self.assertTrue(manifest_path(target, home, platform).is_relative_to(home))
        self.assertIn('native-messaging-hosts', str(manifest_path('firefox', home, 'linux')))
        self.assertIn('Mozilla', registry_key('firefox'))
        self.assertEqual(registry_key('brave'), registry_key('chrome'))

    def test_install_all_linux_profiles_and_remove_independently(self):
        with tempfile.TemporaryDirectory() as tmp, patch('pathlib.Path.home', return_value=Path(tmp)), patch('sys.platform', 'linux'), contextlib.redirect_stdout(io.StringIO()):
            for target in TARGETS:
                install(target, None if target == 'firefox' else 'a' * 32)
                value = json.loads(manifest_path(target).read_text())
                if target == 'firefox':
                    self.assertEqual(value['allowed_extensions'], [FIREFOX_ID])
                    self.assertNotIn('allowed_origins', value)
                else:
                    self.assertEqual(set(value['allowed_origins']), {'chrome-extension://' + 'a' * 32 + '/', 'chrome-extension://' + extension_id() + '/'})
            install('brave', None, remove=True)
            self.assertFalse(manifest_path('brave').exists())
            self.assertTrue(manifest_path('chrome').exists())
            self.assertTrue(manifest_path('firefox').exists())

    def test_shared_windows_host_keeps_other_extension_ids(self):
        registry = types.SimpleNamespace(HKEY_CURRENT_USER=1, REG_SZ=1, CreateKey=MagicMock(), SetValueEx=MagicMock(), DeleteKey=MagicMock())
        with tempfile.TemporaryDirectory() as tmp, patch('pathlib.Path.home', return_value=Path(tmp)), patch('sys.platform', 'win32'), patch.dict('sys.modules', {'winreg': registry}), contextlib.redirect_stdout(io.StringIO()):
            install('chrome', 'a' * 32)
            install('brave', 'b' * 32)
            content = json.loads(manifest_path('chrome').read_text())
            self.assertEqual(len(content['allowed_origins']), 3)
            install('brave', None, remove=True)
            content = json.loads(manifest_path('chrome').read_text())
            self.assertEqual(set(content['allowed_origins']), {'chrome-extension://' + 'a' * 32 + '/', 'chrome-extension://' + extension_id() + '/'})
            registry.DeleteKey.assert_not_called()

    def test_linux_protocol_install_and_remove_restore_previous_handler(self):
        from setup_protocol import install as install_protocol
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            environment = {'XDG_DATA_HOME': str(home / 'data'), 'XDG_CONFIG_HOME': str(home / 'config')}
            with patch('pathlib.Path.home', return_value=home), patch('sys.platform', 'linux'), patch.dict('os.environ', environment), patch('setup_protocol.subprocess.run', return_value=types.SimpleNamespace(stdout='old-handler.desktop\n')) as command, contextlib.redirect_stdout(io.StringIO()):
                install_protocol()
                desktop = home / 'data/applications/hizli-indir-url.desktop'
                self.assertIn(' %u', desktop.read_text())
                self.assertIn('protocol_handler.py', desktop.read_text())
                install_protocol(remove=True)
                self.assertFalse(desktop.exists())
                command.assert_called_with(['xdg-mime', 'default', 'old-handler.desktop', 'x-scheme-handler/hizli-indir'], check=True)

    def test_protocol_roundtrip_and_invalid_schemes(self):
        url = 'https://example.com/dosya.zip?token=a%2Fb&name=Türkçe'
        self.assertEqual(decode_link('hizli-indir://download?url=' + quote(url, safe='')),
                         {'action': 'download', 'url': url})
        for link in ['https://download?url=https://a', 'hizli-indir://else?url=https://a',
                     'hizli-indir://download?url=file:///etc/passwd',
                     'hizli-indir://download?url=https://a&url=https://b',
                     'hizli-indir://download?url=https://a&extra=x',
                     'hizli-indir://download?url=https://a#x']:
            with self.assertRaises(ValueError):
                decode_link(link)

    def test_platform_launcher_escaping_and_extension_sources(self):
        self.assertEqual(desktop_quote('/a b/50%/file'), '"/a b/50%%/file"')
        self.assertEqual(apple_string('a"b'), '"a\\"b"')
        root = Path(__file__).resolve().parents[1]
        for name in ('background.js', 'popup.js', 'popup.html'):
            self.assertEqual((root / 'browser-extension' / name).read_bytes(),
                             (root / 'browser-extension-firefox' / name).read_bytes())
        manifest = json.loads((root / 'browser-extension-firefox/manifest.json').read_text())
        self.assertEqual(manifest['browser_specific_settings']['gecko']['id'], FIREFOX_ID)
        self.assertIn('scripts', manifest['background'])
        self.assertNotIn('service_worker', manifest['background'])


if __name__ == '__main__':
    unittest.main()
