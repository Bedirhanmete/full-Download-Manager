import json
from pathlib import Path
import tempfile
import unittest

import preferences
from i18n import STRINGS, text, transfer_speed, link_speed


class PreferencesTests(unittest.TestCase):
    def test_language_and_network_settings_persist(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'settings.json'
            values = dict(preferences.DEFAULTS, language='en', connections=8,
                          concurrent_downloads=2, internet_mbps=500)
            preferences.save(values, path)
            self.assertEqual(preferences.load(path), values)
            self.assertFalse(path.with_name('settings.json.tmp').exists())

    def test_bad_or_partial_settings_keep_safe_defaults(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'settings.json'
            path.write_text('{broken', encoding='utf-8')
            self.assertEqual(preferences.load(path), preferences.DEFAULTS)
            values = preferences.normalize({'language': 'xx', 'connections': 33,
                                            'concurrent_downloads': -1, 'internet_mbps': float('nan')})
            self.assertEqual(values, preferences.DEFAULTS)

    def test_32_connections_persist(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'settings.json'
            preferences.save(dict(preferences.DEFAULTS, connections=32), path)
            self.assertEqual(preferences.load(path)['connections'], 32)

    def test_decimal_speed_units_match_isp_units(self):
        self.assertEqual(transfer_speed(62_500_000), '62.50 MB/s')
        self.assertEqual(link_speed(62_500_000), 500)
        self.assertEqual(link_speed(-1), 0)

    def test_all_translations_keep_the_same_format_parameters(self):
        from string import Formatter
        fields = lambda value: {name for _, name, _, _ in Formatter().parse(value) if name is not None}
        for key, pair in STRINGS.items():
            with self.subTest(key=key):
                self.assertTrue(all(pair))
                self.assertEqual(fields(pair[0]), fields(pair[1]))

