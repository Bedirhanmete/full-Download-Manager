# Exercise actual removal only under an isolated, unique temporary directory.
$ErrorActionPreference = 'Stop'
$project = Split-Path $PSScriptRoot
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('fdm-uninstall-test-' + [guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $testRoot)
function Assert($Value, $Message) { if (-not $Value) { throw $Message } }
try {
    $local = Join-Path $testRoot 'local'
    $profile = Join-Path $testRoot 'profile'
    $settings = Join-Path $profile '.hizli-indir/settings.json'
    [void](New-Item -ItemType Directory -Path (Split-Path $settings) -Force)
    Set-Content -LiteralPath $settings -Value 'preserve settings'
    $download = Join-Path $testRoot 'download.iso'
    Set-Content -LiteralPath $download -Value 'preserve download'
    foreach ($name in @('Full Download Manager', 'HizliIndir')) {
        $app = Join-Path $local ($name + '/app')
        [void](New-Item -ItemType Directory -Path $app -Force)
        Copy-Item -LiteralPath (Join-Path $project 'windows_uninstall.ps1') -Destination $app
        Set-Content -LiteralPath (Join-Path $app 'FullDownloadManager.exe') -Value 'fixture'
        Set-Content -LiteralPath (Join-Path $app 'windows_setup.ps1') -Value 'param([switch]$FunctionsOnly); function Find-Python { return $null }'
        $cache = Join-Path $local ($name + '/aria2')
        [void](New-Item -ItemType Directory -Path $cache)
        Set-Content -LiteralPath (Join-Path $cache 'aria2c.exe') -Value 'preserve runtime'
    }
    # Registry and shortcuts are mocked; the real user account is untouched.
    $bootstrap = Join-Path $testRoot 'run.ps1'
    $script = @'
$ErrorActionPreference = 'Stop'
function Test-Path {
    param([string]$LiteralPath)
    if ($LiteralPath -like 'HKCU:*') { return $false }
    Microsoft.PowerShell.Management\Test-Path -LiteralPath $LiteralPath
}
function New-Object {
    param([string]$ComObject)
    if ($ComObject -ne 'WScript.Shell') { throw 'Unexpected COM object' }
    $shell = [pscustomobject]@{}
    $shell | Add-Member -MemberType ScriptMethod -Name CreateShortcut -Value { param($path); return [pscustomobject]@{WorkingDirectory='not-our-install'} }
    return $shell
}
. (Join-Path $env:LOCALAPPDATA 'Full Download Manager/app/windows_uninstall.ps1') -Quiet
Write-Output 'isolated uninstall completed'
'@
    Set-Content -LiteralPath $bootstrap -Value $script -Encoding UTF8
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
    $info.Arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $bootstrap + '"'
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.EnvironmentVariables['LOCALAPPDATA'] = $local
    $info.EnvironmentVariables['USERPROFILE'] = $profile
    $process = [Diagnostics.Process]::Start($info)
    $outputTask = $process.StandardOutput.ReadToEndAsync()
    $errorTask = $process.StandardError.ReadToEndAsync()
    try {
        if (-not $process.WaitForExit(15000)) {
            $process.Kill()
            Write-Output (($outputTask.GetAwaiter().GetResult() -split "`n" | Select-Object -Last 55) -join "`n")
            throw 'Isolated uninstaller timed out'
        }
        $errors = $errorTask.GetAwaiter().GetResult()
        Assert ($process.ExitCode -eq 0) $errors
    } finally { $process.Dispose() }
    foreach ($name in @('Full Download Manager', 'HizliIndir')) {
        Assert (-not (Test-Path -LiteralPath (Join-Path $local ($name + '/app')))) 'Installed application directory was not removed'
        Assert (Test-Path -LiteralPath (Join-Path $local ($name + '/aria2/aria2c.exe'))) 'Shared runtime was removed'
    }
    Assert (Test-Path -LiteralPath $settings) 'User settings were removed'
    Assert (Test-Path -LiteralPath $download) 'User download was removed'
    $info.Arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + (Join-Path $project 'windows_uninstall.ps1') + '" -Quiet'
    $guardProcess = [Diagnostics.Process]::Start($info)
    try {
        $guardError = $guardProcess.StandardError.ReadToEndAsync()
        $guardOutput = $guardProcess.StandardOutput.ReadToEndAsync()
        if (-not $guardProcess.WaitForExit(10000)) { $guardProcess.Kill(); throw 'Path guard timed out' }
        Assert ($guardProcess.ExitCode -ne 0) 'Uninstaller accepted an unrelated folder'
    } finally { $guardProcess.Dispose() }
    Write-Output 'Uninstaller passed: new/legacy apps removed; downloads, settings and runtimes preserved.'
} finally {
    $resolved = [IO.Path]::GetFullPath($testRoot)
    $parent = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')
    if ((Split-Path $resolved -Parent) -ne $parent -or (Split-Path $resolved -Leaf) -notlike 'fdm-uninstall-test-*') { throw 'Unsafe test cleanup path' }
    Remove-Item -LiteralPath $resolved -Recurse -Force
}
