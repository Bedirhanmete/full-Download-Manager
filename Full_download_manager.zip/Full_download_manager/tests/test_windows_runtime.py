"""Windows runtime discovery works without modifying the user's PATH."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from app import find_aria2


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.discovery = patch('app.bundled_aria2', return_value=None)
        self.bundled = self.discovery.start()
        self.addCleanup(self.discovery.stop)

    def test_bundled_32_connection_runtime_is_preferred(self):
        self.bundled.return_value = 'bundled-32-connection-engine'
        with patch('app.sys.platform', 'win32'):
            self.assertEqual(find_aria2(), 'bundled-32-connection-engine')

    def test_full_product_name_is_preferred_over_legacy_runtime(self):
        with tempfile.TemporaryDirectory() as directory:
            for name in ('HizliIndir', 'Full Download Manager'):
                binary = Path(directory) / name / 'aria2/aria2c.exe'
                binary.parent.mkdir(parents=True)
                binary.touch()
            with patch('app.sys.platform', 'win32'), patch.dict(os.environ, {'LOCALAPPDATA': directory}):
                self.assertEqual(find_aria2(), str(Path(directory) / 'Full Download Manager/aria2/aria2c.exe'))
    def test_private_runtime_without_path(self):
        with tempfile.TemporaryDirectory() as directory:
            binary = Path(directory) / 'HizliIndir' / 'aria2' / 'aria2c.exe'
            binary.parent.mkdir(parents=True)
            binary.touch()
            with patch('app.sys.platform', 'win32'), patch.dict(os.environ, {'LOCALAPPDATA': directory}), patch('app.shutil.which', return_value=None):
                self.assertEqual(find_aria2(), str(binary))

    def test_missing_private_runtime_falls_back_to_path(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch('app.sys.platform', 'win32'), patch.dict(os.environ, {'LOCALAPPDATA': directory}), patch('app.shutil.which', return_value='existing-aria2'):
                self.assertEqual(find_aria2(), 'existing-aria2')

    def test_non_windows_uses_path(self):
        with patch('app.sys.platform', 'linux'), patch('app.shutil.which', return_value='/usr/bin/aria2c'):
            self.assertEqual(find_aria2(), '/usr/bin/aria2c')
