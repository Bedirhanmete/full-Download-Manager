import json
import os
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

import extension_install


class FakeRegistry:
    HKEY_CURRENT_USER = 1
    REG_SZ = 1
    def __init__(self):
        self.values = {}
        self.writes = []
    def OpenKey(self, hive, path):
        assert hive == self.HKEY_CURRENT_USER
        if path not in self.values:
            raise FileNotFoundError(path)
        class Key:
            def __enter__(self): return path
            def __exit__(self, *args): return False
        return Key()
    def CreateKey(self, hive, path):
        assert hive == self.HKEY_CURRENT_USER
        assert '\\Policies\\' not in path
        self.values.setdefault(path, {})
        return self.OpenKey(hive, path)
    def QueryValueEx(self, key, name):
        if name not in self.values[key]:
            raise FileNotFoundError(name)
        return self.values[key][name], self.REG_SZ
    def SetValueEx(self, key, name, reserved, kind, value):
        self.values[key][name] = value
        self.writes.append((key, name, value))
    def DeleteKey(self, hive, path):
        assert hive == self.HKEY_CURRENT_USER
        del self.values[path]


class ExtensionInstallTests(unittest.TestCase):
    def test_request_is_not_registered_if_ownership_journal_cannot_be_saved(self):
        registry = FakeRegistry()
        with tempfile.TemporaryDirectory() as directory, patch('pathlib.Path.home', return_value=Path(directory)), \
             patch.dict('sys.modules', {'winreg': registry}), patch('pathlib.Path.replace', side_effect=PermissionError('journal locked')):
            with self.assertRaises(PermissionError):
                extension_install.register_request('chrome', 'a' * 32)
            self.assertEqual(registry.writes, [])

    def test_store_request_is_optional_user_registry_and_removed_on_uninstall(self):
        registry = FakeRegistry()
        with tempfile.TemporaryDirectory() as directory, patch('pathlib.Path.home', return_value=Path(directory)), \
             patch.dict('sys.modules', {'winreg': registry}):
            self.assertTrue(extension_install.register_request('chrome', 'a' * 32))
            key = extension_install.registry_path('chrome', 'a' * 32)
            self.assertEqual(registry.values[key]['update_url'], extension_install.CHROME_UPDATE)
            self.assertFalse(any('Policies' in path for path in registry.values))
            self.assertEqual(len(extension_install.load_requests()), 1)
            extension_install.remove_requests()
            self.assertEqual(registry.values, {})

    def test_other_installers_registration_is_preserved(self):
        registry = FakeRegistry()
        key = extension_install.registry_path('chrome', 'a' * 32)
        registry.values[key] = {'update_url': extension_install.CHROME_UPDATE, 'fdm_owner': 'another-installation'}
        with tempfile.TemporaryDirectory() as directory, patch('pathlib.Path.home', return_value=Path(directory)), \
             patch.dict('sys.modules', {'winreg': registry}):
            self.assertFalse(extension_install.register_request('chrome', 'a' * 32))
            self.assertEqual(registry.writes, [])
            self.assertEqual(extension_install.load_requests(), [])

    def test_changed_registration_is_preserved_during_uninstall(self):
        registry = FakeRegistry()
        with tempfile.TemporaryDirectory() as directory, patch('pathlib.Path.home', return_value=Path(directory)), \
             patch.dict('sys.modules', {'winreg': registry}):
            extension_install.register_request('chrome', 'a' * 32)
            key = extension_install.registry_path('chrome', 'a' * 32)
            registry.values[key]['fdm_owner'] = 'another-installation'
            extension_install.remove_requests()
            self.assertIn(key, registry.values)

    def test_registry_rejects_invalid_identity_and_provider(self):
        for provider, identity in [('policy', 'a' * 32), ('chrome', '../bad'), ('chrome', None)]:
            with self.assertRaises(ValueError):
                extension_install.registry_path(provider, identity)

    def test_selected_chromium_browser_opens_store_without_external_install_request(self):
        state = {'browser': 'brave', 'store_id': 'a' * 32, 'store_channel': 'chrome',
                 'store_url': 'https://chromewebstore.google.com/detail/' + 'a' * 32,
                 'extensions_url': 'brave://extensions', 'executable': __file__}
        for browser in ('chrome', 'brave', 'edge', 'opera', 'vivaldi', 'chromium'):
            selected = {**state, 'browser': browser, 'extension_id': 'a' * 32}
            with patch('browser_setup.prepare', return_value=selected) as prepare, \
                 patch('browser_setup.store_identity', return_value='a' * 32), \
                 patch('extension_install.register_request') as register, \
                 patch('extension_install.subprocess.Popen') as launch:
                result = extension_install.request_install(browser)
                prepare.assert_called_once_with(browser, None)
                self.assertEqual(launch.call_args.args[0], [__file__, state['store_url']])
                self.assertEqual(result['install_method'], 'store-page')
                register.assert_not_called()

    def test_pending_firefox_listing_opens_addons_home_with_pending_status(self):
        with patch('browser_setup.prepare', return_value={'browser':'firefox', 'store_url':'', 'executable':__file__}), \
             patch('extension_install.firefox_store_url', return_value=None), \
             patch('extension_install.register_request') as register, patch('extension_install.subprocess.Popen') as launch:
            self.assertEqual(extension_install.request_install('zen')['install_method'], 'store-pending')
            register.assert_not_called()
            self.assertEqual(launch.call_args.args[0], [__file__, 'https://addons.mozilla.org/firefox/'])

    def test_published_mozilla_listing_opens_in_selected_firefox_or_zen(self):
        url = 'https://addons.mozilla.org/tr/firefox/addon/full-download-manager/'
        self.assertEqual(extension_install.firefox_store_url(), url)
        for choice in ('firefox', 'zen'):
            with self.subTest(browser=choice), \
                 patch('browser_setup.prepare', return_value={'browser':'firefox', 'store_url':url, 'executable':__file__}) as prepare, \
                 patch('extension_install.register_request') as register, \
                 patch('extension_install.subprocess.Popen') as launch:
                result = extension_install.request_install(choice)
                prepare.assert_called_once_with(choice, None)
                self.assertEqual(result['install_method'], 'store-page')
                self.assertEqual(result['install_url'], url)
                self.assertEqual(launch.call_args.args[0], [__file__, url])
                register.assert_not_called()

    def test_missing_selected_browser_never_opens_the_default_browser(self):
        with patch('browser_setup.prepare', return_value={'browser':'firefox', 'executable':''}), \
             patch('extension_install.firefox_store_url', return_value='https://addons.mozilla.org/firefox/addon/test/'), \
             patch('extension_install.subprocess.Popen') as launch, patch('webbrowser.open') as default:
            self.assertEqual(extension_install.request_install('firefox')['install_method'], 'missing-browser')
            launch.assert_not_called()
            default.assert_not_called()

    def test_firefox_uses_only_an_official_listing(self):
        with tempfile.TemporaryDirectory() as directory, patch('extension_install.ROOT', Path(directory)):
            assets = Path(directory) / 'assets'
            assets.mkdir()
            for url, expected in [('https://addons.mozilla.org/en-US/firefox/addon/full-download-manager/', True),
                                  ('https://addons.mozilla.org.evil.test/firefox/addon/test/', False),
                                  ('javascript:alert(1)', False), ('https://addons.mozilla.org/firefox/addon/test/?next=bad', False)]:
                (assets / 'extension-stores.json').write_text(json.dumps({'firefox_url': url}))
                self.assertEqual(bool(extension_install.firefox_store_url()), expected)


if __name__ == '__main__':
    unittest.main()
