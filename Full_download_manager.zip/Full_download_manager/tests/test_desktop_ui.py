"""Exercise settings, filters, and real-value rendering without a network engine."""
import os
import gc
from pathlib import Path
import tempfile
import time
import tkinter as tk
from tkinter import ttk
import unittest
import queue
from unittest.mock import patch

from desktop_ui import FullDownloadManager
from fluent_widgets import FluentButton
import preferences


def sample_items():
    return [
        {'gid': 'one', 'status': 'active', 'totalLength': str(4_000_000_000),
         'completedLength': str(1_360_000_000), 'downloadSpeed': '40000000', 'connections': '16',
         'files': [{'path': r'C:\Downloads\Windows11_Installer.iso', 'uris': [{'uri': 'https://example.com/windows.iso'}]}]},
        {'gid': 'two', 'status': 'paused', 'totalLength': '2800000000',
         'completedLength': '1200000000', 'downloadSpeed': '0', 'connections': '0',
         'files': [{'path': r'C:\Downloads\creative_suite_installer.zip'}]},
        {'gid': 'three', 'status': 'complete', 'totalLength': '180000000',
         'completedLength': '180000000', 'downloadSpeed': '0', 'connections': '0',
         'files': [{'path': r'C:\Downloads\documentary_1080p.mp4'}]},
    ]


class FakeEngine:
    def __init__(self):
        self.configured = None
        self.closed = False
        self.calls = []
        self.items = sample_items()
        self.data = Path(tempfile.gettempdir()) / 'fdm-ui-test-unused'
    def configure(self, connections, concurrent):
        self.configured = (connections, concurrent)
    def close(self):
        self.closed = True
    def add(self, link, directory, connections):
        self.calls.append(('add', link, directory, connections))
        return 'new-gid'
    def cancel(self, gid):
        self.calls.append(('cancel', gid))
        return 'cancelled'
    def snapshot(self):
        return self.items
    def clear_history(self):
        self.calls.append(('clear_history',))
        kept = [item for item in self.items if item['status'] not in ('complete', 'error', 'removed')]
        count = len(self.items) - len(kept)
        self.items = kept
        return count
    def call(self, *args):
        self.calls.append(args)


@unittest.skipIf(os.environ.get('FDM_SKIP_GUI') == '1', 'GUI explicitly disabled')
class DesktopTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.path = Path(self.directory.name) / 'settings.json'
        self.root = tk.Tk()
        self.root.withdraw()
        self.engine = FakeEngine()
        self.ui = FullDownloadManager(self.root, self.engine,
            dict(preferences.DEFAULTS, internet_mbps=500), self.path)
        self.root.update()

    def tearDown(self):
        self.ui.pool.shutdown(wait=True)
        for identity in self.root.tk.call('after', 'info'):
            self.root.after_cancel(identity)
        self.root.destroy()
        self.ui = None
        self.root = None
        gc.collect()
        self.directory.cleanup()

    def descendants(self, parent):
        for child in parent.winfo_children():
            yield child
            yield from self.descendants(child)

    def test_filters_and_chart_use_actual_item_values(self):
        self.root.deiconify()
        self.root.update()
        self.ui.receive(sample_items(), sample=True)
        self.assertEqual(self.ui.speed, 40_000_000)
        self.assertEqual(self.ui.history[-1], 40_000_000)
        self.ui.select_filter('active')
        self.assertEqual([item['gid'] for item in self.ui.filtered_items()], ['one'])
        self.ui.select_filter('complete')
        self.assertEqual([item['gid'] for item in self.ui.filtered_items()], ['three'])
        labels = [self.ui.graph.itemcget(item, 'text') for item in self.ui.graph.find_all()
                  if self.ui.graph.type(item) == 'text']
        self.assertIn('40.00 MB/s', labels)
        self.assertIn('320.0 Mbps', labels)
        self.assertIn('Hat kullanımı: 64%', labels)

    def test_clear_button_keeps_active_and_paused_downloads(self):
        self.root.deiconify()
        self.root.update()
        self.ui.receive(self.engine.snapshot())
        self.ui.clear_button.invoke()
        self.ui.clear_button.invoke()
        until = time.monotonic() + 3
        while self.ui.clearing and time.monotonic() < until:
            self.root.update()
            time.sleep(.02)
        self.assertFalse(self.ui.clearing)
        self.assertEqual([item['gid'] for item in self.ui.items], ['one', 'two'])
        self.assertEqual(self.engine.calls, [('clear_history',)])
        self.assertEqual(self.ui.clear_button.cget('state'), 'disabled')
        self.ui.select_filter('active')
        self.assertFalse(self.ui.clear_button.winfo_manager())

    def test_32_connections_can_be_saved_from_settings(self):
        self.ui.show_settings()
        window = self.ui.dialogs[-1]
        widgets = list(self.descendants(window))
        connections = next(w for w in widgets if isinstance(w, ttk.Combobox) and '32' in w.cget('values'))
        connections.set('32')
        next(w for w in widgets if isinstance(w, FluentButton) and w.cget('text') == 'Kaydet').invoke()
        until = time.monotonic() + 3
        while self.ui.preferences['connections'] != 32 and time.monotonic() < until:
            self.root.update()
            time.sleep(.02)
        self.assertEqual(self.engine.configured, (32, 3))
        self.assertEqual(preferences.load(self.path)['connections'], 32)

    def test_browser_capture_raises_main_window_without_dialog_or_downloading(self):
        self.ui.browser_download('https://example.com/file.zip')
        self.root.update()
        window = self.root
        until = time.monotonic() + .7
        while not window.winfo_viewable() and time.monotonic() < until:
            self.root.update()
            time.sleep(.02)
        self.assertEqual(self.root.state(), 'normal')
        self.assertTrue(window.winfo_viewable())
        self.assertTrue(window.attributes('-topmost'))
        self.assertFalse(self.ui.dialogs)
        self.assertTrue(self.ui.pending_panel.winfo_viewable())
        self.assertEqual(self.ui.pending_url.get(), 'https://example.com/file.zip')
        self.assertEqual(self.engine.calls, [])
        # A short foreground pulse must not leave the app permanently topmost.
        until = time.monotonic() + 1.7
        while time.monotonic() < until:
            self.root.update()
            time.sleep(.02)
        self.assertFalse(window.attributes('-topmost'))

    def wait_pending(self):
        until = time.monotonic() + 3
        while self.ui.pending_starting and time.monotonic() < until:
            self.root.update()
            time.sleep(.02)
        self.assertFalse(self.ui.pending_starting)

    def test_captures_queue_deduplicate_and_start_only_on_download_click(self):
        first, second = 'https://example.com/one.zip', 'https://example.com/two.zip'
        for link in (first, second, first):
            self.ui.browser_download(link)
        self.assertEqual(self.ui.pending_links, [first, second])
        self.assertEqual(self.engine.calls, [])
        self.ui.pending_download_button.invoke()
        self.ui.pending_download_button.invoke()
        self.wait_pending()
        self.assertEqual(self.engine.calls, [('add', first,
            self.ui.preferences['download_directory'], 16)])
        self.assertEqual(self.ui.pending_links, [second])
        self.assertEqual(self.ui.pending_url.get(), second)
        self.ui.pending_dismiss_button.invoke()
        self.assertEqual(self.ui.pending_links, [])
        self.assertFalse(self.ui.pending_panel.winfo_manager())

    def test_failed_start_preserves_link_and_can_retry(self):
        link = 'https://example.com/retry.zip'
        self.ui.browser_download(link)
        with patch.object(self.engine, 'add', side_effect=RuntimeError('Test failure')):
            self.ui.pending_download_button.invoke()
            self.wait_pending()
        self.assertEqual(self.ui.pending_links, [link])
        self.assertIn('Test failure', self.ui.notice)
        self.ui.pending_download_button.invoke()
        self.wait_pending()
        self.assertEqual(self.ui.pending_links, [])

    def test_pending_links_survive_language_rebuild(self):
        self.ui.browser_download('https://example.com/file.zip')
        self.ui.preferences['language'] = 'en'
        self.ui.build()
        self.root.update()
        self.assertEqual(self.ui.pending_download_button.cget('text'), 'Download')
        self.assertEqual(self.ui.pending_title.cget('text'), 'Ready to download (1)')
        self.assertEqual(self.ui.pending_url.get(), 'https://example.com/file.zip')
        self.assertFalse(self.ui.dialogs)
        self.assertEqual(self.engine.calls, [])

    def test_window_close_hides_without_stopping_engine_and_capture_restores_it(self):
        self.ui.tray = type('Tray', (), {'events': queue.SimpleQueue(), 'stop': lambda _: None})()
        self.root.deiconify()
        self.root.update()
        self.assertIn('hide', self.root.protocol('WM_DELETE_WINDOW'))
        self.ui.hide()
        self.root.update()
        self.assertEqual(self.root.state(), 'withdrawn')
        self.assertFalse(self.ui.closing)
        self.assertFalse(self.engine.closed)
        self.assertEqual(self.engine.calls, [])
        self.ui.browser_download('https://example.com/wake.zip')
        self.root.update()
        self.assertEqual(self.root.state(), 'normal')
        self.assertEqual(self.ui.pending_url.get(), 'https://example.com/wake.zip')

    def test_tray_and_shortcut_restore_existing_hidden_window(self):
        self.engine.data = Path(self.directory.name)
        tray = type('Tray', (), {'events': queue.SimpleQueue(), 'stop': lambda _: None})()
        self.ui.tray = tray
        self.ui.hide()
        tray.events.put('show')
        self.ui.browser_requests()
        self.root.update()
        self.assertEqual(self.root.state(), 'normal')
        self.ui.hide()
        (self.engine.data / 'show-window').touch()
        self.ui.browser_requests()
        self.root.update()
        self.assertEqual(self.root.state(), 'normal')
        self.assertFalse((self.engine.data / 'show-window').exists())
        tray.events.put('exit')
        with patch.object(self.ui, 'close') as close:
            self.ui.browser_requests()
            close.assert_called_once()

    def test_hidden_window_keeps_latest_data_and_renders_when_restored(self):
        self.ui.receive(sample_items(), sample=True)
        self.assertEqual(self.ui.speed, 40_000_000)
        self.ui.foreground_window(self.root)
        self.root.update()
        labels = [self.ui.graph.itemcget(item, 'text') for item in self.ui.graph.find_all()
                  if self.ui.graph.type(item) == 'text']
        self.assertIn('40.00 MB/s', labels)

    def test_language_change_from_settings_persists_without_restarting_engine(self):
        self.ui.show_settings()
        window = self.ui.dialogs[-1]
        widgets = list(self.descendants(window))
        language = next(w for w in widgets if isinstance(w, ttk.Combobox) and 'English' in w.cget('values'))
        language.set('English')
        next(w for w in widgets if isinstance(w, (tk.Button, FluentButton)) and w.cget('text') == 'Kaydet').invoke()
        deadline = time.monotonic()+3
        while time.monotonic() < deadline and self.ui.language != 'en':
            self.root.update()
            time.sleep(.02)
        self.assertEqual(self.ui.language, 'en')
        self.assertEqual(preferences.load(self.path)['language'], 'en')
        self.assertEqual(self.engine.configured, (16, 3))
        self.assertEqual(self.ui.heading.cget('text'), 'All downloads')
        self.assertEqual(self.root.title(), 'Full Download Manager')
        self.assertFalse(self.ui.dialogs)

    def test_empty_state_does_not_invent_download_activity(self):
        self.assertEqual(self.ui.speed, 0)
        self.assertTrue(all(value == 0 for value in self.ui.history))
        self.assertEqual(self.ui.items, [])

    def test_fluent_button_mouse_keyboard_and_disabled_state(self):
        clicked = []
        button = self.ui.button(self.ui.body, 'Test', lambda: clicked.append(True))
        button.pack()
        self.root.deiconify()
        self.root.update()
        button.event_generate('<ButtonPress-1>', x=10, y=10)
        button.event_generate('<ButtonRelease-1>', x=10, y=10)
        self.assertEqual(len(clicked), 1)
        button.focus_force()
        self.root.update()
        button.event_generate('<Return>')
        self.assertEqual(len(clicked), 2)
        button.configure(state='disabled')
        button.invoke()
        self.assertEqual(len(clicked), 2)
        self.root.withdraw()

    def test_pause_and_resume_are_sent_to_engine(self):
        self.ui.receive(sample_items())
        self.ui.action('forcePause', 'one')
        deadline = time.monotonic()+2
        while not self.engine.calls and time.monotonic() < deadline:
            self.root.update()
            time.sleep(.02)
        self.assertIn(('forcePause', 'one'), self.engine.calls)

    def test_cancel_button_confirms_and_calls_cleanup(self):
        self.ui.receive(sample_items())
        with patch('desktop_ui.messagebox.askyesno', return_value=False):
            self.ui.cancel_download('one')
        self.assertNotIn(('cancel', 'one'), self.engine.calls)
        with patch('desktop_ui.messagebox.askyesno', return_value=True):
            self.ui.cancel_download('one')
        deadline = time.monotonic()+2
        while self.ui.cancelling and time.monotonic() < deadline:
            self.root.update()
            time.sleep(.02)
        self.assertIn(('cancel', 'one'), self.engine.calls)
        self.assertFalse(self.ui.cancelling)
        self.assertIn('kalıntıları silindi', self.ui.notice)

