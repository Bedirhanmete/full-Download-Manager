import unittest
from app import paused_session


class StartupSessionTests(unittest.TestCase):
    def test_empty_install_has_no_default_download(self):
        self.assertEqual(paused_session(''), '')

    def test_every_entry_overrides_saved_auto_resume(self):
        original = (
            'https://example.com/first.zip\n  dir=C:/Downloads\n  pause=false\n'
            'https://example.com/second.zip\n  pause=false\n  out=second.zip\n')
        result = paused_session(original)
        self.assertNotIn('pause=false', result)
        self.assertEqual(result.count('pause=true'), 2)
        self.assertIn('out=second.zip', result)
        self.assertEqual(paused_session(result), result)

    def test_existing_session_without_pause_is_made_explicit(self):
        result = paused_session('# saved session\nhttps://example.com/file.zip\n  gid=123\n')
        self.assertTrue(result.endswith('  pause=true\n'))
        self.assertIn('gid=123', result)

