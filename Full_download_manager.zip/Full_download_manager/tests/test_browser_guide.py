import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch

import browser_setup


class GuideTests(unittest.TestCase):
    def test_firefox_store_install_button_opens_selected_browser_without_signing_steps(self):
        root = tk.Tk()
        root.withdraw()
        url = 'https://addons.mozilla.org/tr/firefox/addon/full-download-manager/'
        state = {'browser':'firefox','name':'Zen','executable':__file__, 'extension_enabled':False,
                 'native_host_ready':True,'extension_path':str(browser_setup.ROOT / 'browser-extension-firefox'),
                 'permanent_package':None,'extensions_url':'about:addons',
                 'extension_id':None,'store_id':None,'store_channel':'firefox','store_url':url}
        try:
            with patch('browser_setup.prepare', return_value=state), \
                 patch('preferences.load', return_value={'language':'tr'}), \
                 patch('tkinter.Tk', return_value=root), patch.object(root,'mainloop'), \
                 patch('browser_setup.subprocess.Popen') as launch:
                browser_setup.guide('zen')
                def descendants(parent):
                    for widget in parent.winfo_children():
                        yield widget
                        yield from descendants(widget)
                widgets = list(descendants(root))
                buttons = [w for w in widgets if isinstance(w,ttk.Button)]
                store = next(w for w in buttons if w.cget('text') == 'Mağazadan kalıcı kur')
                self.assertFalse(any(w.cget('text') == 'Mozilla imzalama adımları' for w in buttons))
                self.assertTrue(any('Mozilla mağazasında yayımlandı' in str(w.cget('text'))
                                    for w in widgets if isinstance(w,ttk.Label)))
                store.invoke()
                self.assertEqual(launch.call_args.args[0], [__file__,url])
        finally:
            root.destroy()
