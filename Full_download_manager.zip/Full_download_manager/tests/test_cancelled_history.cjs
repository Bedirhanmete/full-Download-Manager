// Reproduce Zen publishing a cancelled history item after the first erase.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

async function fixture(nativeOk=true) {
  let changed, exists=true, state='in_progress';
  const erased=[];
  const event={addListener() {}};
  const browser={
    runtime:{onInstalled:event,onStartup:event,sendNativeMessage:async () => ({ok:nativeOk})},
    contextMenus:{onClicked:event},storage:{local:{get:async () => ({enabled:true}),set:async () => {}},onChanged:event},
    action:{setBadgeText:async () => {},setBadgeBackgroundColor:async () => {}},
    downloads:{onCreated:event,onChanged:{addListener(fn) {changed=fn;}},
      pause:async () => {},resume:async () => {},
      cancel:async () => {state='interrupted';},
      search:async () => exists ? [{id:7,state}] : [],
      erase:async query => {erased.push(query.id);exists=false;return [query.id];}}
  };
  const context=vm.createContext({browser,URL});
  vm.runInContext(fs.readFileSync('browser-extension-firefox/background.js','utf8'),context);
  await vm.runInContext("capture({id:7,state:'in_progress',url:'https://example.com/file.iso'})",context);
  return {erased, get exists() {return exists;}, async publish(id=7,newState='interrupted') {
    exists=true;state=newState;
    changed({id,state:{current:'interrupted'},error:{current:'USER_CANCELED'}});
    await new Promise(resolve => setImmediate(resolve));
  }};
}

(async () => {
  const success=await fixture();
  assert.equal(success.exists,false);
  await success.publish();
  assert.equal(success.exists,false);
  assert.deepEqual(success.erased,[7,7]);
  await success.publish(99);
  assert.equal(success.exists,true);
  assert.deepEqual(success.erased,[7,7]);
  await success.publish(7,'in_progress');
  assert.equal(success.exists,true);
  const failed=await fixture(false);
  await failed.publish();
  assert.equal(failed.exists,true);
  assert.deepEqual(failed.erased,[]);
  console.log('Late Zen cancellation removed; unrelated, restarted and unacknowledged downloads preserved');
})().catch(error => {console.error(error);process.exitCode=1;});
