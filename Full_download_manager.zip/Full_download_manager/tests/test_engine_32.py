"""Verify 32 real HTTP connections and non-destructive history clearing."""
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import tempfile
import threading
import time
import unittest

from app import Engine, find_aria2

SIZE = 128 * 1024 * 1024
BLOCK = bytes(range(256)) * 256


class RangeHandler(BaseHTTPRequestHandler):
    lock = threading.Lock()
    active = peak = 0

    def log_message(self, *_):
        pass

    def do_GET(self):
        start, end = 0, SIZE - 1
        header = self.headers.get('Range')
        if header:
            first, _, last = header.partition('=')[2].partition('-')
            start = int(first)
            if last:
                end = min(end, int(last))
        self.send_response(206 if header else 200)
        self.send_header('Content-Length', str(end - start + 1))
        self.send_header('Accept-Ranges', 'bytes')
        if header:
            self.send_header('Content-Range', f'bytes {start}-{end}/{SIZE}')
        self.end_headers()
        with self.lock:
            RangeHandler.active += 1
            RangeHandler.peak = max(RangeHandler.peak, RangeHandler.active)
        try:
            for pos in range(start, end + 1, len(BLOCK)):
                length = min(len(BLOCK), end - pos + 1)
                offset = pos % len(BLOCK)
                self.wfile.write((BLOCK + BLOCK)[offset:offset + length])
                time.sleep(.01)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        finally:
            with self.lock:
                RangeHandler.active -= 1


@unittest.skipUnless(find_aria2(), 'aria2 required')
class Engine32Tests(unittest.TestCase):
    def test_32_real_connections_and_history_clear_preserves_files_and_paused_job(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), RangeHandler)
        server.request_queue_size = 64
        threading.Thread(target=server.serve_forever, daemon=True).start()
        url = f'http://127.0.0.1:{server.server_port}/file.bin'
        try:
            with tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                engine = Engine(root / 'state', connections=32)
                try:
                    self.assertEqual(engine.call('getGlobalOption')['max-connection-per-server'], '32')
                    gid = engine.add(url, root / 'files', 32)
                    until = time.monotonic() + 45
                    peak = 0
                    while time.monotonic() < until:
                        item = engine.call('tellStatus', gid)
                        peak = max(peak, int(item.get('connections', 0)))
                        if item['status'] in ('complete', 'error'):
                            break
                        time.sleep(.05)
                    self.assertEqual(item['status'], 'complete', item)
                    self.assertEqual(peak, 32, f'Observed peak {peak}; server peak {RangeHandler.peak}')
                    self.assertGreater(RangeHandler.peak, 16)
                    expected = hashlib.sha256()
                    for _ in range(SIZE // len(BLOCK)):
                        expected.update(BLOCK)
                    output = root / 'files/file.bin'
                    with output.open('rb') as stream:
                        self.assertEqual(hashlib.file_digest(stream, 'sha256').hexdigest(), expected.hexdigest())
                    waiting = engine.add(url + '?keep', root / 'paused', 32)
                    engine.call('forcePause', waiting)
                    until = time.monotonic() + 3
                    while engine.call('tellStatus', waiting)['status'] != 'paused' and time.monotonic() < until:
                        time.sleep(.05)
                    self.assertEqual(engine.clear_history(), 1)
                    self.assertEqual(engine.call('tellStopped', 0, 1000), [])
                    self.assertTrue(output.is_file())
                    self.assertEqual(output.stat().st_size, SIZE)
                    self.assertEqual(engine.call('tellStatus', waiting)['status'], 'paused')
                    self.assertIn(waiting, (root / 'state/session.txt').read_text(encoding='utf-8'))
                    self.assertEqual(engine.clear_history(), 0)
                finally:
                    engine.close()
        finally:
            server.shutdown()
            server.server_close()


if __name__ == '__main__':
    unittest.main()
