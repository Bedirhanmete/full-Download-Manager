const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

async function handoff({enabled=true, fails=false, sender={id:'our-extension',tab:{id:1}},
  url='https://example.com/file.iso'} = {}) {
  let listener, native=0;
  const event = {addListener() {}};
  const chrome = {
    runtime:{id:'our-extension',onInstalled:event,onStartup:event,
      onMessage:{addListener(fn) {listener=fn;}},
      sendNativeMessage:async () => {native++; return {ok:!fails};}},
    storage:{local:{get:async () => ({enabled}),set:async () => {}},onChanged:event},
    contextMenus:{onClicked:event},downloads:{onCreated:event},
    action:{setBadgeText:async () => {},setBadgeBackgroundColor:async () => {}}
  };
  const context = vm.createContext({chrome,URL});
  vm.runInContext(fs.readFileSync('browser-extension/background.js','utf8'),context);
  let resolve;
  const received = new Promise(done => {resolve=done;});
  const waiting = listener({action:'capture-link',url},sender,resolve);
  const response = waiting ? await received : undefined;
  return {native,waiting,ok:response?.ok};
}

(async () => {
  assert.deepEqual(await handoff(), {native:1,waiting:true,ok:true});
  assert.deepEqual(await handoff({enabled:false}), {native:0,waiting:true,ok:false});
  assert.deepEqual(await handoff({fails:true}), {native:1,waiting:true,ok:false});
  for (const options of [{sender:{id:'other',tab:{id:1}}}, {sender:{id:'our-extension'}},
    {url:'file:///private.iso'}, {url:'https://user:secret@example.com/file.iso'}]) {
    assert.deepEqual(await handoff(options), {native:0,waiting:false,ok:undefined});
  }
  console.log('7 file-link native acknowledgement and sender validation checks passed');
})().catch(error => {console.error(error);process.exitCode=1;});
