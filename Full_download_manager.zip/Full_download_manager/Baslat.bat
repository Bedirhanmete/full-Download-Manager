@echo off
start "" "%SystemRoot%\System32\wscript.exe" "%~dp0Baslat.vbs"
exit /b
