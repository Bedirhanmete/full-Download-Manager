"""Build the unsigned Mozilla submission archive, never label it installable."""
from pathlib import Path
import json
import zipfile
import shutil
import os
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def copy_if_changed(source, destination):
    # A temporary Firefox add-on can keep its ZIP open. Unchanged archives do
    # not need to be rewritten when only the desktop application is rebuilt.
    if destination.exists() and destination.read_bytes() == source.read_bytes():
        return
    if destination.exists():
        try:
            with zipfile.ZipFile(source) as left, zipfile.ZipFile(destination) as right:
                if (set(left.namelist()) == set(right.namelist())
                        and all(left.read(name) == right.read(name) for name in left.namelist())):
                    return  # ZIP timestamps may differ after regenerating icons.
        except zipfile.BadZipFile:
            pass
    # Firefox may memory-map a loaded ZIP: truncating that file fails on Windows,
    # while replacing its directory entry is allowed when it shares delete access.
    # Build the replacement completely before touching the installed archive.
    with tempfile.NamedTemporaryFile(dir=destination.parent, prefix='.fdm-package-',
                                     suffix='.tmp', delete=False) as handle:
        replacement = Path(handle.name)
    try:
        shutil.copyfile(source, replacement)
        os.replace(replacement, destination)
    finally:
        replacement.unlink(missing_ok=True)


def build():
    source = ROOT / 'browser-extension-firefox'
    version = json.loads((source / 'manifest.json').read_text(encoding='utf-8'))['version']
    output = ROOT / 'dist' / f'FullDownloadManager-Firefox-{version}-UNSIGNED.zip'
    output.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source.rglob('*')):
            if path.is_file() and path.suffix in {'.js', '.json', '.html', '.png'}:
                archive.write(path, path.relative_to(source).as_posix())
    copy_if_changed(output, ROOT / 'assets' / 'FullDownloadManager-Firefox-UNSIGNED.zip')
    temporary_firefox = ROOT / 'dist' / f'FullDownloadManager-Firefox-{version}-TEMPORARY.zip'
    try:
        copy_if_changed(output, temporary_firefox)
    except PermissionError:
        # A running Firefox/Zen may deny even atomic replacement. Keep its loaded
        # archive intact and deliver the same version under an explicit new name.
        print(f'Loaded archive is locked, unchanged: {temporary_firefox}')
        temporary_firefox = temporary_firefox.with_name(temporary_firefox.stem + '-UPDATED.zip')
        copy_if_changed(output, temporary_firefox)
    print(output)
    chromium = ROOT / 'browser-extension'
    manifest = json.loads((chromium / 'manifest.json').read_text(encoding='utf-8'))
    # Stores assign their own identity. The development key is not a store ID.
    manifest.pop('key', None)
    store_output = ROOT / 'dist' / f"FullDownloadManager-Chromium-{manifest['version']}-STORE.zip"
    with zipfile.ZipFile(store_output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(chromium.rglob('*')):
            if path.is_file() and path.suffix in {'.js', '.json', '.html', '.png'}:
                name = path.relative_to(chromium).as_posix()
                if name == 'manifest.json':
                    archive.writestr(name, json.dumps(manifest, ensure_ascii=False, indent=2))
                else:
                    archive.write(path, name)
    copy_if_changed(store_output, ROOT / 'assets' / 'FullDownloadManager-Chromium-STORE.zip')
    print(store_output)
    development = ROOT / 'dist' / f"FullDownloadManager-Chromium-{manifest['version']}-UNPACKED.zip"
    with zipfile.ZipFile(development, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(chromium.rglob('*')):
            if path.is_file() and path.suffix in {'.js', '.json', '.html', '.png'}:
                archive.write(path, path.relative_to(chromium).as_posix())
    print(development)
    print(temporary_firefox)
    return output


if __name__ == '__main__':
    build()
