"""Bounded Range throughput probe. Discards data; never fetches an entire large file."""
import concurrent.futures
import json
import os
import re
import time
import urllib.request

URL = os.environ['FDM_BENCHMARK_URL']
SIZE = 32 * 1024 * 1024


def read_range(start, length):
    request = urllib.request.Request(URL, headers={
        'Range': f'bytes={start}-{start + length - 1}', 'User-Agent': 'aria2/1.37.0',
        'Accept-Encoding': 'identity',
    })
    received = 0
    started = time.monotonic()
    with urllib.request.urlopen(request, timeout=12) as response:
        content_range = response.headers.get('Content-Range', '')
        match = re.match(r'bytes (\d+)-(\d+)/(\d+)', content_range)
        if response.status != 206 or not match or int(match[1]) != start:
            raise RuntimeError(f'Range unsupported: HTTP {response.status}')
        while received < length and time.monotonic() - started < 15:
            chunk = response.read(min(65536, length - received))
            if not chunk:
                break
            received += len(chunk)
    return received


def measure(connections):
    started = time.monotonic()
    chunk = SIZE // connections
    with concurrent.futures.ThreadPoolExecutor(max_workers=connections) as pool:
        results = list(pool.map(lambda n: read_range(n * chunk, chunk), range(connections)))
    elapsed = time.monotonic() - started
    size = sum(results)
    return {'connections': connections, 'bytes': size, 'seconds': round(elapsed, 3),
            'MB_per_second': round(size / elapsed / 1_000_000, 2),
            'Mbps': round(size / elapsed * 8 / 1_000_000, 2)}


if __name__ == '__main__':
    for count in (1, 16):
        try:
            print(json.dumps(measure(count)), flush=True)
        except Exception as exc:
            print(json.dumps({'connections': count, 'error': str(exc)}), flush=True)
            break
