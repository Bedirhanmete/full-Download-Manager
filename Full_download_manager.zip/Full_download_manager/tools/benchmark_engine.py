"""Short real-engine probe against a user-supplied URL; keeps user sessions untouched."""
import json
import os
from pathlib import Path
import sys
import tempfile
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import Engine


def main():
    url = os.environ['FDM_BENCHMARK_URL']
    with tempfile.TemporaryDirectory(prefix='fdm-network-probe-') as directory:
        engine = Engine(Path(directory) / 'state')
        try:
            gid = engine.add(url, Path(directory) / 'parts', 16)
            # Benchmark-only guard, above a 500 Mbps plan. The application itself has no limit.
            engine.call('changeOption', gid, {'max-download-limit': '64M'})
            started = time.monotonic()
            first_data = None
            peak_connections = 0
            peak_speed = 0
            completed = 0
            while time.monotonic() - started < 15 and completed < 96 * 1024 * 1024:
                state = engine.call('tellStatus', gid)
                if state['status'] == 'error':
                    raise RuntimeError(state.get('errorMessage', state.get('errorCode')))
                completed = int(state['completedLength'])
                if completed and first_data is None:
                    first_data = time.monotonic()
                peak_connections = max(peak_connections, int(state.get('connections', 0)))
                peak_speed = max(peak_speed, int(state['downloadSpeed']))
                time.sleep(.05)
            engine.call('forcePause', gid)
            elapsed = time.monotonic() - started
            options = engine.call('getOption', gid)
            result = {
                'source': 'Microsoft Windows ISO', 'test': 'short partial download with actual aria2 engine',
                'received_MiB': round(completed / 1024**2, 2), 'elapsed_seconds': round(elapsed, 3),
                'peak_connections': peak_connections, 'peak_MB_per_second': round(peak_speed / 1_000_000, 2),
                'peak_Mbps': round(peak_speed * 8 / 1_000_000, 2),
                'average_Mbps_including_startup': round(completed / elapsed * 8 / 1_000_000, 2),
                'file_allocation': options['file-allocation'],
                'disk_cache': engine.call('getGlobalOption')['disk-cache'],
            }
            print(json.dumps(result, indent=2), flush=True)
            output = Path(__file__).resolve().parents[1] / 'artifacts'
            output.mkdir(exist_ok=True)
            (output / 'engine-speed-test.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        finally:
            engine.close()


if __name__ == '__main__':
    main()

