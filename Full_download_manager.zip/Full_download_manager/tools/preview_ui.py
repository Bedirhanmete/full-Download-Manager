"""Test-only visual preview; example data never enter the production application."""
from pathlib import Path
import sys
import tkinter as tk
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
from test_desktop_ui import FakeEngine, sample_items
from desktop_ui import FullDownloadManager
import preferences

root = tk.Tk()
ui = FullDownloadManager(root, FakeEngine(), dict(preferences.DEFAULTS, internet_mbps=500))
root.title('FDM UI PREVIEW')
if '--sample-data' in sys.argv:
    root.title('FDM UI PREVIEW - SAMPLE DATA')
    ui.notice = 'ARAYÜZ ÖNİZLEMESİ • ÖRNEK VERİLER / UI PREVIEW • SAMPLE DATA'
    ui.history.clear()
    ui.history.extend([v * 1_000_000 for v in [
        0, 2, 9, 13, 16, 19, 17, 14, 18, 22, 29, 25, 24, 27, 32, 37, 35, 31, 28,
        36, 42, 39, 35, 34, 31, 37, 46, 42, 41, 38, 36, 40]])
    ui.receive(sample_items())
root.after(15000, ui.close)
root.mainloop()

