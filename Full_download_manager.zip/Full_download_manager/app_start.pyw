"""Windowless desktop entry point with visible startup errors."""
from pathlib import Path
import traceback


def main():
    language = 'tr'
    try:
        from preferences import load
        from i18n import text as translate
        language = load()['language']
        from app import main as run
        run()
    except Exception:
        details = traceback.format_exc()
        log = Path.home() / '.hizli-indir' / 'startup.log'
        try:
            log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text(details, encoding='utf-8')
            from i18n import text as translate
            text = translate('startup_log', language, path=log)
        except OSError:
            text = details[-1800:]
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text, 'Full Download Manager', 16)


if __name__ == '__main__':
    main()
