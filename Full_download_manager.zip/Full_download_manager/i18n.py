"""Application UI strings. Product name is the same in both languages."""
STRINGS = {
    'new': ('Yeni indirme', 'New download'),
    'all': ('Tüm indirmeler', 'All downloads'),
    'active': ('Aktif indirmeler', 'Active downloads'),
    'complete': ('Tamamlananlar', 'Completed'),
    'paused': ('Duraklatılanlar', 'Paused'),
    'settings': ('Ayarlar', 'Settings'),
    'browser': ('Tarayıcı bağlantısı', 'Browser integration'),
    'browser_ready': ('Tarayıcı bağlantısı hazır', 'Browser integration is ready'),
    'browser_unset': ('Tarayıcıyı bağla', 'Connect your browser'),
    'browser_capture': ('Tarayıcıdan bağlantı yakalandı', 'Download captured from browser'),
    'performance': ('Yüksek performans', 'High performance'),
    'unlimited': ('Hız sınırı yok', 'No speed limit'),
    'connections': ('Dosya başına bağlantı', 'Connections per file'),
    'actual_connections': ('{count} aktif bağlantı', '{count} active connections'),
    'parallel': ('Çoklu bağlantı', 'Multiple connections'),
    'save_exit': ('Kaydet ve çık', 'Save and exit'),
    'pause_all': ('Tümünü duraklat', 'Pause all'),
    'resume_all': ('Tümünü başlat', 'Resume all'),
    'clear': ('Temizle', 'Clear'),
    'cleared': ('{count} bitmiş indirme kaydı temizlendi. Dosyalar ve devam eden indirmeler korundu.', '{count} finished download records cleared. Files and ongoing downloads were preserved.'),
    'analysis': ('Hız analizi', 'Speed analysis'),
    'live': ('ANLIK HIZ', 'LIVE SPEED'),
    'peak': ('Oturum zirvesi', 'Session peak'),
    'capacity': ('Hat kapasitesi', 'Line capacity'),
    'capacity_unset': ('Hat hızını ayarlardan girin', 'Set your line speed in Settings'),
    'usage': ('Hat kullanımı', 'Line utilization'),
    'source_note': ('Hız, kaynak sunucuya ve ağ koşullarına bağlıdır.', 'Speed depends on the source server and network conditions.'),
    'empty_title': ('Bir sonraki indirmene hazır', 'Ready for your next download'),
    'empty_text': ('Dosya bağlantısını ekle. Gerisini Full Download Manager halletsin.', 'Add a file link. Let Full Download Manager take care of the rest.'),
    'empty_filter': ('Bu görünümde indirme yok', 'No downloads in this view'),
    'empty_filter_text': ('İndirmeler durumlarına göre burada görünecek.', 'Downloads will appear here as their status changes.'),
    'link': ('Dosya bağlantısı (HTTP / HTTPS)', 'File link (HTTP / HTTPS)'),
    'folder': ('Kayıt klasörü', 'Download folder'),
    'browse': ('Gözat', 'Browse'),
    'start': ('İndirmeyi başlat', 'Start download'),
    'download': ('İndir', 'Download'),
    'starting': ('Başlatılıyor…', 'Starting…'),
    'pending_downloads': ('İndirilmeye hazır ({count})', 'Ready to download ({count})'),
    'cancel': ('Vazgeç', 'Cancel'),
    'cancel_download': ('İptal', 'Cancel'),
    'confirm_cancel': ('İndirme iptal edilsin mi? Bu indirmeye ait yarım dosya ve devam kaydı kalıcı olarak silinecek.',
                       'Cancel this download? Its partial file and resume data will be permanently deleted.'),
    'cancelling': ('İndirme iptal ediliyor, yarım dosyalar temizleniyor…', 'Cancelling download and removing partial files…'),
    'cancelled': ('İndirme iptal edildi ve dosya kalıntıları silindi.', 'Download cancelled and partial files deleted.'),
    'cancel_preserved': ('İndirme iptal edildi. Önceden var olan veya başka bir indirmeye ait dosyalar korundu.',
                         'Download cancelled. Pre-existing files and files used by another download were preserved.'),
    'cancel_complete': ('İndirme zaten tamamlandığı için tamamlanan dosya korundu.', 'The download had already finished, so its completed file was preserved.'),
    'save': ('Kaydet', 'Save'),
    'language': ('Dil', 'Language'),
    'network': ('İndirme ve bağlantı', 'Downloads and connection'),
    'concurrent': ('Aynı anda indirilen dosya', 'Simultaneous downloads'),
    'line_speed': ('İnternet paketi hızı (Mbps)', 'Internet plan speed (Mbps)'),
    'line_help': ('0 = belirtilmedi. Bu değer hız sınırı koymaz; yalnızca karşılaştırma içindir.', '0 = unspecified. This is a comparison value, not a speed limit.'),
    'connection_help': ('1–32 bağlantı / dosya. Büyük dosyalarda sunucu desteklediğinde kullanılır.', '1–32 connections per file. Available for large files when supported by the server.'),
    'speed_help': ('500 Mbps ≈ 62,5 MB/s. MB/s dosya hızıdır; Mbps hat hızıdır.', '500 Mbps ≈ 62.5 MB/s. MB/s measures file transfer; Mbps measures line speed.'),
    'settings_saved': ('Ayarlar kaydedildi.', 'Settings saved.'),
    'queued': ('İndirme kuyruğa eklendi.', 'Download added to the queue.'),
    'closing': ('İndirmeler durduruluyor ve oturum kaydediliyor…', 'Pausing downloads and saving your session…'),
    'error': ('Hata', 'Error'),
    'startup_error': ('Uygulama başlatılamadı', 'Could not start the application'),
    'engine_error': ('İndirme motoru bağlantısı: ', 'Download engine connection: '),
    'invalid_folder': ('Kayıt klasörü seçin.', 'Choose a download folder.'),
    'invalid_settings': ('Bağlantı sayısı 1–32, eşzamanlı dosya 1–8, hat hızı 0–100000 arasında olmalı.', 'Use 1–32 connections, 1–8 simultaneous files, and a line speed from 0 to 100000 Mbps.'),
    'status_active': ('İndiriliyor', 'Downloading'),
    'status_waiting': ('Sırada', 'Queued'),
    'status_paused': ('Duraklatıldı', 'Paused'),
    'status_complete': ('İndirme tamamlandı', 'Download complete'),
    'status_error': ('İndirme başarısız', 'Download failed'),
    'status_removed': ('İptal edildi', 'Cancelled'),
    'remaining': ('{time} kaldı', '{time} remaining'),
    'seconds': ('{n} sn', '{n}s'),
    'minutes': ('{n} dk', '{n}m'),
    'hours': ('{n} sa {m} dk', '{n}h {m}m'),
    'unknown': ('Dosya bilgisi bekleniyor…', 'Waiting for file information…'),
    'pause': ('Duraklat', 'Pause'),
    'resume': ('Devam et', 'Resume'),
    'stop': ('Durdur', 'Stop'),
    'open_folder': ('Klasörü aç', 'Open folder'),
    'retry': ('Yeniden dene', 'Retry'),
    'file_count': ('{count} dosya', '{count} files'),
    'applied': ('Ayarlar mevcut ve yeni indirmelere uygulandı.', 'Settings applied to existing and new downloads.'),
    'performance_note': ('32 bağlantıya kadar • sınırsız aktarım', 'Up to 32 connections • unlimited transfer'),
    'no_limit': ('Uygulama hız sınırı uygulamaz.', 'The application does not impose a speed limit.'),
    'confirm_stop': ('Bu indirme durdurulsun mu? İndirilmiş parçalar diskte korunur.', 'Stop this download? Downloaded parts will remain on disk.'),
    'browser_error': ('Tarayıcı bağlantısı açılamadı.', 'Could not open browser integration.'),
}
ERRORS = {
    'Geçerli bir http:// veya https:// dosya bağlantısı girin.': 'Enter a valid http:// or https:// file link.',
    'Kullanıcı bilgisi içeren bağlantılar desteklenmiyor.': 'Links containing embedded login credentials are not supported.',
    'Uygulama zaten açık. Açık pencereyi kullanın.': 'The application is already running. Use the open window.',
    'İndirme motoru zamanında yanıt vermedi.': 'The download engine did not respond in time.',
    'İndirme motoru açılamadı. engine.log dosyasını kontrol edin.': 'Could not start the download engine. Check engine.log.',
    'aria2c bulunamadı. README içindeki aria2 kurulumunu tamamlayın ve uygulamayı yeniden açın.': 'aria2c was not found. Run the installer and reopen the application.',
}


def text(key, language='tr', **values):
    pair = STRINGS[key]
    return pair[1 if language == 'en' else 0].format(**values)


def error_text(value, language='tr'):
    value = str(value)
    return ERRORS.get(value, value) if language == 'en' else value


def transfer_speed(bytes_per_second):
    return f'{max(0, bytes_per_second) / 1_000_000:.2f} MB/s'


def link_speed(bytes_per_second):
    return max(0, bytes_per_second) * 8 / 1_000_000

STRINGS.update({
    'browser_help_firefox': (
        'Yerel uygulama bağlantısı hazır. Kalıcı Zen / Firefox kurulumu için Mozilla imzalı XPI gerekir.\n\n'
        'Bu kurulumda imzalı paket bulunamadı. “Kalıcı kurulum rehberi” düğmesiyle imzalama adımlarını açın. '
        'İmzasız ZIP, Mozilla başvurusu içindir; tarayıcıya kurulamaz. İmzalı XPI hazır olduğunda Eklentiler → dişli menüsü → Dosyadan eklenti yükle yolunu kullanın.',
        'The local application bridge is ready. Permanent Zen / Firefox installation requires a Mozilla-signed XPI.\n\n'
        'No signed package was bundled. Open “Permanent installation guide” for signing instructions. '
        'The unsigned ZIP is a Mozilla submission package, not an installable add-on. Once signed, use Add-ons → gear menu → Install Add-on From File.'),
    'browser_help_firefox_signed': (
        'Kalıcı uzantı paketi hazır.\n\n1. Eklentiler ekranını açın.\n2. Dişli menüsünde “Dosyadan eklenti yükle” seçin.\n'
        '3. Aşağıdaki XPI dosyasını seçip izinleri onaylayın.\n\nTarayıcı imzayı doğrular. Kurulum tamamlandığında uzantı yeniden başlatmalarda kalır. Eski geçici eklentiyi önce kaldırın.',
        'A permanent extension package is available.\n\n1. Open the Add-ons page.\n2. Choose “Install Add-on From File” in the gear menu.\n'
        '3. Select the XPI below and approve permissions.\n\nThe browser verifies the signature. After installation the add-on persists across restarts. Remove the old temporary add-on first.'),
    'copy_path': ('Yolu kopyala', 'Copy path'),
    'publishing_guide': ('Chrome / Edge yayınlama rehberi', 'Chrome / Edge publishing guide'),
    'store_identity_help': ('Mağaza yüklemesinden sonra verilen 32 harfli uzantı kimliğini girin. Chrome mağazası kimliği Chrome, Brave, Vivaldi, Opera ve Chromium için ortaktır. Edge mağazası kimliği ayrı kaydedilir.',
                            'Enter the 32-letter extension ID assigned by the store. The Chrome store ID is shared by Chrome, Brave, Vivaldi, Opera and Chromium. The Edge store ID is saved separately.'),
    'store_identity_invalid': ('Uzantı kimliği a–p arasında 32 küçük harften oluşmalıdır.', 'The extension ID must contain 32 lowercase letters from a to p.'),
    'store_identity_apply': ('Mağaza uzantısını uygulamaya bağla', 'Connect store extension to the app'),
    'store_open': ('Mağazadan kalıcı kur', 'Install permanently from store'),
    'browser_help_firefox_store': (
        'Firefox/Zen uzantısı Mozilla mağazasında yayımlandı.\n\n“Mağazadan kalıcı kur” düğmesine basın; seçtiğiniz tarayıcıda Firefox’a Ekle seçeneğiyle kurulumu onaylayın. Geçici uzantıya gerek yoktur.\n\nMağaza her zaman onaylanmış sürümü sunar. Yeni sürüm incelemedeyse onaydan sonra güncellenir. Daha önce yüklediğiniz geçici kopyayı kaldırın.',
        'The Firefox/Zen extension is published on Mozilla Add-ons.\n\nClick “Install permanently from store”, then choose Add to Firefox and approve installation in your selected browser. No temporary add-on is needed.\n\nThe store serves the approved release. A pending update becomes available after approval. Remove an earlier temporary copy.'),
    'selected_browser_missing': ('Seçtiğiniz tarayıcı bu bilgisayarda bulunamadı. Tarayıcıyı yükledikten sonra mağaza bağlantısını yeniden açın.',
                                 'The selected browser was not found on this computer. Install it, then open the store link again.'),
    'firefox_store_pending': ('Firefox Add-ons açıldı. Uzantımız inceleme aşamasında olduğu için henüz kendi mağaza sayfası yok. Yayınlandığında doğrudan uzantının sayfası açılacak.',
                              'Firefox Add-ons is open. Our add-on is under review and does not yet have a public store listing. Once published, its listing will open directly.'),
    'browser_store_unavailable': ('Uygulama kuruldu. Bu tarayıcı için bir uzantı mağazası bağlantısı bulunamadı. Tarayıcı bağlantısı ekranından desteklenen bir tarayıcı seçebilirsiniz.',
                                   'The application is installed. No extension store link is available for this browser. Select a supported browser in Browser Integration.'),
    'browser_help_chromium_store': (
        'Mağaza uzantısının yerel uygulama bağlantısı hazır. “Mağazadan kalıcı kur” düğmesine basıp tarayıcıdaki kurulumu onaylayın.\n\nMağaza kimliğinin kaydedilmesi uzantıyı otomatik olarak yüklemez. Mağaza incelemesi ve yayını tamamlanmış olmalıdır. Eski geliştirici kopyasını kaldırın.',
        'The store extension is connected to the local application. Click “Install permanently from store” and approve installation in your browser.\n\nSaving a store ID does not automatically install the extension. Store review and publication must be complete. Remove the old developer copy.'),
    'signing_guide': ('Kalıcı kurulum rehberi', 'Permanent installation guide'),
    'browser_help_chromium': (
        'Uygulama bağlantısı hazır. Son adımı tarayıcıda tamamlayın:\n\n'
        '1. Eklentiler ekranını açın.\n2. “Geliştirici modu” seçeneğini etkinleştirin.\n'
        '3. “Paketlenmemiş öğe yükle” düğmesine basın.\n4. Aşağıdaki klasörü seçin.\n\n'
        'Kimlik kopyalamanız veya komut yazmanız gerekmez. Eklenti mağazada yayımlanmadığından bu adım tarayıcıda yapılır.',
        'The application bridge is ready. Complete the last step in your browser:\n\n'
        '1. Open the extensions page.\n2. Enable “Developer mode”.\n'
        '3. Click “Load unpacked”.\n4. Select the folder below.\n\n'
        'No extension ID or terminal commands are needed. This activation step is required because the extension is not published in a store.'),
    'browser_help_unknown': (
        'Desteklenen bir varsayılan tarayıcı algılanamadı. Uygulama bağlantısı yine de kuruldu.\n\n'
        'Bağlantı sayfasından dosya bağlantısını uygulamaya aktarabilirsiniz.',
        'No supported default browser was detected. The explicit application handoff is still ready.\n\n'
        'Use the link page to send a file URL to the application.'),
    'extensions_page': ('Eklentiler ekranını aç', 'Open extensions page'),
    'link_page': ('Bağlantı sayfasını aç', 'Open link page'),
    'copy_folder': ('Klasör yolunu kopyala', 'Copy folder path'),
    'restart_browser': ('Eklentiyi yükledikten sonra tarayıcıyı tamamen kapatıp yeniden açın.', 'After loading the extension, fully close and reopen your browser.'),
    'paste_address': ('Adres kopyalandı. Tarayıcının adres çubuğuna yapıştırın:\n', 'Address copied. Paste it into your browser address bar:\n'),
    'done': ('Tamam', 'Done'),
    'startup_log': ('Uygulama açılamadı. Hata ayrıntıları:\n{path}', 'The application could not start. Error details:\n{path}'),
})
