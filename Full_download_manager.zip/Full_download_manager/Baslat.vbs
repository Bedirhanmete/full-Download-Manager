Option Explicit
Dim shell, fso, folder, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
command = """" & shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"" -NoProfile -NonInteractive -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File """ & folder & "\windows_setup.ps1"""
On Error Resume Next
shell.Run command, 0, False
If Err.Number <> 0 Then
    MsgBox "Baslatilamadi: " & Err.Description, 16, "Full Download Manager"
End If
