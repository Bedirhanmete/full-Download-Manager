"""Dark, bilingual desktop UI. Charts and cards always use real engine data."""
from collections import deque
import concurrent.futures
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, font

import preferences
from i18n import STRINGS, text, error_text, transfer_speed, link_speed
from fluent_widgets import FluentButton

BG = '#202020'
SIDE = '#252525'
CARD = '#2d2d2d'
EDGE = '#414141'
FG = '#f5f5f5'
MUTED = '#b5b5b5'
CYAN = '#60cdff'
GREEN = '#6ccb5f'
BLUE = '#60cdff'


def rounded(canvas, box, radius=15, **options):
    x1, y1, x2, y2 = box
    r = min(radius, (x2 - x1) / 2, (y2 - y1) / 2)
    return canvas.create_polygon(
        x1+r, y1, x2-r, y1, x2, y1, x2, y1+r, x2, y2-r,
        x2, y2, x2-r, y2, x1+r, y2, x1, y2, x1, y2-r, x1, y1+r, x1, y1,
        smooth=True, splinesteps=20, **options)


def gradient_color(fraction):
    a, b = (63, 135, 246), (96, 205, 255)
    return '#%02x%02x%02x' % tuple(int(x + (y-x) * fraction) for x, y in zip(a, b))


def shorten(value, maximum, face):
    if face.measure(value) <= maximum:
        return value
    while value and face.measure(value + '…') > maximum:
        value = value[:-1]
    return value + '…'


def human_bytes(value):
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if value < 1000 or unit == 'TB':
            return f'{value:.1f} {unit}'
        value /= 1000


def time_left(total, done, speed, language):
    if not speed or not total:
        return '—'
    remaining = max(0, total - done) // speed
    if remaining >= 3600:
        result = text('hours', language, n=remaining // 3600, m=(remaining % 3600) // 60)
    elif remaining >= 60:
        result = text('minutes', language, n=remaining // 60)
    else:
        result = text('seconds', language, n=remaining)
    return text('remaining', language, time=result)


class FullDownloadManager:
    def __init__(self, root, engine, settings=None, settings_path=None):
        self.root = root
        self.engine = engine
        self.preferences = preferences.normalize(settings) if settings is not None else preferences.load()
        self.settings_path = settings_path
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        self.items = []
        self.history = deque([0.0] * 90, maxlen=90)
        self.peak = 0.0
        self.speed = 0
        self.filter = 'all'
        self.closing = False
        self.polling = False
        self.selected = None
        self.cancelling = set()
        self.clearing = False
        self.dialogs = []
        self.after_ids = []
        self.toast_until = 0
        self.notice = ''
        self.tray = None
        self.pending_links = []
        self.pending_starting = False
        self.pending_url = tk.StringVar(root)
        root.title('Full Download Manager')
        root.geometry('1280x800')
        root.minsize(1040, 700)
        root.configure(bg=BG)
        icon = Path(__file__).with_name('assets') / 'app.png'
        if icon.exists():
            self.window_icon = tk.PhotoImage(file=str(icon))
            root.iconphoto(True, self.window_icon)
        self.name_font = font.Font(root, family='Segoe UI', size=12, weight='bold')
        self.small_font = font.Font(root, family='Segoe UI', size=10)
        self.setup_theme()
        self.build()
        root.protocol('WM_DELETE_WINDOW', self.hide)
        root.bind('<Control-n>', lambda _: self.new_download())
        root.bind('<Control-comma>', lambda _: self.show_settings())
        root.bind('<Escape>', lambda _: self.dismiss_dialog())
        root.bind('<Destroy>', self.release_gui_resources, add='+')
        root.after(50, self.dark_titlebar)

    def release_gui_resources(self, event):
        if event.widget is not self.root:
            return
        # Tk image/font destruction must run on the GUI thread, not a later worker GC.
        self.window_icon = None
        if self.tray:
            self.tray.stop()
        self.name_font = None
        self.small_font = None

    @property
    def language(self):
        return self.preferences['language']

    def t(self, key, **values):
        return text(key, self.language, **values)

    def setup_theme(self):
        style = ttk.Style(self.root)
        style.theme_use('clam')
        style.configure('FDM.TEntry', fieldbackground='#242424', foreground=FG, insertcolor=FG,
                        bordercolor=EDGE, lightcolor=EDGE, darkcolor=EDGE, padding=8)
        style.configure('FDM.TCombobox', fieldbackground=BG, background=CARD, foreground=FG, arrowcolor=FG, padding=7)
        style.map('FDM.TCombobox', fieldbackground=[('readonly', BG)], foreground=[('readonly', FG)])
        self.root.option_add('*TCombobox*Listbox.background', CARD)
        self.root.option_add('*TCombobox*Listbox.foreground', FG)

    def dark_titlebar(self):
        if sys.platform == 'win32':
            try:
                import ctypes
                user = ctypes.windll.user32
                user.GetParent.argtypes = [ctypes.c_void_p]
                user.GetParent.restype = ctypes.c_void_p
                handle = user.GetParent(self.root.winfo_id())
                dwm = ctypes.windll.dwmapi.DwmSetWindowAttribute
                dwm.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
                for attribute, setting in ((20, 1), (33, 2), (35, 0x202020)):
                    value = ctypes.c_int(setting)
                    dwm(handle, attribute, ctypes.byref(value), ctypes.sizeof(value))
            except (AttributeError, OSError):
                pass

    def button(self, parent, title, command, primary=False, **options):
        return FluentButton(parent, title, command, primary=primary, **options)

    def label(self, parent, title, muted=False, size=10, bold=False, **options):
        return tk.Label(parent, text=title, bg=parent.cget('bg'), fg=MUTED if muted else FG,
                        font=('Segoe UI', size, 'bold' if bold else 'normal'), **options)

    def build(self):
        for child in self.root.winfo_children():
            if not isinstance(child, tk.Toplevel):
                child.destroy()
        self.side = tk.Frame(self.root, bg=SIDE, width=246)
        self.side.pack(side='left', fill='y')
        self.side.pack_propagate(False)
        logo = tk.Canvas(self.side, bg=SIDE, width=220, height=100, highlightthickness=0)
        logo.pack(padx=14, pady=(15, 6))
        rounded(logo, (12, 15, 60, 63), radius=12, fill='#0078d4', outline='')
        logo.create_line(36, 25, 36, 45, fill='white', width=3, capstyle='round')
        logo.create_line(27, 37, 36, 46, 45, 37, fill='white', width=3,
                         capstyle='round', joinstyle='round')
        logo.create_line(23, 48, 23, 53, 49, 53, 49, 48, fill='white', width=3,
                         capstyle='round', joinstyle='round')
        logo.create_text(72, 31, text='Full Download', fill=FG, font=('Segoe UI', 14, 'bold'), anchor='w')
        logo.create_text(72, 54, text='Manager', fill=CYAN, font=('Segoe UI', 14, 'bold'), anchor='w')
        self.button(self.side, '+   ' + self.t('new'), self.new_download, primary=True).pack(fill='x', padx=20, pady=(0, 25))
        self.nav = {}
        for key, icon in (('all', '↓'), ('active', '↧'), ('complete', '✓'), ('paused', 'Ⅱ')):
            line = tk.Frame(self.side, bg=SIDE)
            line.pack(fill='x', padx=(12, 0), pady=3)
            indicator = tk.Frame(line, width=4, bg=SIDE)
            button = self.button(line, icon + '   ' + self.t(key), lambda k=key: self.select_filter(k), anchor='w')
            button.configure(bg=SIDE, font=('Segoe UI', 11), pady=12)
            button.pack(fill='x', expand=True)
            indicator.place(x=1, rely=.5, anchor='w', width=3, height=18)
            indicator.lift()
            self.nav[key] = (button, indicator, icon)
        self.button(self.side, '⚙   ' + self.t('settings'), self.show_settings, anchor='w').pack(fill='x', padx=12, pady=(20, 3))
        self.button(self.side, '↗   ' + self.t('browser'), self.open_browser_help, anchor='w').pack(fill='x', padx=12, pady=3)
        self.button(self.side, self.t('save_exit'), self.close).pack(side='bottom', fill='x', padx=20, pady=(12, 18))
        self.performance = tk.Canvas(self.side, height=144, bg=SIDE, highlightthickness=0)
        self.performance.pack(side='bottom', fill='x', padx=18, pady=(18, 0))
        self.body = tk.Frame(self.root, bg=BG)
        self.body.pack(side='left', fill='both', expand=True)
        header = tk.Frame(self.body, bg=BG, height=72)
        header.pack(fill='x')
        header.pack_propagate(False)
        self.browser_label = self.label(header, '', size=10)
        self.browser_label.pack(side='left', padx=28)
        self.button(header, self.language.upper() + '  ▾', self.show_settings).pack(side='right', padx=25, pady=17)
        tk.Frame(self.body, height=1, bg=EDGE).pack(fill='x')
        content = tk.Frame(self.body, bg=BG)
        content.pack(fill='both', expand=True, padx=26, pady=(24, 14))
        bar = tk.Frame(content, bg=BG)
        bar.pack(fill='x', pady=(0, 16))
        self.heading = self.label(bar, '', size=19, bold=True)
        self.heading.pack(side='left')
        self.button(bar, self.t('resume_all'), lambda: self.action('unpauseAll')).pack(side='right', padx=(8, 0))
        self.button(bar, self.t('pause_all'), lambda: self.action('forcePauseAll')).pack(side='right')
        self.clear_button = self.button(bar, self.t('clear'), self.clear_history)
        self.pending_panel = tk.Frame(content, bg=CARD, padx=16, pady=12)
        self.pending_title = self.label(self.pending_panel, '', bold=True, size=12)
        self.pending_title.pack(anchor='w', pady=(0, 8))
        ttk.Entry(self.pending_panel, textvariable=self.pending_url, state='readonly',
                  style='FDM.TEntry').pack(fill='x')
        controls = tk.Frame(self.pending_panel, bg=CARD)
        controls.pack(fill='x', pady=(8, 0))
        self.pending_dismiss_button = self.button(controls, self.t('cancel'), self.dismiss_pending)
        self.pending_dismiss_button.pack(side='left')
        self.pending_download_button = self.button(controls, self.t('download'), self.start_pending, primary=True)
        self.pending_download_button.pack(side='right')
        self.graph = tk.Canvas(content, bg=BG, height=226, highlightthickness=0)
        self.graph.pack(side='bottom', fill='x', pady=(16, 0))
        self.graph.bind('<Configure>', lambda _: self.draw_graph())
        self.status_label = self.label(content, self.notice, muted=True, anchor='w')
        self.status_label.pack(side='bottom', fill='x', pady=(8, 0))
        list_frame = tk.Frame(content, bg=BG)
        list_frame.pack(fill='both', expand=True)
        self.cards = tk.Canvas(list_frame, bg=BG, highlightthickness=0, yscrollincrement=24)
        self.cards.pack(side='left', fill='both', expand=True)
        scrollbar = tk.Scrollbar(list_frame, command=self.cards.yview, bg=SIDE, troughcolor=BG,
                                 activebackground=EDGE, relief='flat', width=9, bd=0)
        scrollbar.pack(side='right', fill='y')
        self.cards.configure(yscrollcommand=scrollbar.set)
        self.cards.bind('<Configure>', lambda _: self.draw_cards())
        self.cards.bind('<MouseWheel>', lambda event: self.cards.yview_scroll(-int(event.delta / 120), 'units'))
        self.cards.bind('<Button-1>', self.card_click)
        self.cards.bind('<Motion>', self.card_hover)
        self.refresh_labels()
        self.draw_cards()
        self.draw_graph()

    def browser_state(self):
        if self.toast_until > time.monotonic():
            return self.t('browser_capture'), GREEN
        try:
            path = Path(os.environ.get('LOCALAPPDATA', '')) / 'HizliIndir/browser-setup.json'
            ready = json.loads(path.read_text(encoding='utf-8'))['native_host_ready']
        except (OSError, ValueError, KeyError):
            ready = False
        return self.t('browser_ready' if ready else 'browser_unset'), GREEN if ready else MUTED

    def refresh_labels(self):
        title, color = self.browser_state()
        self.browser_label.configure(text='●   ' + title, fg=color)
        active = sum(item['status'] in ('active', 'waiting') for item in self.items)
        for key, (button, indicator, icon) in self.nav.items():
            selected = self.filter == key
            suffix = f' ({active})' if key == 'active' else ''
            button.configure(text=icon + '   ' + self.t(key) + suffix,
                             bg='#373737' if selected else SIDE)
            indicator.configure(bg=CYAN if selected else SIDE)
        self.heading.configure(text=self.t(self.filter))
        if self.filter == 'all':
            if not self.clear_button.winfo_manager():
                self.clear_button.pack(side='right', padx=8)
            terminal = any(item['status'] in ('complete', 'error', 'removed') for item in self.items)
            self.clear_button.configure(state='normal' if terminal and not self.clearing else 'disabled')
        else:
            self.clear_button.pack_forget()
        self.status_label.configure(text=self.notice or self.t('file_count', count=len(self.items)))
        self.draw_performance()
        self.refresh_pending()

    def refresh_pending(self):
        if not self.pending_links:
            self.pending_panel.pack_forget()
            self.pending_url.set('')
            return
        if not self.pending_panel.winfo_manager():
            self.pending_panel.pack(fill='x', before=self.graph, pady=(0, 12))
        self.pending_url.set(self.pending_links[0])
        self.pending_title.configure(text=self.t('pending_downloads', count=len(self.pending_links)))
        state = 'disabled' if self.pending_starting else 'normal'
        self.pending_download_button.configure(state=state,
            text=self.t('starting' if self.pending_starting else 'download'))
        self.pending_dismiss_button.configure(state=state)

    def dismiss_pending(self):
        if self.pending_links and not self.pending_starting:
            self.pending_links.pop(0)
            self.refresh_pending()

    def start_pending(self):
        if self.closing or self.pending_starting or not self.pending_links:
            return
        link = self.pending_links[0]
        destination = self.preferences['download_directory'].strip()
        if not destination:
            self.notice = self.t('invalid_folder')
            self.refresh_labels()
            return
        count = self.preferences['connections']
        self.pending_starting = True
        self.refresh_pending()
        self.foreground_window(self.root)
        def failed(_):
            self.pending_starting = False
            self.refresh_pending()
        def added(_):
            self.pending_starting = False
            self.pending_links.remove(link)
            self.notice = self.t('queued')
            self.filter = 'all'
            self.refresh_labels()
            self.draw_cards()
        self.submit(lambda: self.engine.add(link, destination, count), added, on_error=failed)

    def select_filter(self, key):
        self.filter = key
        self.cards.yview_moveto(0)
        self.refresh_labels()
        self.draw_cards()

    def filtered_items(self):
        groups = {'active': ('active', 'waiting'), 'complete': ('complete',), 'paused': ('paused',)}
        return self.items if self.filter == 'all' else [i for i in self.items if i['status'] in groups[self.filter]]

    def draw_performance(self):
        canvas = self.performance
        canvas.delete('all')
        rounded(canvas, (0, 0, 210, 138), fill=CARD, outline=EDGE)
        canvas.create_text(15, 22, text=self.t('performance'), anchor='w', fill=FG, font=('Segoe UI', 11, 'bold'))
        canvas.create_oval(16, 45, 26, 55, fill=GREEN, outline='')
        canvas.create_text(35, 50, text=self.t('unlimited'), anchor='w', fill=GREEN, font=('Segoe UI', 10))
        canvas.create_text(16, 80, text=self.t('connections'), anchor='w', fill=MUTED, font=('Segoe UI', 9))
        canvas.create_text(190, 80, text=str(self.preferences['connections']), anchor='e', fill=FG, font=('Segoe UI', 12, 'bold'))
        canvas.create_text(16, 110, text=self.t('concurrent'), anchor='w', fill=MUTED, font=('Segoe UI', 9))
        canvas.create_text(190, 110, text=str(self.preferences['concurrent_downloads']), anchor='e', fill=CYAN, font=('Segoe UI', 12, 'bold'))

    def draw_cards(self):
        canvas = self.cards
        canvas.delete('all')
        self.card_actions = {}
        width = max(canvas.winfo_width() - 4, 600)
        items = self.filtered_items()
        if not items:
            h = max(canvas.winfo_height(), 260)
            x, y = width / 2, min(h / 2 - 25, 145)
            canvas.create_oval(x-30, y-42, x+30, y+18, outline=EDGE, width=2)
            canvas.create_line(x, y-27, x, y+1, fill=CYAN, width=3)
            canvas.create_line(x-10, y-9, x, y+1, x+10, y-9, fill=CYAN, width=3)
            canvas.create_text(x, y+53, text=self.t('empty_title' if self.filter == 'all' else 'empty_filter'),
                               fill=FG, font=('Segoe UI', 17, 'bold'))
            canvas.create_text(x, y+86, text=self.t('empty_text' if self.filter == 'all' else 'empty_filter_text'),
                               fill=MUTED, font=('Segoe UI', 10), width=width-60)
            if self.filter == 'all':
                tag = 'new'
                rounded(canvas, (x-95, y+113, x+95, y+153), fill=BLUE, outline='', tags=(tag,))
                canvas.create_text(x, y+133, text='+  ' + self.t('new'), fill=FG, font=('Segoe UI', 10, 'bold'), tags=(tag,))
                self.card_actions[tag] = self.new_download
            canvas.configure(scrollregion=(0, 0, width, max(h-1, 250)))
            return
        for index, item in enumerate(items):
            y = index * 116 + 2
            gid = item['gid']
            state = item['status']
            active = state == 'active'
            paused = state == 'paused'
            complete = state == 'complete'
            color = GREEN if complete else '#f0b657' if state == 'error' else CYAN
            rounded(canvas, (1, y, width-2, y+104), radius=9, fill=CARD,
                    outline=CYAN if self.selected == gid else EDGE)
            path = item.get('files', [{}])[0].get('path', '')
            name = Path(path).name or self.t('unknown')
            x = 43
            canvas.create_polygon(x-13, y+22, x+5, y+22, x+15, y+32, x+15, y+63, x-13, y+63,
                                   fill='#d8a64d' if name.lower().endswith(('.zip', '.rar', '.7z', '.iso')) else '#73a8cf', outline='')
            canvas.create_line(x+4, y+23, x+4, y+34, x+14, y+34, fill=BG, width=2)
            canvas.create_text(x+1, y+48, text='✓' if complete else '↓', fill=BG, font=('Segoe UI', 14, 'bold'))
            right = width-30
            name_width = max(180, width-415)
            canvas.create_text(77, y+26, text=shorten(name, name_width, self.name_font), anchor='w', fill=FG, font=self.name_font)
            total = int(item.get('totalLength', 0))
            done = int(item.get('completedLength', 0))
            speed = int(item.get('downloadSpeed', 0))
            ratio = min(1, done / total) if total else 0
            detail = self.t('status_' + state) if 'status_' + state in STRINGS else state
            if state == 'error':
                detail += ' · ' + item.get('errorMessage', item.get('errorCode', ''))
            elif not complete:
                detail = f'{human_bytes(done)} / {human_bytes(total) if total else "—"}  ({ratio:.0%})  ·  {detail}'
            canvas.create_text(77, y+53, text=shorten(detail, max(170, width-330), self.small_font),
                               anchor='w', fill=GREEN if complete else MUTED, font=self.small_font)
            if not complete and state not in ('error', 'removed'):
                canvas.create_text(right-151, y+27, text=transfer_speed(speed), anchor='e', fill=FG, font=('Segoe UI', 12, 'bold'))
                canvas.create_text(right-151, y+53, text=time_left(total, done, speed, self.language), anchor='e', fill=MUTED, font=('Segoe UI', 9))
            if active:
                count = int(item.get('connections', 0))
                canvas.create_text(77, y+88, text=self.t('actual_connections', count=count), anchor='w', fill=MUTED, font=('Segoe UI', 8))
            bar_y = y+71
            start_x, end_x = 77, right-151
            rounded(canvas, (start_x, bar_y, end_x, bar_y+5), radius=2, fill='#454545', outline='')
            if ratio > 0:
                canvas.create_rectangle(start_x, bar_y, start_x+(end_x-start_x)*ratio, bar_y+5, fill=color, outline='')
            tag = 'select:' + gid
            self.card_actions[tag] = lambda value=gid: self.select_card(value)
            canvas.create_rectangle(1, y, 67, y+102, outline='', fill='', tags=(tag,))
            actions = [('folder', '↗', self.t('open_folder'), lambda i=item: self.open_folder(i))] if complete else []
            if active or state == 'waiting' or paused:
                actions = [('toggle', '▶' if paused else 'Ⅱ', self.t('resume' if paused else 'pause'),
                            lambda value=gid, p=paused: self.action('unpause' if p else 'forcePause', value)),
                           ('stop', '×', self.t('cancel_download'), lambda value=gid: self.cancel_download(value))]
            elif state in ('error', 'removed'):
                actions = [('retry', '↻', self.t('retry'), lambda i=item: self.retry(i)),
                           ('stop', '×', self.t('cancel_download'), lambda value=gid: self.cancel_download(value))]
            for offset, (name_key, symbol, caption, callback) in enumerate(actions):
                cx = right-102 + offset*66
                tag = name_key + ':' + gid
                rounded(canvas, (cx-17, y+24, cx+17, y+58), radius=7,
                        outline='#665050' if name_key == 'stop' else '#505050',
                        fill='#383838', tags=(tag,))
                canvas.create_text(cx, y+41, text=symbol, fill='#f57585' if name_key == 'stop' else CYAN,
                                   font=('Segoe UI', 12, 'bold'), tags=(tag,))
                canvas.create_text(cx, y+82, text=caption, fill=MUTED, font=('Segoe UI', 8), tags=(tag,))
                self.card_actions[tag] = callback
        canvas.configure(scrollregion=(0, 0, width, len(items)*116))

    def card_click(self, event):
        for tag in self.cards.gettags('current'):
            if tag in self.card_actions:
                self.card_actions[tag]()
                return

    def card_hover(self, event):
        tags = self.cards.gettags('current')
        self.cards.configure(cursor='hand2' if any(t in self.card_actions for t in tags) else '')

    def select_card(self, gid):
        self.selected = gid
        self.draw_cards()

    def draw_graph(self):
        canvas = self.graph
        canvas.delete('all')
        w, h = max(canvas.winfo_width()-2, 600), 222
        rounded(canvas, (1, 1, w, h), fill=CARD, outline=EDGE)
        canvas.create_text(21, 28, text=self.t('analysis'), anchor='w', fill=FG, font=('Segoe UI', 14, 'bold'))
        plan = self.preferences['internet_mbps']
        subtitle = f'{self.t("capacity")}: {plan:g} Mbps' if plan else self.t('capacity_unset')
        canvas.create_text(21, 54, text=subtitle, anchor='w', fill=MUTED, font=('Segoe UI', 9))
        graph_right = w-240
        chart_top, chart_bottom = 83, 174
        for y in (chart_top, (chart_top+chart_bottom)/2, chart_bottom):
            canvas.create_line(21, y, graph_right, y, fill='#3b3b3b', dash=(3, 5))
        values = list(self.history)
        scale = max(max(values, default=0)*1.2, 1)
        points = []
        for index, value in enumerate(values):
            points += [21+(graph_right-21)*index/(len(values)-1), chart_bottom-(value/scale)*(chart_bottom-chart_top)]
        canvas.create_polygon(21, chart_bottom, *points, graph_right, chart_bottom, fill='#253d49', outline='')
        for index in range(len(values)-1):
            canvas.create_line(*points[index*2:index*2+4], fill=gradient_color(index/(len(values)-1)), width=2.5)
        canvas.create_text(21, 198, text=self.t('source_note'), anchor='w', fill=MUTED, font=('Segoe UI', 8))
        cx, cy = w-116, 121
        canvas.create_arc(cx-66, cy-66, cx+66, cy+66, start=-35, extent=250, outline='#454545', width=8, style='arc')
        utilization = min(1, link_speed(self.speed)/plan) if plan else 0
        if utilization > 0:
            canvas.create_arc(cx-66, cy-66, cx+66, cy+66, start=215, extent=-250*utilization, outline=GREEN, width=8, style='arc')
        canvas.create_text(cx, cy-29, text=self.t('live'), fill=MUTED, font=('Segoe UI', 8, 'bold'))
        canvas.create_text(cx, cy-5, text=transfer_speed(self.speed), fill=FG, font=('Segoe UI', 14, 'bold'))
        canvas.create_text(cx, cy+17, text=f'{link_speed(self.speed):.1f} Mbps', fill=CYAN, font=('Segoe UI', 10))
        caption = f'{self.t("usage")}: {link_speed(self.speed)/plan:.0%}' if plan else self.t('unlimited')
        canvas.create_text(cx, 190, text=caption, fill=GREEN, font=('Segoe UI', 9))
        canvas.create_text(graph_right, 55, text=f'{self.t("peak")}: {transfer_speed(self.peak)}', anchor='e',
                           fill=GREEN, font=('Segoe UI', 9))

    def submit(self, operation, callback=None, on_error=None):
        if self.closing:
            return
        future = self.pool.submit(operation)
        def check():
            if not future.done():
                if self.root.winfo_exists():
                    self.root.after(40, check)
                return
            try:
                value = future.result()
            except Exception as exc:
                self.notice = error_text(exc, self.language)
                if self.closing:
                    messagebox.showwarning('Full Download Manager', self.notice, parent=self.root)
                    self.root.destroy()
                    return
                self.refresh_labels()
                if on_error:
                    on_error(exc)
            else:
                if callback:
                    callback(value)
        self.root.after(40, check)

    def action(self, method, gid=None):
        if self.closing:
            return
        def operation():
            self.engine.call(method, *([gid] if gid else []))
            self.engine.call('saveSession')
            return self.engine.snapshot()
        self.submit(operation, self.receive)

    def clear_history(self):
        if self.closing or self.clearing:
            return
        self.clearing = True
        self.refresh_labels()
        def operation():
            count = self.engine.clear_history()
            return count, self.engine.snapshot()
        def finished(result):
            self.clearing = False
            count, items = result
            self.selected = None
            self.notice = self.t('cleared', count=count)
            self.receive(items)
        def failed(_):
            self.clearing = False
            self.refresh_labels()
        self.submit(operation, finished, on_error=failed)

    def cancel_download(self, gid):
        if self.closing or gid in self.cancelling:
            return
        if not messagebox.askyesno(self.t('cancel_download'), self.t('confirm_cancel'), parent=self.root):
            return
        self.cancelling.add(gid)
        self.notice = self.t('cancelling')
        self.refresh_labels()
        def operation():
            result = self.engine.cancel(gid)
            return result, self.engine.snapshot()
        def finished(value):
            self.cancelling.discard(gid)
            result, items = value
            self.notice = self.t('cancel_complete' if result == 'complete' else
                                 'cancel_preserved' if result == 'preserved' else 'cancelled')
            self.receive(items)
        def failed(exc):
            self.cancelling.discard(gid)
            messagebox.showerror(self.t('error'), error_text(exc, self.language), parent=self.root)
        self.submit(operation, finished, on_error=failed)

    def retry(self, item):
        uris = item.get('files', [{}])[0].get('uris', [])
        if uris:
            self.new_download(uris[0]['uri'])

    def open_folder(self, item):
        path = item.get('files', [{}])[0].get('path', '')
        if not path:
            return
        folder = Path(path).parent
        try:
            if sys.platform == 'win32':
                os.startfile(str(folder))
            else:
                subprocess.Popen(['open' if sys.platform == 'darwin' else 'xdg-open', str(folder)])
        except OSError as exc:
            messagebox.showerror(self.t('error'), str(exc), parent=self.root)

    def receive(self, items, sample=False):
        self.items = items
        self.speed = sum(int(item.get('downloadSpeed', 0)) for item in items if item['status'] == 'active')
        self.peak = max(self.peak, self.speed)
        if sample:
            self.history.append(self.speed)
        if self.root.state() == 'withdrawn':
            return
        self.refresh_labels()
        self.draw_cards()
        self.draw_graph()

    def poll(self):
        if self.closing:
            return
        if not self.polling:
            self.polling = True
            def operation():
                try:
                    return self.engine.snapshot(), None
                except Exception as exc:
                    return None, str(exc)
            def received(result):
                self.polling = False
                items, error = result
                if error:
                    self.notice = self.t('engine_error') + error_text(error, self.language)
                    self.refresh_labels()
                else:
                    self.receive(items, sample=True)
            self.submit(operation, received)
        self.after_ids.append(self.root.after(2000 if self.root.state() == 'withdrawn' else 800, self.poll))
        if len(self.after_ids) > 20:
            self.after_ids = self.after_ids[-20:]

    def browser_requests(self):
        if self.closing:
            return
        from browser_bridge import receive_requests
        from queue import Empty
        if self.tray:
            self.tray.language = self.language
            while True:
                try:
                    command = self.tray.events.get_nowait()
                except Empty:
                    break
                if command == 'exit':
                    self.close()
                    return
                self.foreground_window(self.root)
        marker = self.engine.data / 'show-window'
        try:
            if marker.exists():
                fresh = time.time() - marker.stat().st_mtime < 30
                marker.unlink(missing_ok=True)
                if fresh:
                    self.foreground_window(self.root)
        except OSError:
            pass
        receive_requests(self.engine.data, self.browser_download)
        self.after_ids.append(self.root.after(100, self.browser_requests))
        if len(self.after_ids) > 20:
            self.after_ids = self.after_ids[-20:]

    def browser_download(self, link):
        if self.closing:
            raise ValueError(self.t('closing'))
        from app import valid_url
        link = valid_url(link)
        if link not in self.pending_links:
            self.pending_links.append(link)
        self.toast_until = time.monotonic()+10
        self.refresh_labels()
        self.foreground_window(self.root)

    def foreground_window(self, window):
        """Raise the main window briefly above the browser."""
        def activate():
            if self.closing or not window.winfo_exists():
                return
            window.deiconify()
            window.update_idletasks()
            window.attributes('-topmost', True)
            window.lift()
            window.focus_force()
        activate()
        self.refresh_labels()
        self.draw_cards()
        self.draw_graph()
        # Windows maps a restored transient parent asynchronously. Raise again
        # after that mapping rather than letting the browser keep foreground.
        self.after_ids.append(self.root.after(100, activate))
        def release():
            if window.winfo_exists():
                window.attributes('-topmost', False)
        self.after_ids.append(self.root.after(1500, release))

    def dialog(self, title, width, height):
        window = tk.Toplevel(self.root)
        window.title(title + ' — Full Download Manager')
        window.configure(bg=CARD)
        window.geometry(f'{width}x{height}')
        window.minsize(width, height)
        window.transient(self.root)
        self.dialogs.append(window)
        window.protocol('WM_DELETE_WINDOW', lambda: self.destroy_dialog(window))
        return window

    def destroy_dialog(self, window):
        if window in self.dialogs:
            self.dialogs.remove(window)
        if window.winfo_exists():
            window.destroy()

    def dismiss_dialog(self):
        if self.dialogs:
            self.destroy_dialog(self.dialogs[-1])

    def new_download(self, link=''):
        if self.closing:
            return
        window = self.dialog(self.t('new'), 670, 420)
        frame = tk.Frame(window, bg=CARD)
        frame.pack(fill='both', expand=True, padx=26, pady=24)
        self.label(frame, self.t('new'), size=20, bold=True).pack(anchor='w', pady=(0, 12))
        self.label(frame, self.t('link'), muted=True).pack(anchor='w', pady=(5, 6))
        url = tk.StringVar(value=link)
        entry = ttk.Entry(frame, textvariable=url, style='FDM.TEntry', font=('Segoe UI', 11))
        entry.pack(fill='x', ipady=3)
        self.label(frame, self.t('folder'), muted=True).pack(anchor='w', pady=(17, 6))
        row = tk.Frame(frame, bg=CARD)
        row.pack(fill='x')
        directory = tk.StringVar(value=self.preferences['download_directory'])
        ttk.Entry(row, textvariable=directory, style='FDM.TEntry').pack(side='left', fill='x', expand=True)
        def browse():
            selected = filedialog.askdirectory(parent=window)
            if selected:
                directory.set(selected)
        self.button(row, self.t('browse'), browse).pack(side='left', padx=(8, 0))
        self.label(frame, self.t('no_limit'), muted=True).pack(anchor='w', pady=14)
        controls = tk.Frame(frame, bg=CARD)
        controls.pack(fill='x', pady=8)
        def start():
            from app import valid_url
            try:
                value = valid_url(url.get().strip())
                destination = directory.get().strip()
                if not destination:
                    raise ValueError(self.t('invalid_folder'))
            except ValueError as exc:
                messagebox.showerror(self.t('error'), error_text(exc, self.language), parent=window)
                return
            count = self.preferences['connections']
            def operation():
                gid = self.engine.add(value, destination, count)
                return gid
            def added(_):
                self.notice = self.t('queued')
                self.filter = 'all'
                self.refresh_labels()
            self.submit(operation, added)
            self.destroy_dialog(window)
        self.button(controls, self.t('cancel'), lambda: self.destroy_dialog(window)).pack(side='left')
        self.button(controls, self.t('start'), start, primary=True).pack(side='right')
        entry.focus_set()
        window.bind('<Return>', lambda _: start())
        window.bind('<Escape>', lambda _: self.destroy_dialog(window))
        return window

    def show_settings(self):
        if self.closing:
            return
        window = self.dialog(self.t('settings'), 690, 615)
        frame = tk.Frame(window, bg=CARD)
        frame.pack(fill='both', expand=True, padx=28, pady=24)
        self.label(frame, self.t('settings'), size=21, bold=True).pack(anchor='w', pady=(0, 15))
        values = {}
        language = tk.StringVar(value='English' if self.language == 'en' else 'Türkçe')
        self.label(frame, self.t('language'), muted=True).pack(anchor='w', pady=(0, 5))
        language_box = ttk.Combobox(frame, textvariable=language, values=('Türkçe', 'English'), state='readonly', style='FDM.TCombobox')
        language_box.pack(fill='x')
        for key, caption, options in (
            ('connections', 'connections', (1, 4, 8, 16, 32)),
            ('concurrent_downloads', 'concurrent', tuple(range(1, 9))),
            ('internet_mbps', 'line_speed', None),
        ):
            self.label(frame, self.t(caption), muted=True).pack(anchor='w', pady=(15, 5))
            values[key] = tk.StringVar(value=str(self.preferences[key]))
            if options:
                widget = ttk.Combobox(frame, textvariable=values[key], values=options, state='readonly', style='FDM.TCombobox')
            else:
                widget = ttk.Entry(frame, textvariable=values[key], style='FDM.TEntry')
            widget.pack(fill='x')
        self.label(frame, self.t('line_help'), muted=True, wraplength=630, justify='left').pack(anchor='w', pady=(9, 0))
        self.label(frame, self.t('speed_help'), muted=True, wraplength=630, justify='left').pack(anchor='w', pady=(9, 0))
        self.label(frame, self.t('connection_help'), muted=True, wraplength=630, justify='left').pack(anchor='w', pady=(9, 0))
        controls = tk.Frame(frame, bg=CARD)
        controls.pack(side='bottom', fill='x', pady=(10, 0))
        save_button = self.button(controls, self.t('save'), lambda: None, primary=True)
        def save():
            try:
                new_values = dict(self.preferences)
                new_values.update(
                    language='en' if language.get() == 'English' else 'tr',
                    connections=int(values['connections'].get()),
                    concurrent_downloads=int(values['concurrent_downloads'].get()),
                    internet_mbps=float(values['internet_mbps'].get().replace(',', '.')),
                )
                if not 1 <= new_values['connections'] <= 32 or not 1 <= new_values['concurrent_downloads'] <= 8 or not 0 <= new_values['internet_mbps'] <= 100000:
                    raise ValueError
            except ValueError:
                messagebox.showerror(self.t('error'), self.t('invalid_settings'), parent=window)
                return
            save_button.configure(state='disabled')
            def operation():
                self.engine.configure(new_values['connections'], new_values['concurrent_downloads'])
                return preferences.save(new_values, self.settings_path)
            def applied(saved):
                self.preferences = saved
                for dialog in list(self.dialogs):
                    self.destroy_dialog(dialog)
                self.notice = self.t('applied')
                self.build()
            self.submit(operation, applied, on_error=lambda _: save_button.configure(state='normal') if window.winfo_exists() else None)
        save_button.configure(command=save)
        save_button.pack(side='right')
        self.button(controls, self.t('cancel'), lambda: self.destroy_dialog(window)).pack(side='left')

    def open_browser_help(self):
        if sys.platform != 'win32':
            return
        python = Path(sys.executable).with_name('pythonw.exe')
        try:
            subprocess.Popen([str(python), str(Path(__file__).with_name('browser_setup.py')), '--guide'],
                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except OSError as exc:
            messagebox.showerror(self.t('browser_error'), str(exc), parent=self.root)

    def hide(self):
        if self.closing:
            return
        for dialog in list(self.dialogs):
            self.destroy_dialog(dialog)
        if self.tray:
            self.root.withdraw()
        else:
            # Keep a taskbar route back if the notification area is unavailable.
            self.root.iconify()

    def close(self):
        if self.closing:
            return
        for dialog in list(self.dialogs):
            self.destroy_dialog(dialog)
        self.notice = self.t('closing')
        self.refresh_labels()
        self.closing = True
        for after_id in self.after_ids:
            try:
                self.root.after_cancel(after_id)
            except tk.TclError:
                pass
        def shutdown():
            self.engine.close()
        future = self.pool.submit(shutdown)
        def check():
            if not future.done():
                self.root.after(50, check)
                return
            try:
                future.result()
            except Exception as exc:
                messagebox.showwarning('Full Download Manager', error_text(exc, self.language), parent=self.root)
            finally:
                self.pool.shutdown(wait=False)
                self.root.destroy()
        self.root.after(50, check)


def launch():
    from app import Engine
    from browser_bridge import running
    data = Path.home() / '.hizli-indir'
    if running(data):
        (data / 'show-window').touch()
        return
    settings = preferences.load()
    # pythonw must have our own taskbar identity instead of Python's identity.
    if os.name == 'nt':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('FullDownloadManager.Desktop')
    root = tk.Tk()
    root.withdraw()
    try:
        engine = Engine(connections=settings['connections'], concurrent_downloads=settings['concurrent_downloads'])
    except Exception as exc:
        if str(exc) == 'Uygulama zaten açık. Açık pencereyi kullanın.' and running(data):
            (data / 'show-window').touch()
            root.destroy()
            return
        messagebox.showerror(text('startup_error', settings['language']), error_text(exc, settings['language']), parent=root)
        root.destroy()
        return
    ui = None
    try:
        ui = FullDownloadManager(root, engine, settings)
        if os.name == 'nt':
            from windows_tray import WindowsTray
            try:
                ui.tray = WindowsTray(ui.language).start()
            except OSError:
                pass
        root.deiconify()
        ui.poll()
        ui.browser_requests()
        root.mainloop()
    finally:
        if ui:
            ui.pool.shutdown(wait=True)
        if engine.process.poll() is None:
            engine.close()

