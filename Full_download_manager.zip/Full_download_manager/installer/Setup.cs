﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("Full Download Manager Kurulum")]
[assembly: AssemblyDescription("Full Download Manager kullanıcı hesabı kurulumu")]
[assembly: AssemblyVersion("1.3.0.0")]
static class Program {
    internal static string AppRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Full Download Manager", "app");
    [STAThread]
    static int Main(string[] args) {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try {
            if (args.Length == 2 && args[0] == "/extract-only") {
                Extract(Path.GetFullPath(args[1]));
                return 0;
            }
            using (var mutex = new Mutex(false, @"Local\HizliIndirInstaller")) {
                if (!mutex.WaitOne(0)) {
                    MessageBox.Show("Kurulum zaten açık.", "Full Download Manager");
                    return 1;
                }
                try {
                    bool installOnly = args.Length == 1 && args[0] == "/install-only";
                    using (var window = new SetupWindow(installOnly)) {
                        Application.Run(window);
                        return window.Result;
                    }
                } finally { mutex.ReleaseMutex(); }
            }
        } catch (Exception e) {
            MessageBox.Show(e.Message, "Full Download Manager kurulamadı", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }
    internal static void Extract(string root) {
        Directory.CreateDirectory(root);
        root = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip")) {
            if (stream == null) throw new IOException("Kurulum paketi eksik.");
            using (var archive = new ZipArchive(stream, ZipArchiveMode.Read)) {
                foreach (var entry in archive.Entries) {
                    string destination = Path.GetFullPath(Path.Combine(root, entry.FullName));
                    if (!destination.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                        throw new IOException("Kurulum paketinde geçersiz dosya yolu.");
                    if (String.IsNullOrEmpty(entry.Name)) { Directory.CreateDirectory(destination); continue; }
                    Directory.CreateDirectory(Path.GetDirectoryName(destination));
                    using (var source = entry.Open())
                    using (var target = File.Create(destination)) source.CopyTo(target);
                }
            }
        }
    }
}
sealed class SetupWindow : Form {
    readonly Label status = new Label();
    readonly Button install = new Button();
    readonly Button close = new Button();
    readonly Button browserHelp = new Button();
    readonly CheckBox browser = new CheckBox();
    readonly ComboBox browserChoice = new ComboBox();
    readonly string[] browserKeys = {"chrome", "brave", "edge", "vivaldi", "opera", "chromium", "firefox", "zen"};
    readonly CheckBox launch = new CheckBox();
    readonly ProgressBar progress = new ProgressBar();
    readonly bool installOnly;
    bool running;
    bool complete;
    internal int Result = 1;
    internal SetupWindow(bool installOnly) {
        this.installOnly = installOnly;
        Icon = System.Drawing.Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
        Text = "Full Download Manager — Kurulum";
        Font = new Font("Segoe UI", 10);
        BackColor = Color.FromArgb(245, 247, 251);
        ClientSize = new Size(580, 420);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        var title = new Label { Text = "Full Download Manager", Font = new Font("Segoe UI", 23, FontStyle.Bold), AutoSize = true, Location = new Point(25, 22) };
        status.Text = "Dosyalarınızı kolayca indirin.\r\nKurulum, gerekli bileşenleri sizin için hazırlayacak.";
        status.SetBounds(28, 82, 525, 75);
        browser.Text = "Uzantıyı kurmak için seçtiğim tarayıcıda mağazayı aç";
        browser.Checked = true;
        browser.SetBounds(28, 164, 520, 28);
        browserChoice.DropDownStyle = ComboBoxStyle.DropDownList;
        browserChoice.Items.AddRange(new object[] {"Tarayıcı seçin…", "Google Chrome", "Brave", "Microsoft Edge", "Vivaldi", "Opera", "Chromium", "Firefox", "Zen Browser"});
        browserChoice.SelectedIndex = 0;
        browserChoice.SetBounds(28, 199, 524, 30);
        browser.CheckedChanged += delegate { browserChoice.Enabled = browser.Checked && !running; };
        launch.Text = "Kurulum bitince uygulamayı aç";
        launch.Checked = true;
        launch.SetBounds(28, 237, 520, 28);
        var location = new Label { Text = "Kurulum yeri: " + Program.AppRoot, AutoEllipsis = true };
        location.SetBounds(28, 279, 525, 40);
        progress.SetBounds(28, 330, 525, 8);
        install.Text = "Kur";
        install.SetBounds(427, 366, 125, 34);
        install.Click += delegate { if (complete) { OpenApp(); Close(); } else BeginInstall(); };
        close.Text = "Vazgeç";
        close.SetBounds(294, 366, 125, 34);
        close.Click += delegate { Close(); };
        browserHelp.Text = "Mağazayı aç";
        browserHelp.SetBounds(28, 366, 175, 34);
        browserHelp.Visible = false;
        browserHelp.Click += delegate { OpenBrowserStore(); };
        Controls.AddRange(new Control[] { title, status, browser, browserChoice, launch, location, progress, install, close, browserHelp });
        FormClosing += delegate(object sender, FormClosingEventArgs e) { if (running) e.Cancel = true; };
        Shown += delegate { if (installOnly) BeginInstall(); };
    }
    void SetStatus(string message) {
        if (IsDisposed || String.IsNullOrWhiteSpace(message)) return;
        BeginInvoke((Action)delegate { status.Text = message; });
    }
    bool AppOpen() {
        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".hizli-indir", "app.lock");
        if (!File.Exists(path)) return false;
        try { using (File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) {} return false; }
        catch (IOException) { return true; }
    }
    void BeginInstall() {
        if (browser.Checked && !installOnly && SelectedBrowser() == "") {
            status.Text = "Uzantı için bir tarayıcı seçin veya mağazayı aç seçeneğini kapatın.";
            browserChoice.Focus();
            return;
        }
        if (AppOpen()) {
            status.Text = "Full Download Manager açık. Uygulamada “Kaydet ve çık” düğmesine basın, ardından yeniden Kur'u seçin.";
            if (installOnly) { Result = 2; Close(); }
            return;
        }
        bool configure = browser.Checked;
        bool start = launch.Checked;
        string selectedBrowser = SelectedBrowser();
        running = true;
        install.Enabled = close.Enabled = browser.Enabled = launch.Enabled = false;
        browserChoice.Enabled = false;
        progress.Style = ProgressBarStyle.Marquee;
        status.Text = "Uygulama dosyaları hazırlanıyor…";
        var worker = new BackgroundWorker();
        worker.DoWork += delegate {
            Program.Extract(Program.AppRoot);
            string script = Path.Combine(Program.AppRoot, "windows_setup.ps1");
            string arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"" + script + "\" -Headless -NoLaunch -RegisterInstall";
            if (configure) arguments += " -ConfigureBrowser";
            if (configure && selectedBrowser != "") arguments += " -Browser " + selectedBrowser;
            var info = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, @"WindowsPowerShell\v1.0\powershell.exe"), arguments);
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.RedirectStandardOutput = info.RedirectStandardError = true;
            info.StandardOutputEncoding = info.StandardErrorEncoding = Encoding.UTF8;
            info.WorkingDirectory = Program.AppRoot;
            var errors = new StringBuilder();
            using (var process = new Process()) {
                process.StartInfo = info;
                process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) { SetStatus(e.Data); };
                process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (e.Data != null) errors.AppendLine(e.Data); };
                process.Start();
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();
                process.WaitForExit();
                if (process.ExitCode != 0) throw new IOException("Kurulum tamamlanamadı.\r\n" + errors.ToString());
            }
        };
        worker.RunWorkerCompleted += delegate(object sender, RunWorkerCompletedEventArgs e) {
            running = false;
            progress.Style = ProgressBarStyle.Blocks;
            progress.Value = e.Error == null ? 100 : 0;
            install.Enabled = close.Enabled = true;
            if (e.Error != null) {
                status.Text = "Kurulum tamamlanamadı. İnternet bağlantınızı kontrol edip tekrar deneyin.";
                if (installOnly) { Result = 1; Close(); return; }
                MessageBox.Show(this, e.Error.Message, "Kurulum", MessageBoxButtons.OK, MessageBoxIcon.Error);
                browser.Enabled = launch.Enabled = true;
                browserChoice.Enabled = browser.Checked;
                return;
            }
            Result = 0;
            complete = true;
            close.Text = "Bitir";
            install.Text = "Uygulamayı aç";
            browserHelp.Visible = configure;
            browserChoice.Enabled = configure;
            status.Text = configure
                ? "Kurulum tamamlandı. Seçtiğiniz tarayıcıda mağaza açılacak.\r\nUzantı kurulumunu mağaza sayfasından onaylayabilirsiniz."
                : "Kurulum tamamlandı. Masaüstü ve Başlat menüsü kısayollarınız hazır.";
            if (installOnly) { Close(); return; }
            if (configure) OpenBrowserStore();
            if (start) OpenApp();
        };
        worker.RunWorkerAsync();
    }
    string SelectedBrowser() {
        int index = browserChoice.SelectedIndex - 1;
        return index >= 0 && index < browserKeys.Length ? browserKeys[index] : "";
    }
    void OpenBrowserStore() {
        string selected = SelectedBrowser();
        if (selected == "") { status.Text = "Önce bir tarayıcı seçin."; return; }
        OpenLauncher("--browser-install --browser " + selected);
    }
    void OpenApp() { OpenLauncher(""); }
    void OpenLauncher(string arguments) {
        try {
            Process.Start(new ProcessStartInfo(Path.Combine(Program.AppRoot, "FullDownloadManager.exe"), arguments) {
                UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = Program.AppRoot
            });
        } catch (Exception e) { MessageBox.Show(this, e.Message, "Full Download Manager"); }
    }
}
