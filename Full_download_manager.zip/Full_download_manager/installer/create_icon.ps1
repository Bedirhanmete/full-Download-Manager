# Native drawing only; no image-generation or third-party package is required.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$assets = Join-Path (Split-Path $PSScriptRoot) 'assets'
[void](New-Item -ItemType Directory -Path $assets -Force)
$bitmap = New-Object Drawing.Bitmap(64, 64)
$graphics = [Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.Clear([Drawing.Color]::Transparent)
$shape = New-Object Drawing.Drawing2D.GraphicsPath
$shape.AddArc(2, 2, 24, 24, 180, 90)
$shape.AddArc(38, 2, 24, 24, 270, 90)
$shape.AddArc(38, 38, 24, 24, 0, 90)
$shape.AddArc(2, 38, 24, 24, 90, 90)
$shape.CloseFigure()
$brush = New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(0, 120, 212))
$pen = New-Object Drawing.Pen([Drawing.Color]::White, 4)
$pen.StartCap = [Drawing.Drawing2D.LineCap]::Round
$pen.EndCap = [Drawing.Drawing2D.LineCap]::Round
$pen.LineJoin = [Drawing.Drawing2D.LineJoin]::Round
try {
    $graphics.FillPath($brush, $shape)
    $graphics.DrawLine($pen, 32, 14, 32, 38)
    $points = [Drawing.Point[]]@((New-Object Drawing.Point(21,28)), (New-Object Drawing.Point(32,39)), (New-Object Drawing.Point(43,28)))
    $graphics.DrawLines($pen, $points)
    $tray = [Drawing.Point[]]@((New-Object Drawing.Point(17,42)), (New-Object Drawing.Point(17,49)), (New-Object Drawing.Point(47,49)), (New-Object Drawing.Point(47,42)))
    $graphics.DrawLines($pen, $tray)
    $bitmap.Save((Join-Path $assets 'app.png'), [Drawing.Imaging.ImageFormat]::Png)
    foreach ($extension in @('browser-extension', 'browser-extension-firefox')) {
        $icons = Join-Path (Split-Path $PSScriptRoot) ($extension + '/icons')
        [void](New-Item -ItemType Directory -Path $icons -Force)
        foreach ($size in @(16, 32, 48, 128)) {
            $scaled = New-Object Drawing.Bitmap($size, $size)
            $canvas = [Drawing.Graphics]::FromImage($scaled)
            try {
                $canvas.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                $canvas.DrawImage($bitmap, 0, 0, $size, $size)
                $scaled.Save((Join-Path $icons "app-$size.png"), [Drawing.Imaging.ImageFormat]::Png)
            } finally { $canvas.Dispose(); $scaled.Dispose() }
        }
    }
    $appIcon = [Drawing.Icon]::FromHandle($bitmap.GetHicon())
    $stream = [IO.File]::Create((Join-Path $assets 'app.ico'))
    try { $appIcon.Save($stream) } finally { $stream.Dispose(); $appIcon.Dispose() }
} finally {
    $pen.Dispose()
    $brush.Dispose()
    $shape.Dispose()
    $graphics.Dispose()
    $bitmap.Dispose()
}

