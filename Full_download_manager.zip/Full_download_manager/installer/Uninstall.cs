﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

[assembly: AssemblyTitle("Full Download Manager Uninstaller")]
[assembly: AssemblyVersion("1.3.0.0")]
static class Uninstaller {
    [STAThread]
    static int Main(string[] args) {
        try {
            bool check = args.Length == 1 && args[0] == "--check";
            bool quiet = args.Length == 1 && args[0] == "--quiet";
            if (args.Length > 0 && !check && !quiet) return 2;
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string root = null;
            foreach (string name in new [] {"Full Download Manager", "HizliIndir"}) {
                string candidate = Path.Combine(local, name, "app");
                if (File.Exists(Path.Combine(candidate, "windows_uninstall.ps1"))) {
                    root = candidate; break;
                }
            }
            if (check) return root == null ? 2 : 0;
            if (root == null) {
                MessageBox.Show("Full Download Manager kurulumu bulunamadi.", "Full Download Manager");
                return 1;
            }
            string script = Path.Combine(root, "windows_uninstall.ps1");
            string arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"" + script + "\"" + (quiet ? " -Quiet" : "");
            Process.Start(new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, @"WindowsPowerShell\v1.0\powershell.exe"), arguments) {
                UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = local
            });
            // Exit before the script removes our installed executable.
            return 0;
        } catch (Exception error) {
            MessageBox.Show(error.Message, "Full Download Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }
}
