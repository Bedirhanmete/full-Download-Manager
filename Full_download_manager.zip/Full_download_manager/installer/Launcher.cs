﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using System.Reflection;

[assembly: AssemblyTitle("Full Download Manager")]
[assembly: AssemblyVersion("1.3.0.0")]
static class Launcher {
    [STAThread]
    static int Main(string[] args) {
        try {
            string root = AppDomain.CurrentDomain.BaseDirectory;
            string script = Path.Combine(root, "windows_setup.ps1");
            if (!File.Exists(script)) throw new IOException("Uygulama dosyaları eksik. Kurulumu yeniden çalıştırın.");
            string extra = args.Length == 1 && args[0] == "--browser-help" ? " -BrowserHelp" : "";
            if (args.Length == 1 && args[0] == "--browser-install") extra = " -BrowserInstall";
            if (args.Length == 3 && args[0] == "--browser-install" && args[1] == "--browser") {
                string[] allowed = {"chrome", "brave", "edge", "vivaldi", "opera", "chromium", "firefox", "zen"};
                if (Array.IndexOf(allowed, args[2]) < 0) throw new ArgumentException("Unknown browser.");
                extra = " -BrowserInstall -Browser " + args[2];
            }
            var info = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, @"WindowsPowerShell\v1.0\powershell.exe"),
                "-NoProfile -NonInteractive -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"" + script + "\"" + extra);
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.WorkingDirectory = root;
            Process.Start(info);
            return 0;
        } catch (Exception e) {
            MessageBox.Show(e.Message, "Full Download Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }
}
