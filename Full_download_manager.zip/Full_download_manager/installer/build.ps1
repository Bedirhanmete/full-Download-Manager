﻿# Build a self-contained installer with the .NET Framework supplied by Windows.
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
& (Join-Path $PSScriptRoot 'create_icon.ps1')
& py -3.13 (Join-Path $root 'tools/package_extension.py')
if ($LASTEXITCODE -ne 0) { throw 'Firefox basvuru paketi olusturulamadi.' }
$icon = Join-Path $root 'assets/app.ico'
$compiler = Join-Path $env:SystemRoot 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { throw '.NET Framework C# derleyicisi bulunamadı.' }
$output = Join-Path $root 'dist'
[void](New-Item -ItemType Directory -Path $output -Force)
$staging = Join-Path ([IO.Path]::GetTempPath()) ('hizli-build-' + [guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $staging)
try {
    $payload = Join-Path $staging 'payload'
    [void](New-Item -ItemType Directory -Path $payload)
    $files = @('app.py', 'download_files.py', 'desktop_ui.py', 'windows_tray.py', 'fluent_widgets.py', 'preferences.py', 'i18n.py', 'app_start.pyw', 'browser_bridge.py', 'native_host.py', 'protocol_handler.py',
        'setup_browser.py', 'setup_protocol.py', 'browser_setup.py', 'extension_install.py', 'browser-link.html', 'windows_setup.ps1',
        'windows_uninstall.ps1', 'Baslat.vbs', 'Baslat.bat', 'README.md')
    foreach ($file in $files) { Copy-Item -LiteralPath (Join-Path $root $file) -Destination $payload }
    foreach ($directory in @('assets', 'browser-extension', 'browser-extension-firefox')) {
        Copy-Item -LiteralPath (Join-Path $root $directory) -Destination $payload -Recurse
    }
    $launcher = Join-Path $payload 'FullDownloadManager.exe'
    & $compiler /nologo /target:winexe /platform:anycpu /optimize+ "/win32icon:$icon" "/out:$launcher" /reference:System.Windows.Forms.dll (Join-Path $PSScriptRoot 'Launcher.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Başlatıcı derlenemedi.' }
    $uninstaller = Join-Path $output 'FullDownloadManager-Uninstall.exe'
    & $compiler /nologo /target:winexe /platform:anycpu /optimize+ "/win32icon:$icon" "/out:$uninstaller" /reference:System.Windows.Forms.dll (Join-Path $PSScriptRoot 'Uninstall.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Uninstaller build failed.' }
    Copy-Item -LiteralPath $uninstaller -Destination $payload
    $zip = Join-Path $staging 'payload.zip'
    Compress-Archive -Path (Join-Path $payload '*') -DestinationPath $zip -CompressionLevel Optimal
    $installer = Join-Path $output 'FullDownloadManager-Setup.exe'
    & $compiler /nologo /target:winexe /platform:anycpu /optimize+ "/win32icon:$icon" "/out:$installer" "/resource:$zip,payload.zip" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.IO.Compression.dll (Join-Path $PSScriptRoot 'Setup.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Kurulum dosyası derlenemedi.' }
    Get-Item -LiteralPath $installer | Select-Object FullName, Length
    Get-FileHash -LiteralPath $installer -Algorithm SHA256
} finally {
    $resolved = [IO.Path]::GetFullPath($staging)
    $tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
    if (-not $resolved.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path $resolved -Leaf) -notlike 'hizli-build-*') {
        throw 'Güvenli olmayan derleme temizleme yolu.'
    }
    Remove-Item -LiteralPath $resolved -Recurse -Force
}
